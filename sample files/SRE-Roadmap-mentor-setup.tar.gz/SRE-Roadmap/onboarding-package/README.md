# Onboarding Package — SRE Mentor Workspace

This folder collects every instruction, guide, and next-step plan for your SRE learning workspace in one place. Use it as the single source of truth for Day‑1 onboarding, Git/GitHub setup, lab submission rules, dashboard usage, progress schema, and the immediate plan I will follow as your mentor/developer.

Folder: onboarding-package
Files included here:
- README.md (this file)

---

Table of contents
- Quick start (what to do before 15‑Aug‑2026)
- Git & GitHub (install, configure, clone, branch, commit, push, pull)
- SSH setup (Windows / macOS / Linux) & HTTPS alternative
- Lab submission process (step-by-step commands + PR checklist)
- Daily / Weekly routine and required files
- Dashboard: view locally, publish, update progress/status.json
- Extended status.json schema (KPIs and timeseries)
- Automation options (Actions) and recommended developer-first step
- Immediate plan: what I will do first and why
- Where to find files in the repo

---

Quick start (before 15‑Aug‑2026)
1. Decide which machine you will use (work laptop / home PC). Prefer a Linux/macOS environment or Windows with Git Bash/WSL.
2. Install Git and optionally VS Code and GitHub Desktop. See Git & GitHub below.
3. If you want SSH access, follow the SSH setup in this file (choose your OS).
4. On 15‑Aug‑2026, follow the Day‑1 plan at plan/day1-15-aug-2026.md (already in the repo).

---

Git & GitHub (absolute beginner guide)
1) Install Git
- macOS: `brew install git` or install Xcode Command Line Tools
- Ubuntu/Debian: `sudo apt update && sudo apt install git -y`
- Windows: install Git for Windows (includes Git Bash) from https://git-scm.com

2) Configure identity (one-time)
- `git config --global user.name "Your Full Name"`
- `git config --global user.email "you@example.com"`

3) Clone the repository
- SSH (if configured): `git clone git@github.com:PunithKumarSRE1305/SRE-Roadmap.git`
- HTTPS: `git clone https://github.com/PunithKumarSRE1305/SRE-Roadmap.git`
- `cd SRE-Roadmap`

4) Branching and workflow (one-liners)
- Create & switch to a new branch: `git switch -c labs/<concept>/lab1-<yourname>`
- Check status: `git status`
- Stage changes: `git add <file>` or `git add .`
- Commit: `git commit -m "labs(<concept>): lab1 - short summary by <yourname>"`
- Push branch: `git push -u origin labs/<concept>/lab1-<yourname>`
- Open a Pull Request on GitHub (use the web UI) and set reviewer: @PunithKumarSRE1305

5) Common commands cheat-sheet
- `git log --oneline` — view history
- `git diff` — view unstaged changes
- `git diff --staged` — view staged changes
- `git pull --rebase origin main` — update branch with latest main
- `git merge <branch>` — merge another branch into current
- `git revert <commit>` — undo a pushed commit safely

Why these commands? (simple student explanation)
- `add` selects which files to include in a snapshot (commit).
- `commit` records a snapshot locally with a message explaining why you changed files.
- `push` uploads those snapshots to GitHub so others (and your mentor) can review.
- `pull` fetches other people's changes. Keeping your branch up-to-date prevents conflicts.

---

SSH setup (short)
- macOS / Linux
  - `ssh-keygen -t ed25519 -C "you@example.com"` (accept defaults)
  - `eval "$(ssh-agent -s)"`
  - `ssh-add ~/.ssh/id_ed25519`
  - `cat ~/.ssh/id_ed25519.pub` -> copy the output -> GitHub: Settings → SSH and GPG keys → New SSH key
  - Test: `ssh -T git@github.com`
- Windows (Git Bash)
  - Follow the same commands inside Git Bash
- HTTPS alternative
  - Use HTTPS clone URL and a Personal Access Token (PAT) when prompted for password. Create PAT in GitHub Settings -> Developer settings -> Personal access tokens.

---

Lab submission process (exact steps you must follow for each lab)
1. Create branch: `git switch -c labs/<concept>/labX-<yourname>`
2. Add artifacts under: `concepts/<concept>/lab-submissions/<yourname>/labX/`
   - Required files: README.md with steps, code/config (scripts/, service unit files), test outputs (logs, screenshots), LAB_REPORT.md
3. Stage & commit: `git add . && git commit -m "labs(<concept>): labX - <short summary> by <yourname>"`
4. Push branch: `git push -u origin labs/<concept>/labX-<yourname>`
5. Open Pull Request on GitHub
   - Title format: `labs(<concept>): labX - <short summary> — <yourname>`
   - PR description must include: steps performed, exact commands, acceptance checklist, test evidence (screenshots or logs), and link to daily note and weekly journal.
   - Label: `lab-submission` and request reviewer: @PunithKumarSRE1305
6. Address review comments by committing fixes to the same branch and pushing. The PR updates automatically.
7. After PR merge, update `progress/status.json` (or I will) with the new concept percent and labs count.

Acceptance criteria for a lab
- Reproducible steps with commands
- Artifacts included (scripts, configs, sample outputs)
- README explains test procedure and expected output
- No secrets or credentials in the repo

---

Daily & Weekly routine (what you must commit)
- Daily note (required every study day): `progress/daily-notes/YYYY-MM-DD-<yourname>.md`
  - Fields: Concept, Time spent, Tasks done, Blockers, Plan for next day
- Weekly journal (required each week): `progress/weekly-journals/YYYY-WW-<yourname>.md`
  - Fields: Total hours, Completed labs/quizzes, Blockers, 3 goals next week
- Lab PRs: `concepts/<concept>/lab-submissions/<yourname>/labX/`
- Quiz answers: `concepts/<concept>/quiz-answers/<yourname>.md`

Missed days policy
- Miss one weekday: document reason in weekly journal and reschedule.
- Miss more than two weekdays in a week: I will assign remediation before new concepts are allowed.

---

Dashboard: view, publish, update
- Files location: `docs/dashboard/index.html`, `docs/dashboard/style.css`, `docs/dashboard/app.js`
- Data source: `progress/status.json`

View locally
1. `git clone` (or `git pull`) the repo
2. From repo root: `python3 -m http.server 8000` (or any static server)
3. Open browser: `http://localhost:8000/docs/dashboard/index.html`

Publish (GitHub Pages)
1. Repo Settings → Pages
2. Source: Branch = `main`, Folder = `/docs`
3. Save and open the published URL (will show `/docs` contents). Dashboard will be at `/docs/dashboard/index.html`.

Update progress
- Edit `progress/status.json` locally and push changes.
- The dashboard reads this file on page load. If published via Pages, push and wait a short time for Pages to redeploy, then reload the page.

---

Extended status.json schema (recommended)
Use this JSON structure to store the KPIs, timeseries, roadmap, and per-concept progress. The dashboard code reads `progress/status.json` at load time.

Example schema:

{
  "overall": 34,
  "study_hours_total": 208,
  "current_streak_days": 90,
  "labs_completed": 54,
  "labs_total": 159,
  "modules_done": 2,
  "modules_total": 15,
  "avg_hours_day_30d": 2.6,
  "sre_score": 39,
  "daily_hours": [
    {"date":"2026-05-11","hours":2.1},
    {"date":"2026-05-12","hours":1.0}
  ],
  "weekly_hours_by_phase": {
    "W1": {"Foundation":8,"Core":0,"Infra":0},
    "W2": {"Foundation":9,"Core":2}
  },
  "phase_completion": {"Foundation":97,"CoreSkills":62,"Infrastructure":14},
  "concepts": {"linux":62,"networking":14,"scripting-python":62,"git":45,"prometheus":20},
  "roadmap": [
    {"phase":"Foundation","months":"1-3","percent":97,"items":["Linux","Networking","Bash"]},
    {"phase":"Core Skills","months":"4-6","percent":62,"items":["Git","Python","Databases"]}
  ]
}

---

Automation options (developer recommendations)
- Option A (manual): You edit `progress/status.json` and push. Simple and safe.
- Option B (semi-automated): Add a GitHub Action that regenerates SVGs in `progress/svg/` from `progress/status.json` when it changes. Keeps README visuals in sync.
- Option C (event-driven): Add a GitHub Action that listens for merged PRs with label `lab-submission` and updates `progress/status.json` automatically (requires rules mapping PRs to concepts and percentage deltas).

Developer-first recommendation (what I will do first)
- Step 1 (priority): Add KPI cards & roadmap visuals to the dashboard UI. Rationale: the dashboard becomes immediately useful and visually matches your reference. This helps you see progress as you start submitting labs.
- Step 2: Publish the dashboard via GitHub Pages so you can view it publicly.
- Step 3: Add a GitHub Action to regenerate per-concept SVGs from `progress/status.json` and commit them back to the repo when the JSON changes.
- Step 4: Implement event-driven automation (optional) to update JSON from merged lab PRs.

Estimated timeline for the developer-first steps
- Step 1: 1–2 hours — implement KPI cards, roadmap bars, and a phase donut.
- Step 2: 10 minutes — enable GitHub Pages and verify URL.
- Step 3: 2–3 hours — write Action to regenerate simple SVGs and commit back.
- Step 4: 4–8 hours — implement, test, and harden PR-to-progress mapping action.

Immediate action I will now take (with your confirmation already provided)
- I will implement Step 1: Add KPI cards & roadmap visuals to `docs/dashboard` and push changes to `main`. After that I will notify you and show the preview instructions and what to update in `progress/status.json` to reflect real values.

If you want me to continue after Step 1, reply: “Continue with Step 2: publish dashboard” or “Add tracker action (Step 3)”.

---

Where to find everything in the repo
- README: `/README.md` (top-level)
- Guides: `/docs/git-basics.md`, `/docs/ssh-setup.md`
- Day‑1 plan: `/plan/day1-15-aug-2026.md`
- Concepts: `/concepts/<concept>/README.md` and labs under `/concepts/<concept>/lab*-*.md`
- Dashboard: `/docs/dashboard/*`
- Progress data: `/progress/status.json`
- SVG placeholders: `/progress/svg/*.svg`

---

If anything in this package is unclear or you want different ordering, tell me now. I will now proceed with Step 1 (Add KPI cards & roadmap visuals) and push the changes to the dashboard. After that I will report the commit SHA and preview instructions.
