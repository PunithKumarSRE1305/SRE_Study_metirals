# 🚀 SRE Roadmap — From Performance Engineer to Site Reliability Engineer

> **Strict, mentor-driven SRE learning workspace.** 15 concepts. 1 year. Start date: **15 August 2026**.
> No sugar-coating. No shortcuts. You earn every percentage point.

---

## 📊 Visual Progress Tracker

### Overall SRE Journey
![Overall progress](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/overall.svg)

### Phase Progress
| Phase | Visual | Range |
|---|---|---|
| Foundation | ![Foundation](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/phase-foundation.svg) | Months 1–3 |
| Core Skills | ![Core Skills](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/phase-core-skills.svg) | Months 4–6 |
| Infrastructure | ![Infrastructure](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/phase-infrastructure.svg) | Months 7–9 |
| Advanced SRE | ![Advanced SRE](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/phase-advanced-sre.svg) | Months 10–12 |

### Concept-wise Progress (click a concept to open its folder)

| # | Concept | Progress | Status | Folder |
|---|---|---|---|---|
| 1 | Linux Fundamentals | ![linux](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/linux.svg) | 🔴 Not started | [concepts/linux](concepts/linux/README.md) |
| 2 | Networking Fundamentals | ![networking](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/networking.svg) | 🔴 Not started | [concepts/networking](concepts/networking/README.md) |
| 3 | Bash Scripting | ![bash](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/bash-scripting.svg) | 🔴 Not started | [concepts/bash-scripting](concepts/bash-scripting/README.md) |
| 4 | Git & Version Control | ![git](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/git.svg) | 🔴 Not started | [concepts/git](concepts/git/README.md) |
| 5 | Python Scripting | ![python](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/python-scripting.svg) | 🔴 Not started | [concepts/python-scripting](concepts/python-scripting/README.md) |
| 6 | Databases (SQL & NoSQL) | ![databases](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/databases.svg) | 🔴 Not started | [concepts/databases](concepts/databases/README.md) |
| 7 | Web Architecture & Protocols | ![web](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/web-architecture.svg) | 🔴 Not started | [concepts/web-architecture](concepts/web-architecture/README.md) |
| 8 | Monitoring & Observability | ![monitoring](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/monitoring-observability.svg) | 🔴 Not started | [concepts/monitoring-observability](concepts/monitoring-observability/README.md) |
| 9 | Containers (Docker) | ![docker](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/docker.svg) | 🔴 Not started | [concepts/docker](concepts/docker/README.md) |
| 10 | Kubernetes | ![k8s](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/kubernetes.svg) | 🔴 Not started | [concepts/kubernetes](concepts/kubernetes/README.md) |
| 11 | Cloud Platforms (AWS) | ![aws](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/cloud-aws.svg) | 🔴 Not started | [concepts/cloud-aws](concepts/cloud-aws/README.md) |
| 12 | Infrastructure as Code | ![iac](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/infrastructure-as-code.svg) | 🔴 Not started | [concepts/infrastructure-as-code](concepts/infrastructure-as-code/README.md) |
| 13 | CI/CD Pipelines | ![cicd](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/ci-cd.svg) | 🔴 Not started | [concepts/ci-cd](concepts/ci-cd/README.md) |
| 14 | Incident Response & Postmortems | ![incident](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/incident-response.svg) | 🔴 Not started | [concepts/incident-response](concepts/incident-response/README.md) |
| 15 | SRE Practices (SLOs, SLIs, Error Budgets) | ![sre](https://raw.githubusercontent.com/PunithKumarSRE1305/SRE-Roadmap/main/progress/svg/sre-practices.svg) | 🔴 Not started | [concepts/sre-practices](concepts/sre-practices/README.md) |

> **Legend:** 🔴 Not started | 🟡 In progress | 🟢 Completed (quiz passed + 3 labs accepted)

### 📈 Live Interactive Dashboard
A full interactive dashboard with KPI cards, charts, and roadmap visuals is available at:
**[https://punithkumarsre1305.github.io/SRE-Roadmap/dashboard/](https://punithkumarsre1305.github.io/SRE-Roadmap/dashboard/)**

(If GitHub Pages is enabled → Settings → Pages → Branch: main, Folder: /docs)

---

## 🎯 The Goal

**Become a Site Reliability Engineer in 12 months, starting 15 August 2026.**

### Is this realistic? YES — but only if you are disciplined.
- You work 11 hours/day as a Performance Engineer. That leaves roughly **1.5–2 hours on weekdays** and **4–6 hours on weekends** for study.
- That's approximately **12–14 hours/week × 52 weeks = ~625 hours** in a year.
- 15 concepts × ~40 hours each = ~600 hours needed.
- **The math works — but there is zero margin for laziness.** Miss too many days and you fall behind. I will not sugar-coat this.

---

## 📋 The Strict Mentoring & Gating Process

This is not a "read and check a box" course. Every concept has a **gate** you must pass through.

### How a concept is marked COMPLETE (no exceptions)

| Gate | Requirement | Who decides |
|---|---|---|
| 📖 Study | Read the concept README, complete daily tasks, write daily notes | You |
| 🧪 Quiz | Answer **10 questions** about the concept. Score **≥ 8/10** to pass | I review your answers |
| 🔬 Labs | Submit **at least 3 lab PRs**. Each must meet acceptance criteria | I review and may request changes |
| 📝 Weekly Journal | Submit a weekly journal every Sunday | I review and assign remediation if needed |

**If you fail the quiz (score < 8/10):** I will tell you to study the concept again. You get ONE retry. If you fail again, I assign remediation tasks before you can reattempt.

**If your lab PR does not meet standards:** I will request changes. You fix them and push again. A lab is only "accepted" when I approve and merge the PR.

**A concept is 100% complete ONLY when:** quiz passed (≥8/10) AND all 3 labs accepted AND merged. Not before.

### What I will NOT do
- ❌ I will not mark something complete because you "read it"
- ❌ I will not accept "I tried" as a lab submission — you must produce working code/config
- ❌ I will not let you skip ahead to Kubernetes before you can use Linux
- ❌ I will not sugar-coat your progress

---

## 📅 Day-Wise Timetable (1 Year)

Full timetable: [plan/one-year-timetable.md](plan/one-year-timetable.md)

| Phase | Weeks | Months | Concepts |
|---|---|---|---|
| **Foundation** | 1–12 | 1–3 | Linux, Networking, Bash, Git |
| **Core Skills** | 13–24 | 4–6 | Python, Databases, Web Architecture, Monitoring |
| **Infrastructure** | 25–36 | 7–9 | Docker, Kubernetes, Cloud, IaC |
| **Advanced SRE** | 37–48 | 10–12 | CI/CD, Incident Response, SRE Practices |
| **Capstone** | 49–52 | Month 13 | Final project + career prep |

Each concept gets ~3 weeks:
- **Weeks 1–2 (Mon–Fri):** ~1.5–2h/day — study theory, take notes, practice
- **Weeks 1–2 (Sat):** ~4–5h — Lab work
- **Weeks 1–2 (Sun):** ~3–4h — Lab work + quiz attempt + weekly journal
- **Week 3:** Finish remaining labs, pass quiz, get concept approved

---

## ☀️ What You Must Do EVERY DAY (Step-by-Step)

Follow this checklist **every single study day**. No skipping.

### Step 1: Open today's plan (5 min)
1. Go to [plan/one-year-timetable.md](plan/one-year-timetable.md) and find today's date/week
2. Read what concept and sub-topic you're studying today
3. Open the concept folder: `concepts/<concept-name>/README.md`

### Step 2: Study (60–90 min)
1. Read the concept README sections: **Why it's used in SRE**, **How it works**, **Major issues**
2. Take notes in a file: `progress/daily-notes/YYYY-MM-DD-punith.md`
3. Try the hands-on exercises mentioned in the README
4. If you're stuck, write down your blocker in the daily note

### Step 3: Commit your daily note (10 min)
1. Open a terminal (see [docs/git-where-to-run.md](docs/git-where-to-run.md) if you don't know how)
2. Run these commands:
   ```
   git checkout main
   git pull origin main
   git switch -c notes/<concept>/<YYYY-MM-DD>
   git add progress/daily-notes/<file>
   git commit -m "notes(<concept>): daily note for <YYYY-MM-DD>"
   git push -u origin notes/<concept>/<YYYY-MM-DD>
   ```
3. Open a Pull Request on GitHub with title: `notes: daily note <YYYY-MM-DD>`

### Step 4: Update your mental model (5 min)
1. Ask yourself: "Can I explain what I learned today to someone else?"
2. If no → you didn't learn it. Go back and study more.
3. Write 1 thing you found confusing in your daily note under "Blockers"

**Daily time budget: ~1.5–2 hours on weekdays, 4–6 hours on weekends**

---

## 📝 What You Must Do EVERY WEEK (Step-by-Step)

### Every Sunday (or your week's last study day):

### Step 1: Write your weekly journal
Create a file: `progress/weekly-journals/YYYY-WW-punith.md`

Use the template at [templates/WEEKLY_JOURNAL.md](templates/WEEKLY_JOURNAL.md). Include:
- Total hours studied this week
- What concepts/labs you worked on
- What you completed (labs accepted, quizzes passed)
- What you struggled with
- 3 goals for next week
- Any blockers or questions for me (your mentor)

### Step 2: Commit and push the journal
```
git checkout main
git pull origin main
git switch -c journal/<YYYY-WW>
git add progress/weekly-journals/<file>
git commit -m "journal: week <YYYY-WW> summary"
git push -u origin journal/<YYYY-WW>
```
Then open a Pull Request titled: `journal: week <WW> — <your summary>`

### Step 3: I will review
- I will read your journal and respond
- If you're behind, I will assign remediation
- If you missed too many days, we will adjust the plan
- If you're on track, I will confirm and set next week's goals

---

## 🔬 How to Submit a Lab (Step-by-Step for Beginners)

> You don't know how to do this yet — that's OK. Follow these exact steps.

### Step 1: Read the lab instructions
Open the lab file, e.g., `concepts/linux/lab1.md`. Read the goal, steps, and acceptance criteria.

### Step 2: Create a branch
Open your terminal in the repo folder and run:
```
git checkout main
git pull origin main
git switch -c labs/linux/lab1-punith
```
(This creates a separate workspace called a "branch" so your changes don't break the main project)

### Step 3: Do the lab work
Create files under: `concepts/linux/lab-submissions/punith/lab1/`
- `README.md` — explain what you did, step by step
- Your code/config files (scripts, service files, Dockerfiles, etc.)
- `LAB_REPORT.md` — use the template at [templates/LAB_REPORT.md](templates/LAB_REPORT.md)
- Test outputs / screenshots if applicable

### Step 4: Commit your work
```
git add .
git commit -m "labs(linux): lab1 - <short summary> by punith"
git push -u origin labs/linux/lab1-punith
```

### Step 5: Open a Pull Request on GitHub
1. Go to https://github.com/PunithKumarSRE1305/SRE-Roadmap
2. You'll see a yellow banner saying "Compare & pull request" — click it
3. Title: `labs(linux): lab1 - <short summary> — punith`
4. In the description, write:
   - What you did
   - Exact commands you ran
   - How you tested it
   - Link to your daily note
5. Click "Create pull request"

### Step 6: Wait for my review
- I will review your code and either approve or request changes
- If I request changes: make the fixes, commit, and push to the same branch (the PR updates automatically)
- Once I approve and merge: the lab is "accepted" ✅

### Step 7: Update progress
After the PR is merged, update `progress/status.json`:
- Increase the concept's percentage
- Increase `labs_completed`
- Commit and push the change (this regenerates the SVGs via CI)

---

## ❓ What If I Miss a Day or a Week?

**Missing one day** — Not the end of the world. Document it in your next daily note. Don't try to cram 4 hours into one night — that doesn't work.

**Missing 2+ days in a week** — You must document the reason in your weekly journal. I will assess whether you need a remediation plan. If this happens twice in a month, we need to have a serious conversation about your commitment.

**Missing a full week** — You fall behind by 1 week. The timetable does not auto-extend. You must catch up on weekends or accept that your 12-month goal slips to 13 months. Your choice.

**What if I miss a lab deadline?** There are no "deadlines" per se — the timetable is a guide. But if you're spending 5 weeks on a concept that should take 3, that's a problem. I will flag it.

**The hard truth:** Life happens. Work gets busy. But if you want this in 12 months, you need ~12 hours/week minimum. If you can't commit that, tell me now and we adjust the timeline. I'd rather have an honest 18-month plan than a fake 12-month one.

---

## 📚 Where to Learn Git (For Absolute Beginners)

You said you don't know what commit, push, pull, or PR means. That's fine — I created a complete guide for you:

| Guide | What it covers | Link |
|---|---|---|
| **Git for Beginners** | What is Git, what is commit/push/pull/PR, why we use them, full command list with meanings | [docs/git-basics.md](docs/git-basics.md) |
| **Where to Run Commands** | Do I use CMD? Which platform? How to connect to GitHub? Windows/Mac/Linux steps | [docs/git-where-to-run.md](docs/git-where-to-run.md) |
| **SSH Setup** | How to set up SSH keys so you don't type passwords | [docs/ssh-setup.md](docs/ssh-setup.md) |

**Read these BEFORE 15 August 2026.** You should be able to clone the repo and make a test commit before Day 1.

---

## 📂 Repository Structure

```
SRE-Roadmap/
├── README.md                          ← You are here (visual tracker + process)
├── concepts/                          ← One folder per concept (15 total)
│   ├── linux/                         ← README + quiz + 3 labs + submissions
│   ├── networking/
│   ├── bash-scripting/
│   ├── git/
│   ├── python-scripting/
│   ├── databases/
│   ├── web-architecture/
│   ├── monitoring-observability/
│   ├── docker/
│   ├── kubernetes/
│   ├── cloud-aws/
│   ├── infrastructure-as-code/
│   ├── ci-cd/
│   ├── incident-response/
│   └── sre-practices/
├── plan/                              ← Timetable and daily plans
│   ├── one-year-timetable.md          ← Full 52-week day-wise schedule
│   ├── daily-template.md              ← What a study day looks like
│   └── day1-15-aug-2026.md            ← Your exact Day 1 plan
├── docs/                              ← Guides
│   ├── git-basics.md                  ← Git explained for beginners
│   ├── git-where-to-run.md            ← Where/how to run git commands
│   ├── ssh-setup.md                   ← SSH key setup
│   └── dashboard/                     ← Interactive progress dashboard
├── templates/                         ← Templates for labs, journals, postmortems
├── progress/                          ← Your progress data and notes
│   ├── status.json                    ← Progress percentages (drives the SVGs)
│   ├── svg/                           ← Auto-generated progress bar images
│   ├── daily-notes/                   ← Your daily study notes go here
│   └── weekly-journals/               ← Your weekly journals go here
├── scripts/                           ← Automation scripts
│   └── generate_svgs.py               ← Regenerates progress SVGs from status.json
├── .github/workflows/                 ← CI automation
│   └── regenerate-svgs.yml            ← Auto-regenerates SVGs when status.json changes
└── onboarding-package/                ← Everything consolidated in one place
```

---

## 🏁 Before You Start (Do These Before 15 August 2026)

- [ ] Read this README fully (yes, all of it)
- [ ] Read [docs/git-basics.md](docs/git-basics.md) — understand commit, push, pull, PR
- [ ] Read [docs/git-where-to-run.md](docs/git-where-to-run.md) — know where to run commands
- [ ] Install Git on your computer
- [ ] Clone this repo to your computer
- [ ] Make a test commit (create any file, commit, push, open a PR)
- [ ] Read [plan/one-year-timetable.md](plan/one-year-timetable.md) — understand the full plan
- [ ] Read [plan/day1-15-aug-2026.md](plan/day1-15-aug-2026.md) — know exactly what to do on Day 1

---

## 📖 Reference

- Inspired by: [andrealmar/sre-university](https://github.com/andrealmar/sre-university)
- SRE Book (free): [https://sre.google/sre-book/table-of-contents/](https://sre.google/sre-book/table-of-contents/)
- Google SRE Workbook (free): [https://sre.google/workbook/table-of-contents/](https://sre.google/workbook/table-of-contents/)

---

**Your mentor is ready. The question is: are you? Start on 15 August 2026. Don't be late.**
