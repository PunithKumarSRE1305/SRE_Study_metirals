# Web Architecture & Protocols

> **Phase:** Core Skills | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — you operate what you understand

---

## 🎯 Why is this used in SRE?

**SREs operate web applications at scale.** To keep them reliable, you must understand how requests flow from users through load balancers, CDNs, API gateways, and services to databases. Without this understanding, you can't:
- Design high-availability architectures
- Diagnose where latency is introduced
- Set up load balancing correctly
- Understand failure modes and design resilient systems

**Real-world example:** Black Friday traffic — your e-commerce site goes from 100 req/s to 10,000 req/s. The load balancer distributes traffic, but the database becomes the bottleneck. You need to understand the architecture to know: add read replicas, implement caching, or use a CDN for static assets. **Architecture knowledge tells you WHERE to scale.**

---

## 🔧 How does this work? (From the basics)

### How a web request flows
```
User's Browser
    ↓ (DNS lookup: www.example.com → 93.184.216.34)
CDN (Cloudflare/Akamai) — serves cached static content
    ↓ (cache miss → forward to origin)
Load Balancer (nginx/AWS ALB) — distributes traffic across servers
    ↓ (round-robin or least-connections)
Web Server (nginx) — serves HTML, reverse proxies to app
    ↓
Application Server (Python/Java/Go) — business logic
    ↓
Database (PostgreSQL/MySQL) — data storage
    ↓
Cache (Redis) — reduce database load
```

### HTTP deep dive
```
Request:
  POST /api/users HTTP/1.1       ← Method + Path + Protocol
  Host: api.example.com           ← Which server
  Content-Type: application/json  ← What kind of data
  Authorization: Bearer xyz123    ← Authentication
  Accept: application/json        ← What response format I want

  {"name": "Punith", "role": "sre"}  ← The body (data)

Response:
  HTTP/1.1 201 Created            ← Status code
  Content-Type: application/json  ← Response format
  Location: /api/users/42         ← Where the new resource is

  {"id": 42, "name": "Punith"}    ← The body
```

### HTTP methods
| Method | Purpose | Idempotent? | Example |
|---|---|---|---|
| GET | Read data | Yes | `GET /api/users/42` |
| POST | Create new | No | `POST /api/users` |
| PUT | Replace entire resource | Yes | `PUT /api/users/42` |
| PATCH | Partial update | No | `PATCH /api/users/42` |
| DELETE | Remove | Yes | `DELETE /api/users/42` |

### Load balancing algorithms
| Algorithm | How it works | When to use |
|---|---|---|
| Round-robin | Send to each server in turn | Equal-capacity servers |
| Least-connections | Send to server with fewest active connections | Variable request times |
| IP hash | Same client always goes to same server | Session affinity needed |
| Weighted | Send more traffic to more powerful servers | Mixed-capacity servers |

### Architecture patterns
```
Monolith:              Microservices:           Service mesh:
┌──────────┐           ┌───┐ ┌───┐ ┌───┐      ┌───┐ ┌───┐ ┌───┐
│ All code │           │ A │ │ B │ │ C │      │ A │ │ B │ │ C │
│ in one   │           └─┬─┘ └─┬─┘ └─┬─┘      └─┴─┘ └─┴─┘ └─┴─┘
│ app      │             └──┬───┘     │        Sidecars handle
└──────────┘                └────┬────┘        all communication
                                 ↓
                             ┌─────┐
                             │ DB  │
                             └─────┘
```

### Caching layers (each layer reduces load on the next)
```
Browser cache → CDN cache → Application cache (Redis) → Database
   (fastest)                                       (slowest)
```

### Resilience patterns
| Pattern | What it does | When to use |
|---|---|---|
| **Circuit breaker** | Stop calling a failing service, let it recover | When a downstream service is failing |
| **Retry with backoff** | Retry failed requests with increasing delay | Transient failures (network blips) |
| **Rate limiting** | Limit requests per client | Protect services from overload |
| **Bulkhead** | Isolate resources so one failure doesn't cascade | Prevent cascading failures |
| **Timeout** | Give up after N seconds | Never let a request hang forever |

---

## 📚 How to master this

1. **Draw architecture diagrams** for every system you encounter.
2. **Set up a multi-tier app** in your lab — web + app + database + cache.
3. **Break it on purpose** — kill the cache, see what happens. Kill a web server, see if the load balancer handles it.
4. **Read the AWS Well-Architected Guide** (reliability pillar).
5. **Study real architecture** — read engineering blogs from Netflix, Uber, Discord.

### Resources
- **System Design Primer (GitHub):** https://github.com/donnemartin/system-design-primer
- **AWS Well-Architected:** https://aws.amazon.com/architecture/well-architected/
- **High Scalability (blog):** https://highscalability.com/

---

## ⚠️ Major issues SREs face with web architecture (and how to fix them)

### 1. Cascading failures → everything goes down
**What happens:** Service A fails → Service B waits for A → B runs out of threads → C waits for B → C fails
**Fix:** Circuit breakers, timeouts, bulkheads. Never let a service wait forever.

### 2. No caching → database overwhelmed
**What happens:** Every request hits the database → DB CPU at 100% → everything slow
**Fix:** Add Redis cache layer. Cache frequent reads. Set TTLs.

### 3. Single point of failure → one server takes down everything
**What happens:** The one load balancer or the one database fails → entire system down
**Fix:** Redundancy everywhere. Multiple load balancers. Database replicas. No single points.

### 4. No rate limiting → service overwhelmed by traffic spike
**Fix:** Implement rate limiting at the API gateway or load balancer level.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Deploy a 3-tier app (web + app + DB), document the architecture with a diagram
2. **Lab 2:** Add a cache layer (Redis) and measure the performance improvement
3. **Lab 3:** Set up nginx as a load balancer in front of 2 app instances, test failover

---

## ✅ Completion checklist

- [ ] Read this README and understand HTTP, load balancing, caching, resilience patterns
- [ ] Complete Lab 1: 3-tier app deployment → PR accepted
- [ ] Complete Lab 2: Add caching layer → PR accepted
- [ ] Complete Lab 3: Load balancer with failover → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
