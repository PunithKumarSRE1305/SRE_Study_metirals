# Web Architecture & Protocols — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** Draw the flow of an HTTP request from a user's browser to a database. Label each component.

**Q2.** What is the difference between HTTP/1.1 and HTTP/2? What improvement does HTTP/2 bring?

**Q3.** Explain four different load balancing algorithms. When would you use each?

**Q4.** What is a CDN? How does it reduce latency? What content should and shouldn't be cached?

**Q5.** What is a circuit breaker? Draw a state diagram and explain each state.

**Q6.** What is the difference between a monolith and microservices? Give one advantage and one disadvantage of each.

**Q7.** Explain idempotency. Why is it important for retries? Which HTTP methods are idempotent?

**Q8.** What is rate limiting? Name two algorithms for implementing it.

**Q9.** Describe a cascading failure. How does it happen? How do you prevent it?

**Q10.** You need to design a highly available web application. Describe the architecture, including redundancy at each layer.

---

## How to submit your answers

1. Create a file: `concepts/web-architecture/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/web-architecture/answers`
4. Open a Pull Request titled: `quiz(web-architecture): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
