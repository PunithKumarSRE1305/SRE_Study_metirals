# Monitoring & Observability

> **Phase:** Core Skills | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** CRITICAL — you can't fix what you can't see

---

## 🎯 Why is this used in SRE?

**Monitoring is the SRE's eyes and ears.** Without monitoring, you're flying blind — you don't know there's a problem until a user complains. With monitoring, you know about issues before users do.

What SREs do with monitoring:
- **Detect problems before users do** (alerts fire at 80% CPU, not at 100% crash)
- **Diagnose root causes** (correlate metrics, logs, and traces)
- **Track SLOs** (are we meeting our reliability targets?)
- **Capacity planning** (when do we need to scale?)
- **Postmortem analysis** (what happened during the incident?)

**Real-world example:** At 2 AM, your monitoring alerts: "Payment API error rate at 5% (threshold 1%)." You check Grafana, see error rate spiked 10 minutes ago, correlate with a deploy, check the logs for the specific error, and roll back the deploy. **Users never notice. That's the power of monitoring.**

---

## 🔧 How does this work? (From the basics)

### The 3 pillars of observability
```
1. METRICS (numbers over time)     → "CPU is at 85%"
2. LOGS (events that happened)     → "ERROR: connection refused at 14:32"
3. TRACES (request journey)        → "Request took 2.5s: 0.1s API → 2.3s DB → 0.1s response"
```

**Metrics** tell you WHAT is wrong. **Logs** tell you WHY. **Traces** tell you WHERE.

### Prometheus architecture
```
┌─────────────────────────────────────────────┐
│                  Prometheus                  │
│  (scrape targets every 15s, store metrics)   │
└──────────┬──────────────────────┬────────────┘
           │ scrape               │ scrape
     ┌─────▼─────┐         ┌─────▼─────┐
     │  Exporter │         │   App     │
     │  (node_   │         │  (/metrics│
     │  exporter)│         │  endpoint)│
     └───────────┘         └───────────┘
           │
           │ query (PromQL)
     ┌─────▼─────┐         ┌───────────┐
     │  Grafana  │         │ Alertmgr  │
     │ (dashboards)│       │ (alerts)  │
     └───────────┘         └─────┬─────┘
                                │
                          ┌─────▼─────┐
                          │  Slack/   │
                          │  PagerDuty│
                          └───────────┘
```

### Metric types
| Type | What it measures | Example | Goes up/down? |
|---|---|---|---|
| **Counter** | Something that only increases | Total HTTP requests | Only up |
| **Gauge** | Current value that can go up or down | CPU usage, memory | Up and down |
| **Histogram** | Distribution of values | Request latency percentiles | Up and down |
| **Summary** | Similar to histogram, client-side calculated | Pre-calculated percentiles | Up and down |

### PromQL (the query language — learn this cold)
```promql
# Current CPU usage
100 - (avg by (instance) (rate(node_cpu_seconds_total{mode="idle"}[5m])) * 100)

# Request rate (requests per second over 5 min)
rate(http_requests_total[5m])

# Error rate (errors / total)
rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m])

# 95th percentile latency
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))

# Average over all instances
avg(node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes) * 100
```

### Alerting rules (Prometheus)
```yaml
# Alert when CPU > 80% for 5 minutes
- alert: HighCPUUsage
  expr: 100 - (avg by(instance)(rate(node_cpu_seconds_total{mode="idle"}[5m])) * 100) > 80
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "High CPU on {{ $labels.instance }}"
    description: "CPU usage is {{ $value }}%"

# Alert when service is down
- alert: ServiceDown
  expr: up{job="nginx"} == 0
  for: 1m
  labels:
    severity: critical
  annotations:
    summary: "{{ $labels.instance }} is down"
```

### Grafana dashboards
Grafana is where you visualize Prometheus metrics. Key concepts:
- **Dashboard** = a collection of panels
- **Panel** = one chart/graph
- **Data source** = where data comes from (Prometheus, in our case)
- **Variables** = dropdowns that let you filter (e.g., select a server)

### Structured logging
```json
// BAD (unstructured — hard to search)
[2026-08-15 14:32:01] ERROR: something went wrong with user 42

// GOOD (structured JSON — easy to search and correlate)
{"timestamp":"2026-08-15T14:32:01Z","level":"ERROR","service":"payment","user_id":42,"message":"transaction_failed","error":"insufficient_funds","trace_id":"abc123"}
```

### Distributed tracing
```
Request: [API Gateway] → [Auth Service] → [Payment Service] → [Database]
Span 1:    100ms total
Span 2:           20ms
Span 3:                   70ms
Span 4:                           50ms (← the slow part!)

Trace shows you that the database call is the bottleneck.
```

---

## 📚 How to master this

1. **Set up Prometheus + Grafana** in a lab — it's free and runs locally.
2. **Instrument a sample app** — expose `/metrics` endpoint and see your data in Grafana.
3. **Write PromQL daily** — query for different metrics until it's natural.
4. **Create real dashboards** — one for infrastructure, one for application, one for SLOs.
5. **Set up alerts** — make them fire on purpose, see them in Alertmanager.

### Resources
- **Prometheus docs:** https://prometheus.io/docs/introduction/overview/
- **PromQL for beginners:** https://promlabs.com/promql-cheat-sheet/
- **Grafana docs:** https://grafana.com/docs/
- **OpenTelemetry:** https://opentelemetry.io/docs/

---

## ⚠️ Major issues SREs face with monitoring (and how to fix them)

### 1. Alert fatigue → too many alerts, engineers ignore them
**Fix:** Only alert on actionable issues. Remove alerts that fire and resolve on their own. Use multi-window burn-rate alerting for SLOs.

### 2. Missing monitoring → problems go undetected
**Fix:** Monitor the 4 golden signals: latency, traffic, errors, saturation. If you don't have a metric for it, you can't alert on it.

### 3. Dashboards nobody reads → wasted effort
**Fix:** Design dashboards for specific use cases (on-call dashboard, capacity dashboard). Keep them simple. Use templating.

### 4. No traces → can't find where time is spent
**Fix:** Implement distributed tracing with OpenTelemetry. Add trace IDs to logs for correlation.

### 5. Monitoring the monitor → Prometheus itself goes down
**Fix:** Monitor Prometheus with another Prometheus (or a simple health check). Alert if Prometheus is down.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Set up Prometheus + node_exporter, write PromQL queries, create a Grafana dashboard
2. **Lab 2:** Instrument a Python app with custom metrics, create dashboards for the app
3. **Lab 3:** Build a complete alerting pipeline — Prometheus → Alertmanager → Slack/PagerDuty, test it end-to-end

---

## ✅ Completion checklist

- [ ] Read this README and understand metrics, logs, traces, PromQL, Grafana
- [ ] Complete Lab 1: Prometheus + Grafana setup → PR accepted
- [ ] Complete Lab 2: App instrumentation → PR accepted
- [ ] Complete Lab 3: Alerting pipeline → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
