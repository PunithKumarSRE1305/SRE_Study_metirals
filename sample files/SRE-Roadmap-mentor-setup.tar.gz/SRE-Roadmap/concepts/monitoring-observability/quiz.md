# Monitoring & Observability — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What are the 3 pillars of observability? How do they complement each other?

**Q2.** Explain the difference between a counter, gauge, and histogram in Prometheus. Give one example of each.

**Q3.** Write a PromQL query that calculates the error rate (5xx responses / total responses) over 5 minutes.

**Q4.** What is the 95th percentile latency? Why is it more useful than average latency for SREs?

**Q5.** Explain how Prometheus scrapes metrics. What is a scrape config? What is a target?

**Q6.** What is alert fatigue? How do you prevent it?

**Q7.** Write an Alertmanager rule that pages when a service has been down for more than 2 minutes.

**Q8.** What is the difference between structured and unstructured logging? Why does it matter?

**Q9.** What is distributed tracing? What is a span? What is a trace? How do they help debug latency?

**Q10.** Your monitoring shows high latency but you don't know which component is slow. Walk through your diagnostic process using metrics, logs, and traces.

---

## How to submit your answers

1. Create a file: `concepts/monitoring-observability/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/monitoring-observability/answers`
4. Open a Pull Request titled: `quiz(monitoring-observability): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
