# Monitoring & Observability — Lab 2: App Instrumentation

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Write a Python web app that exposes Prometheus metrics (request count, request duration histogram, error count). Run it, scrape with Prometheus, and create a Grafana dashboard for the app.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/monitoring-observability/lab2-punith`
3. Create your lab folder: `concepts/monitoring-observability/lab-submissions/punith/lab2/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(monitoring-observability): lab2 - app instrumentation by punith"`
6. Push: `git push -u origin labs/monitoring-observability/lab2-punith`
7. Open a Pull Request titled: `labs(monitoring-observability): lab2 - App Instrumentation — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- Python app exposes /metrics endpoint; At least 3 custom metrics defined; Prometheus scraping the app; Grafana dashboard created for app metrics; README explains the metrics and how to test
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
