# Bash Scripting — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** Why must you always quote variables in Bash? Give an example of what goes wrong if you don't.

**Q2.** What does `set -euo pipefail` do? Explain each flag.

**Q3.** Write a Bash function that takes a filename as an argument and returns 0 if the file exists, 1 if not.

**Q4.** How do you read a file line by line in Bash? Why do you use `IFS= read -r`?

**Q5.** What is the difference between `grep`, `awk`, and `sed`? Give one use case for each.

**Q6.** Write a Bash one-liner that finds the top 5 largest files in /var/log.

**Q7.** Your cron job runs a script but it fails. The script works when you run it manually. What are the likely causes and how do you fix them?

**Q8.** What is a trap in Bash? Write an example that cleans up a temp file when the script exits or errors.

**Q9.** Explain command substitution in Bash. Show two syntaxes and when to use each.

**Q10.** Write a Bash script that checks if the nginx service is running on 3 servers (via SSH) and prints a report. Include error handling.

---

## How to submit your answers

1. Create a file: `concepts/bash-scripting/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/bash-scripting/answers`
4. Open a Pull Request titled: `quiz(bash-scripting): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
