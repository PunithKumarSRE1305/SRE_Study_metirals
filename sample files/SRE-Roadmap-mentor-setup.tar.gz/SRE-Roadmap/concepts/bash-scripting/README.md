# Bash Scripting

> **Phase:** Foundation | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — automation is the SRE's superpower

---

## 🎯 Why is this used in SRE?

**SREs automate everything.** If you do a task more than twice, you should script it. Bash is the fastest way to automate tasks on Linux servers.

Real SRE tasks you'll automate with Bash:
- **Health checks:** Script that checks if all services are running and alerts if not
- **Log parsing:** Script that extracts errors from logs and summarizes them
- **Deployments:** Script that pulls the latest code, restarts services, and verifies health
- **Backups:** Script that backs up databases and uploads to S3
- **Server setup:** Script that configures a new server (install packages, set up users, configs)

**Real-world example:** You manage 20 servers. Every morning you need to check disk space on all of them. Instead of SSH-ing into 20 servers manually (takes 30 minutes), you write a 15-line Bash script that checks all 20 servers in 10 seconds and emails you if any are above 80%. **That's what SREs do.**

---

## 🔧 How does this work? (From the basics)

### What is Bash?
Bash (Bourne Again Shell) is both:
1. A **shell** — the program that interprets your commands in the terminal
2. A **scripting language** — you can write scripts (`.sh` files) that run multiple commands automatically

### Your first script
```bash
#!/bin/bash
# This is a comment. The shebang (#!) tells Linux to use bash to run this file

echo "Hello, SRE!"                          # Print text
name="Punith"                               # Variable (no spaces around =)
echo "Hello, $name"                         # Use the variable

# Conditionals
if [ "$name" = "Punith" ]; then
    echo "Welcome, mentor student"
fi

# Loops
for i in 1 2 3 4 5; do
    echo "Number: $i"
done
```

Save as `hello.sh`, make it executable, and run:
```bash
chmod +x hello.sh
./hello.sh
```

### Variables
```bash
# No spaces around = !!
file="/var/log/syslog"
count=5
message="Server is healthy"

# Use variables with $ prefix
echo $file
echo "The count is $count"

# Command substitution (save output of a command)
today=$(date +%Y-%m-%d)
file_count=$(ls /var/log | wc -l)
echo "Today is $today, there are $file_count files in /var/log"
```

### Conditionals
```bash
# if-else
if [ -f "/etc/nginx/nginx.conf" ]; then
    echo "Nginx config exists"
else
    echo "Nginx config NOT found"
fi

# Test operators
# [ -f file ]     → file exists and is regular file
# [ -d dir ]      → directory exists
# [ -z "$var" ]   → variable is empty
# [ -n "$var" ]   → variable is not empty
# [ "$a" = "$b" ] → strings are equal
# [ "$a" != "$b" ]→ strings are not equal
# [ "$a" -gt 5 ]  → number is greater than 5
# [ "$a" -lt 5 ]  → number is less than 5
# [ "$a" -eq 5 ]  → number equals 5
```

### Loops
```bash
# For loop — iterate over a list
for server in web1 web2 web3; do
    echo "Checking $server..."
    ssh $server "df -h"
done

# While loop — run until condition is false
count=0
while [ $count -lt 5 ]; do
    echo "Count: $count"
    count=$((count + 1))
done

# While loop — read file line by line
while IFS= read -r line; do
    echo "Processing: $line"
done < /etc/hosts
```

### Functions
```bash
check_disk() {
    local threshold=$1
    local usage=$(df / | tail -1 | awk '{print $5}' | tr -d '%')
    if [ $usage -gt $threshold ]; then
        echo "WARNING: Disk usage is ${usage}% (threshold: ${threshold}%)"
        return 1
    else
        echo "OK: Disk usage is ${usage}%"
        return 0
    fi
}

# Call the function
check_disk 80
```

### Error handling (CRITICAL for SRE scripts)
```bash
#!/bin/bash
set -e          # Exit immediately if any command fails
set -u          # Exit if using an undefined variable
set -o pipefail # Exit if any command in a pipe fails
# Together: set -euo pipefail (put this at the top of every script)

# Trap errors and clean up
cleanup() {
    echo "Script failed at line $1. Cleaning up..."
    rm -f /tmp/my_temp_file
}
trap 'cleanup $LINENO' ERR
```

### Text processing (the SRE's bread and butter)
```bash
# grep — search for patterns
grep "ERROR" /var/log/app.log              # Find lines with ERROR
grep -i "error" /var/log/app.log           # Case-insensitive
grep -c "ERROR" /var/log/app.log           # Count occurrences
grep -n "ERROR" /var/log/app.log           # Show line numbers

# awk — process columns
df -h | awk '{print $1, $5}'               # Print columns 1 and 5
ps aux | awk '{print $1, $2, $11}'         # Print user, PID, command

# sed — find and replace
sed 's/old/new/g' file.txt                 # Replace "old" with "new"
sed -i 's/8080/9090/g' config.txt          # Replace in-place (modifies file)

# find — find files
find /var/log -name "*.log" -mtime +7      # Logs older than 7 days
find / -name "*.conf" -size +1M            # Config files larger than 1MB
```

---

## 📚 How to master this

1. **Write scripts, don't just read about them.** Every day, write at least one small script.
2. **Start simple:** A script that checks disk space. Then one that checks services. Then one that parses logs.
3. **Use ShellCheck:** https://www.shellcheck.net/ — paste your script and it finds bugs. Every SRE uses this.
4. **Read other people's scripts:** Look at scripts in `/usr/bin/` or on GitHub. See how experienced people write.
5. **Learn by breaking:** Write a script, intentionally break it, figure out why it broke.
6. **Always use `set -euo pipefail`** at the top of production scripts.

### Resources
- **ShellCheck** (essential tool): https://www.shellcheck.net/
- **Bash Cheat Sheet:** https://devhints.io/bash
- **Advanced Bash-Scripting Guide:** https://tldp.org/LDP/abs/html/

---

## ⚠️ Major issues SREs face with Bash (and how to fix them)

### 1. Unquoted variables break scripts
**What happens:** `rm -rf $FILE` where `$FILE` is empty → `rm -rf` (deletes everything!)
**How to fix:** ALWAYS quote variables: `rm -rf "$FILE"`. Use `set -u` to catch undefined variables.

### 2. Script fails silently
**What happens:** A command in the middle fails but the script keeps going, producing wrong results.
**How to fix:** Use `set -e` (exit on error) and `set -o pipefail` (catch pipe failures).

### 3. Script works on one server but not another
**What happens:** Different bash versions or missing commands cause failures.
**How to fix:** Test on the target environment. Use `#!/usr/bin/env bash` instead of `#!/bin/bash`. Check for required commands with `command -v`.

### 4. Cron job runs but script doesn't
**What happens:** Script works when you run it manually but not via cron.
**How to fix:** Cron has a minimal environment (no PATH, no aliases). Always use full paths (`/usr/bin/grep` not `grep`) and set PATH in the script.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Write a system health-check script (checks disk, memory, CPU, services)
2. **Lab 2:** Write an automated alerting script that runs via cron and sends email/slack on threshold breach
3. **Lab 3:** Write a log-parsing script that extracts errors and generates a summary report

---

## ✅ Completion checklist

- [ ] Read this README and understand variables, conditionals, loops, functions
- [ ] Complete Lab 1: Health-check script → PR accepted
- [ ] Complete Lab 2: Alerting script with cron → PR accepted
- [ ] Complete Lab 3: Log-parsing script → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
