# Git & Version Control — Lab 3: Git Hooks

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Set up a pre-commit Git hook that runs ShellCheck on any .sh files and blocks the commit if errors are found. Document how it works and how to test it.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/git/lab3-punith`
3. Create your lab folder: `concepts/git/lab-submissions/punith/lab3/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(git): lab3 - git hooks by punith"`
6. Push: `git push -u origin labs/git/lab3-punith`
7. Open a Pull Request titled: `labs(git): lab3 - Git Hooks — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- Pre-commit hook installed and working; Hook runs ShellCheck on .sh files; Commits with lint errors are blocked; Commits with clean code succeed; README explains hooks and how to install
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
