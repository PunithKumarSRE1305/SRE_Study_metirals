# Git & Version Control

> **Phase:** Foundation | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — everything in SRE is version-controlled

---

## 🎯 Why is this used in SRE?

**Every change to production goes through Git.** Configuration files, infrastructure code, scripts, runbooks, postmortems — all tracked in Git. If you can't use Git, you can't contribute to an SRE team.

What SREs do with Git daily:
- **Store infrastructure as code** (Terraform, Ansible, Kubernetes manifests)
- **Track configuration changes** (so you know what changed when something breaks)
- **Submit changes for review** (via Pull Requests — nothing goes to production without review)
- **Roll back changes** (when a deployment breaks something, revert to the previous commit)
- **Collaborate** (multiple engineers working on the same codebase without overwriting each other)

**Real-world example:** A deployment breaks production. You need to find what changed. You run `git log --oneline`, see the last commit changed a config value, run `git diff <commit>`, spot the mistake, and `git revert <commit>` to undo it. Production is back up in 2 minutes. **Without Git, you'd be guessing what changed.**

---

## 🔧 How does this work? (From the basics)

### What is version control?
Version control is like a **time machine for your files**. It records every change you make, so you can:
- See what changed and when
- Go back to any previous version
- See who made each change and why
- Work on changes in isolation (branches) without breaking the main version

### What is Git vs GitHub?
- **Git** = the tool that tracks changes (runs on your computer)
- **GitHub** = a website that stores your Git repositories online (so others can see and collaborate)

Think of it like: Git is your camera, GitHub is Instagram. You take photos with your camera, upload them to Instagram.

### The core concepts (with analogies)

| Concept | Analogy | Explanation |
|---|---|---|
| **Repository (repo)** | A project folder | A folder tracked by Git |
| **Commit** | A save point in a game | A snapshot of your files at a point in time, with a message |
| **Branch** | A parallel universe | An independent copy where you can make changes without affecting the main version |
| **Push** | Uploading to the cloud | Sending your local commits to GitHub |
| **Pull** | Downloading from the cloud | Getting the latest changes from GitHub to your computer |
| **Pull Request (PR)** | Asking for a grade | "I made changes on my branch, please review and merge them into main" |
| **Merge** | Combining two branches | Taking changes from one branch and putting them into another |
| **Clone** | Copying a project | Downloading the entire repo from GitHub to your computer |

### The daily workflow (this is what you'll do every day)
```
1. git pull origin main          ← Get latest changes from GitHub
2. git switch -c my-branch       ← Create a new branch for your work
3. (make changes to files)        ← Edit files normally
4. git add .                      ← Stage your changes (tell Git "I want to save these")
5. git commit -m "description"    ← Save a snapshot with a message
6. git push -u origin my-branch   ← Upload to GitHub
7. Open a Pull Request on GitHub  ← Ask for review
8. Reviewer approves → merge      ← Changes go into main
```

### Understanding commits
A commit is a snapshot. Think of it as: "I want to remember this moment."
```bash
git add app.py                    # Stage the file (prepare to save)
git add .                         # Stage ALL changed files
git commit -m "fix: handle null pointer in user API"  # Save with a message
```

**Good commit messages** (what SREs use):
```
feat(monitoring): add Prometheus scrape config for payment service
fix(nginx): increase worker_connections to handle traffic spike
docs(runbook): update database failover steps
labs(linux): lab1 - systemd service for web app
```

**Bad commit messages** (don't do this):
```
update
fix
asdfasdf
changes
final final v2
```

### Branches — why we use them
```
main (production code) ────●──────●──────●──────●──────
                            \                            ← you branch off here
                             ●──●──●  (your branch)     ← you make changes here
                            /         \
main                       ●──────●────●──  (after merge) ← changes merged back
```

**Why?** Because you never want to break `main` (the stable version). You make changes on a branch, test them, get them reviewed, and only then merge.

### Merge conflicts (you WILL encounter these)
When two people change the same line of code, Git can't decide which version to keep. It creates a "conflict" that you must resolve manually.

```bash
# When you see "CONFLICT" in git output:
# Open the file. You'll see:
<<<<<<< HEAD
your version of the line
=======
their version of the line
>>>>>>> branch-name

# Delete one version (or combine them), then remove the markers:
the correct version of the line

# Then:
git add <file>
git commit -m "resolve merge conflict in <file>"
```

---

## 📚 How to master this

1. **Use Git for everything.** Even personal projects. Make it muscle memory.
2. **Commit often, with clear messages.** Small commits are easier to review and revert.
3. **Always work on a branch.** Never commit directly to main.
4. **Practice merge conflicts.** They're scary at first but easy once you understand them.
5. **Learn `git log --oneline --graph`** to visualize your history.
6. **Use `git bisect`** to find which commit introduced a bug (powerful debugging tool).

### Resources
- **Pro Git (free book):** https://git-scm.com/book/en/v2
- **Learn Git Branching (interactive):** https://learngitbranching.js.org/
- **Git visualizer:** https://onlywei.github.io/explain-git-with-d3/

---

## ⚠️ Major issues SREs face with Git (and how to fix them)

### 1. Accidental commit to main
**What happens:** You commit to main instead of a branch, breaking the build.
**Fix:** `git reset HEAD~1` (undo the commit but keep changes), then create a branch and re-commit.

### 2. Committed a secret/password
**What happens:** You committed a password or API key. It's now in Git history.
**Fix:** **This is serious.** Remove it immediately: `git rm --cached <file>`, commit. If already pushed, you need to rewrite history (`git filter-branch` or BFG Repo-Cleaner). Then **rotate the secret** — assume it's compromised.

### 3. Merge conflict nightmares
**What happens:** Long-lived branches accumulate many conflicts.
**Fix:** Rebase frequently (`git rebase origin/main`). Keep branches short-lived. Communicate with your team.

### 4. Lost work after a bad reset
**What happens:** `git reset --hard` wiped your uncommitted changes.
**Fix:** `git reflog` — Git keeps a log of everything, even "lost" commits. Find your commit and `git checkout` it.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Create a repo, make commits on branches, open and merge PRs — the full workflow
2. **Lab 2:** Simulate and resolve merge conflicts — document the process
3. **Lab 3:** Set up a pre-commit Git hook that runs a linter before allowing commits

---

## ✅ Completion checklist

- [ ] Read this README and understand commits, branches, push, pull, PR
- [ ] Complete Lab 1: Full Git workflow → PR accepted
- [ ] Complete Lab 2: Merge conflict resolution → PR accepted
- [ ] Complete Lab 3: Git hooks → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
