# Git & Version Control — Lab 2: Merge Conflict Resolution

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Create a scenario with a merge conflict (two branches modifying the same line). Resolve the conflict manually, document the process with screenshots/output, and merge.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/git/lab2-punith`
3. Create your lab folder: `concepts/git/lab-submissions/punith/lab2/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(git): lab2 - merge conflict resolution by punith"`
6. Push: `git push -u origin labs/git/lab2-punith`
7. Open a Pull Request titled: `labs(git): lab2 - Merge Conflict Resolution — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- Conflict created intentionally; Conflict markers shown in the file; Resolution process documented; Final merge successful; README explains what conflicts are and how to resolve them
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
