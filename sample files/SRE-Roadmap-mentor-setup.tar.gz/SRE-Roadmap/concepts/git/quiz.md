# Git & Version Control — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What is the difference between Git and GitHub?

**Q2.** Explain what a commit is. What information does a commit contain?

**Q3.** What is a branch? Why do we use branches instead of committing directly to main?

**Q4.** What is the difference between `git merge` and `git rebase`? When would you use each?

**Q5.** You accidentally committed a file containing a password to Git and pushed it. Walk through exactly what you need to do.

**Q6.** What is a merge conflict? How does it happen? How do you resolve one?

**Q7.** What does `git reset --hard` do? Why is it dangerous? How can you recover from a bad reset?

**Q8.** Write the exact sequence of commands to: create a branch, make changes, commit, push, and open a PR.

**Q9.** What is `git bisect` and how does it help you find which commit introduced a bug?

**Q10.** Explain the difference between `git fetch` and `git pull`. When would you use each?

---

## How to submit your answers

1. Create a file: `concepts/git/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/git/answers`
4. Open a Pull Request titled: `quiz(git): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
