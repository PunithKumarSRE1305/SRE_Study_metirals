# Incident Response & Postmortems

> **Phase:** Advanced SRE | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** CRITICAL — this is what separates SREs from developers

---

## 🎯 Why is this used in SRE?

**Things WILL break.** The question isn't "will we have incidents?" — it's "how fast can we respond and how much do we learn?" Incident response is the most visible, most pressured part of being an SRE.

What SREs do during incidents:
- **Get paged at 3 AM** when something breaks
- **Triage the issue** — how bad is it? Who's affected?
- **Mitigate first** — stop the bleeding before finding root cause
- **Communicate** — keep stakeholders informed
- **Resolve** — fix the issue
- **Write a postmortem** — document what happened and how to prevent it

**Real-world example:** At 2:47 AM, you get paged: "Checkout API error rate 15%." You join the incident call. You check the dashboard — see a deploy happened 20 minutes ago. You check error logs — see null pointer in the new code. You roll back the deploy. Error rate drops to 0% at 2:52 AM. You write a postmortem the next day, identify that the missing test coverage let the bug through, and add a test to prevent it. **5 minutes from alert to resolution. That's an experienced SRE.**

---

## 🔧 How does this work? (From the basics)

### The incident lifecycle
```
1. DETECT    → Alert fires (monitoring catches it)
2. RESPOND   → Acknowledge the page, join the call
3. TRIAGE    → Assess severity, assign roles
4. MITIGATE  → Stop the bleeding (rollback, restart, scale up)
5. RESOLVE   → Fix the root cause
6. COMMUNICATE → Keep stakeholders informed throughout
7. POSTMORTEM → Document, learn, prevent recurrence
```

### Severity levels
| Severity | Impact | Response | Example |
|---|---|---|---|
| **SEV1** | Total outage, data loss, revenue impact | Page immediately, all hands | Production down for all users |
| **SEV2** | Major degradation, significant user impact | Page immediately | Checkout slow for 50% of users |
| **SEV3** | Minor degradation, workaround exists | Fix during business hours | One non-critical API slow |
| **SEV4** | Cosmetic, no user impact | Add to backlog | Typo in error message |

### Incident roles
| Role | Responsibility |
|---|---|
| **Incident Commander (IC)** | Coordinates the response. Does NOT fix things — manages people. |
| **Primary Responder** | Investigates and fixes the issue |
| **Secondary Responder** | Assists primary, handles communication |
| **Scribe** | Takes notes, maintains timeline |
| **Communications** | Updates status page, informs stakeholders |

> **Key rule:** The Incident Commander never touches the keyboard. They think, coordinate, and communicate.

### The golden rule: MITIGATE FIRST
```
❌ BAD: Spend 30 minutes finding the root cause while users are affected
✅ GOOD: Roll back the deploy in 2 minutes, THEN find the root cause

Mitigation > Root Cause (during the incident)
Root Cause > Mitigation (during the postmortem)
```

### On-call rotation
```
Week 1: Alice (primary), Bob (secondary)
Week 2: Bob (primary), Charlie (secondary)
Week 3: Charlie (primary), Alice (secondary)

Primary   → First to respond, handles the incident
Secondary → Backup if primary doesn't respond in 5 min
```

### Blameless postmortems (this is culture, not just process)
```
❌ Blame culture:
  "Who broke production? John pushed the bad code. John needs to be more careful."

✅ Blameless culture:
  "What allowed the bad code to reach production?
   - No test coverage for that code path
   - No integration test for that API
   - No canary deployment to catch it early
   Let's fix the SYSTEM, not blame the person."
```

### Postmortem template
```markdown
# Postmortem: [Incident Title]

## Summary
One-sentence description of what happened.

## Impact
- Duration: [start time] to [end time] (X minutes)
- Users affected: [number or percentage]
- Revenue impact: [if applicable]

## Timeline (all times in UTC)
- 02:47 — Alert fired: Checkout API error rate > 10%
- 02:48 — Alice acknowledged page, joined incident call
- 02:50 — Identified recent deploy as likely cause
- 02:52 — Rolled back deploy, error rate dropping
- 02:55 — Error rate at 0%, incident resolved

## Root Cause
The deploy introduced a null pointer in the payment validation code.
The code path was not covered by any test.

## What went well
- Alert fired quickly (within 1 minute of impact)
- Rollback was fast (3 minutes)

## What went badly
- Bug reached production (no test coverage)
- No canary deployment (full rollout)

## Action items
- [ ] Add test for payment validation code path — Alice, by [date]
- [ ] Implement canary deployment strategy — Bob, by [date]
- [ ] Add null check in payment validation — Charlie, by [date]
```

### Key metrics
| Metric | Full name | What it measures |
|---|---|---|
| **MTTD** | Mean Time To Detect | How long until you notice something is wrong |
| **MTTA** | Mean Time To Acknowledge | How long until someone responds to the alert |
| **MTTR** | Mean Time To Resolve | How long until the issue is fixed |
| **MTBF** | Mean Time Between Failures | How often incidents happen |

---

## 📚 How to master this

1. **Practice with game days** — intentionally break things and practice responding.
2. **Write postmortems for every incident** — even small ones.
3. **Review other people's postmortems** — learn from others' mistakes.
3. **Read the SRE Book chapters on incident response and postmortems.**
4. **Learn to stay calm under pressure** — panic makes everything worse.
5. **Practice communication** — clear, concise updates during incidents.

### Resources
- **Google SRE Book — Incident Response:** https://sre.google/sre-book/managing-incidents/
- **Google SRE Book — Postmortems:** https://sre.google/sre-book/postmortem-culture/
- **PagerDuty incident response:** https://response.pagerduty.com/

---

## ⚠️ Major issues SREs face with incidents (and how to fix them)

### 1. No runbook → engineer doesn't know what to do
**Fix:** Write runbooks for every common alert. Keep them updated. Runbooks should have exact commands.

### 2. Alert fires but nobody responds → user reports the issue
**Fix:** Clear on-call rotation. Escalation policy (secondary responder if primary doesn't acknowledge in 5 min). Test paging regularly.

### 3. Long incidents → can't find root cause
**Fix:** Mitigate first. Use dashboards to narrow down. Check recent changes (deploys, config changes). Use distributed tracing.

### 4. Same incident happens again → no learning from postmortems
**Fix:** Track action items. Assign owners and deadlines. Review open action items in team meetings. A postmortem without action items is useless.

### 5. Blame culture → people hide mistakes
**Fix:** Blameless postmortems. Focus on systems, not people. Celebrate honest reporting. "I broke production" should be met with "thanks for telling us, let's fix the system."

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Write a runbook for a common alert (e.g., "high error rate on API") — include exact commands and steps
2. **Lab 2:** Write a full blameless postmortem for a simulated incident using the template
3. **Lab 3:** Run a game day — inject a failure into a running system, respond using your runbook, and write the postmortem

---

## ✅ Completion checklist

- [ ] Read this README and understand incident lifecycle, severity, roles, postmortems
- [ ] Complete Lab 1: Write a runbook → PR accepted
- [ ] Complete Lab 2: Write a postmortem → PR accepted
- [ ] Complete Lab 3: Game day exercise → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
