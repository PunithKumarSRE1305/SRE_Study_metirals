# Incident Response & Postmortems — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What are the 7 steps of the incident lifecycle? Explain each.

**Q2.** What is the role of the Incident Commander? Why should they NOT fix the issue themselves?

**Q3.** Explain the difference between SEV1, SEV2, SEV3, and SEV4. Give an example of each.

**Q4.** What does 'mitigate first' mean? Why is it more important than finding root cause during an incident?

**Q5.** What is a blameless postmortem? Why is blamelessness important? What happens in a blame culture?

**Q6.** Define MTTD, MTTA, and MTTR. Why does SRE track these metrics?

**Q7.** What is a runbook? What makes a good runbook vs a bad runbook?

**Q8.** Describe an on-call rotation. What is the difference between primary and secondary on-call?

**Q9.** During an incident, how and when should you communicate with stakeholders?

**Q10.** An incident happened because a developer pushed bad code. How do you structure the postmortem to prevent recurrence without blaming the developer?

---

## How to submit your answers

1. Create a file: `concepts/incident-response/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/incident-response/answers`
4. Open a Pull Request titled: `quiz(incident-response): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
