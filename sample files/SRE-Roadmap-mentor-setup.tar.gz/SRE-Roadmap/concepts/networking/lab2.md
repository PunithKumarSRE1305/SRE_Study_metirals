# Networking Fundamentals — Lab 2: Network Troubleshooting

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Diagnose 5 simulated network problems (DNS failure, port conflict, firewall block, high latency, broken TLS) using tcpdump, traceroute, dig, and curl. Document each diagnosis step by step.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/networking/lab2-punith`
3. Create your lab folder: `concepts/networking/lab-submissions/punith/lab2/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(networking): lab2 - network troubleshooting by punith"`
6. Push: `git push -u origin labs/networking/lab2-punith`
7. Open a Pull Request titled: `labs(networking): lab2 - Network Troubleshooting — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- All 5 problems diagnosed; Correct tools used for each; Root cause documented; Fixes applied and verified
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
