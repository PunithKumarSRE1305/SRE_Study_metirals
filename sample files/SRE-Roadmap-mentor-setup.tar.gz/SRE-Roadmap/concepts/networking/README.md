# Networking Fundamentals

> **Phase:** Foundation | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** CRITICAL — you can't fix what you can't see

---

## 🎯 Why is this used in SRE?

**Every service is a network service.** If you don't understand networking, you can't:
- Figure out why a user can't reach your website
- Diagnose why a database connection is failing
- Set up a load balancer
- Understand why latency is high
- Troubleshoot DNS issues
- Configure firewalls correctly

**Real-world example:** Users report "the website is slow." You need to figure out: Is it DNS resolution? Is it the load balancer? Is it network latency between the web server and database? Is it a firewall dropping packets? Without networking knowledge, you're guessing. With it, you run `traceroute`, `dig`, `tcpdump`, and `curl` to pinpoint the issue in minutes.

---

## 🔧 How does this work? (From the basics)

### The OSI Model — 7 layers (memorize this)
Think of it as a stack where each layer has a job:

```
Layer 7: Application    ← HTTP, DNS, SSH (what users interact with)
Layer 6: Presentation   ← TLS/SSL, data formatting
Layer 5: Session        ← Managing connections
Layer 4: Transport      ← TCP, UDP (reliability, ports)
Layer 3: Network        ← IP, routing (IP addresses)
Layer 2: Data Link      ← MAC addresses, switches
Layer 1: Physical       ← Cables, Wi-Fi signals (the actual wires)
```

**Mnemonic:** "All People Seem To Need Data Processing" (Application, Presentation, Session, Transport, Network, Data Link, Physical)

### TCP vs UDP (you must understand this deeply)
| | TCP | UDP |
|---|---|---|
| Connection | Connected (handshake first) | Connectionless (just send) |
| Reliability | Guaranteed delivery | Best effort (may lose packets) |
| Order | Packets arrive in order | No guarantee of order |
| Speed | Slower (overhead) | Faster (no overhead) |
| Used for | Web (HTTP), SSH, email | DNS, video streaming, games |
| Analogy | Phone call (establish connection, talk, hang up) | Postal mail (just send it, hope it arrives) |

### TCP 3-way handshake (this is asked in EVERY SRE interview)
```
Client                    Server
  |                          |
  | --- SYN (can we talk?) → |
  |                          |
  | ← SYN-ACK (yes, sure) -- |
  |                          |
  | --- ACK (great, starting) → |
  |                          |
  | === DATA now flows ===   |
```

### IP Addressing
```
IPv4 address: 192.168.1.100 (4 numbers, 0-255 each)
Subnet mask:  255.255.255.0 (determines network size)
CIDR:         192.168.1.0/24 (means first 24 bits are the network)

Private IP ranges (used inside networks, not on the internet):
  10.0.0.0/8        (10.x.x.x)
  172.16.0.0/12     (172.16.x.x - 172.31.x.x)
  192.168.0.0/16    (192.168.x.x)
```

### Ports (how multiple services share one IP)
```
IP address = which computer
Port = which service on that computer

Common ports you MUST memorize:
  20/21  → FTP
  22     → SSH
  25     → SMTP (email)
  53     → DNS
  80     → HTTP
  443    → HTTPS
  3306   → MySQL
  5432   → PostgreSQL
  6379   → Redis
  8080   → Common alternative HTTP
  9090   → Prometheus
```

### DNS (Domain Name System) — the internet's phone book
```
User types: www.example.com
  ↓
DNS lookup: "What IP is www.example.com?"
  ↓
DNS server responds: "93.184.216.34"
  ↓
Browser connects to 93.184.216.34 on port 443
```

Commands to troubleshoot DNS:
```bash
dig www.example.com           # Full DNS query details
dig +short www.example.com    # Just the IP
nslookup www.example.com      # Simpler DNS lookup
host www.example.com          # Simplest DNS lookup
```

### HTTP — how the web works
```
Request (client → server):
  GET /api/users HTTP/1.1
  Host: api.example.com
  Accept: application/json

Response (server → client):
  HTTP/1.1 200 OK
  Content-Type: application/json
  {"users": [...]}
```

HTTP status codes you must know:
```
2xx = Success     (200 OK, 201 Created, 204 No Content)
3xx = Redirect    (301 Moved, 302 Found, 304 Not Modified)
4xx = Client error (400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found, 429 Too Many Requests)
5xx = Server error (500 Internal Server Error, 502 Bad Gateway, 503 Service Unavailable, 504 Gateway Timeout)
```

### Diagnostic commands (your networking toolkit)
```bash
ping 8.8.8.8                    # Is the host reachable?
traceroute google.com           # What path do packets take?
ss -tlnp                        # What ports are listening? (modern netstat)
netstat -tlnp                   # Same, older tool
curl -v http://localhost:8080   # Test HTTP, show details
tcpdump -i eth0 port 80         # Capture packets on port 80
dig example.com                 # DNS lookup
nslookup example.com            # DNS lookup (simpler)
telnet host port                # Can I connect to this port?
nc -zv host port                # Netcat — check if port is open
```

---

## 📚 How to master this

1. **Draw network diagrams.** Visualizing how packets flow is key.
2. **Use the diagnostic commands daily.** Every time a service is "down," practice with `ss`, `curl`, `dig`.
3. **Set up a home lab.** Two VMs, a virtual network, practice routing and firewalls.
4. **Capture packets with tcpdump/Wireshark.** See what actually goes over the wire.
5. **Complete the 3 labs** — they're designed to force you to use these tools.

### Resources
- **Networking for SREs (YouTube):** search "Computer Networks" by "PowerCert Animated Videos"
- **DNS explained (YouTube):** search "How DNS works"
- **TCP/IP Illustrated (book):** the definitive reference
- **Wireshark (free tool):** https://www.wireshark.org/ — see packets visually

---

## ⚠️ Major issues SREs face with networking (and how to fix them)

### 1. DNS resolution failure → service unreachable
**Symptoms:** "Can't connect to database," intermittent failures
**Diagnose:** `dig`, `nslookup`, check `/etc/resolv.conf`, check DNS server health
**Fix:** Fix DNS records, add fallback DNS servers, implement DNS caching, use IP addresses in emergencies

### 2. Port conflict → service won't start
**Symptoms:** "Address already in use"
**Diagnose:** `ss -tlnp | grep <port>` — find what's using the port
**Fix:** Kill the conflicting process or change the port

### 3. High latency → slow user experience
**Symptoms:** Users report slowness, high response times
**Diagnose:** `traceroute`, `ping`, `tcpdump` to find where delay is introduced
**Fix:** Optimize routing, move services closer (CDN, multi-region), fix network configuration

### 4. Firewall blocking traffic → connection refused
**Symptoms:** Works from one network but not another
**Diagnose:** `telnet host port`, check firewall rules (`iptables -L`, `ufw status`)
**Fix:** Add the correct firewall rule. Document all required ports.

### 5. TLS/certificate issues → HTTPS fails
**Symptoms:** "SSL certificate error," browser warnings
**Diagnose:** `openssl s_client -connect host:443`, check cert expiry
**Fix:** Renew certificates, fix certificate chain, update trust store

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Map a network — scan ports, identify services, document the topology
2. **Lab 2:** Network troubleshooting lab — diagnose 5 simulated network problems using diagnostic tools
3. **Lab 3:** Set up nginx as a reverse proxy with TLS in front of a web application

---

## ✅ Completion checklist

- [ ] Read this README and understand OSI model, TCP/UDP, DNS, HTTP
- [ ] Complete Lab 1: Network mapping → PR accepted
- [ ] Complete Lab 2: Network troubleshooting → PR accepted
- [ ] Complete Lab 3: Reverse proxy with TLS → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
