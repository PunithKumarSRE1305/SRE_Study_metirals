# Networking Fundamentals — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** Draw or describe the OSI 7-layer model. Give one example protocol for each layer.

**Q2.** Explain the TCP 3-way handshake. Why is it called 'connection-oriented'?

**Q3.** What is the difference between TCP and UDP? Give one real-world example of each.

**Q4.** What does DNS do? Walk through what happens when you type www.google.com in a browser.

**Q5.** How do you check if a remote server's port 443 is reachable? (give two different commands)

**Q6.** Explain HTTP status codes 200, 301, 404, 500, 502, and 503. What does each mean?

**Q7.** What is a reverse proxy? How does it differ from a forward proxy? Why do SREs use them?

**Q8.** What is a subnet mask? What does 255.255.255.0 mean? How many hosts can it support?

**Q9.** You can SSH into a server but can't reach it on port 443 from your laptop. Walk through how you diagnose this.

**Q10.** What is TLS? Why do we use it? What happens during a TLS handshake?

---

## How to submit your answers

1. Create a file: `concepts/networking/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/networking/answers`
4. Open a Pull Request titled: `quiz(networking): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
