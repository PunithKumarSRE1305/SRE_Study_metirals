# CI/CD Pipelines

> **Phase:** Advanced SRE | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — automated delivery is the SRE way

---

## 🎯 Why is this used in SRE?

**SREs build pipelines that safely and automatically deliver code to production.** No manual deployments, no SSH-ing into servers to update code. Everything automated, tested, and tracked.

What SREs do with CI/CD:
- **Build pipelines** that run tests on every commit
- **Package applications** into Docker images automatically
- **Deploy to staging** automatically, to production with approval
- **Roll back automatically** when health checks fail
- **Implement deployment strategies** (blue-green, canary) for zero-downtime

**Real-world example:** A developer pushes code. The CI pipeline runs unit tests (pass), builds a Docker image, pushes to registry, deploys to staging, runs integration tests (pass), then deploys to production using a canary strategy — 5% of traffic first, monitor for 10 minutes, if healthy, 100%. If errors spike, automatic rollback. **The developer just pushed code. Everything else was automated.**

---

## 🔧 How does this work? (From the basics)

### CI vs CD vs CD
```
CI  = Continuous Integration     → Merge code frequently, run tests
CD₁ = Continuous Delivery        → Code is always ready to deploy (manual button)
CD₂ = Continuous Deployment      → Code automatically deploys to production
```

### A GitHub Actions workflow (what you'll build)
```yaml
# .github/workflows/deploy.yml
name: Build and Deploy

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Run tests
        run: pytest

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build Docker image
        run: docker build -t myapp:${{ github.sha }} .
      - name: Push to registry
        run: |
          docker push myregistry/myapp:${{ github.sha }}

  deploy:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to Kubernetes
        run: |
          kubectl set image deployment/myapp myapp=myregistry/myapp:${{ github.sha }}
          kubectl rollout status deployment/myapp
```

### Pipeline stages (the standard flow)
```
Code Push → [Lint] → [Test] → [Build] → [Scan] → [Deploy Staging] → [Integration Test] → [Deploy Prod] → [Verify]
     ↑                                                                                              |
     └──────────────────── Rollback if any stage fails ────────────────────────────────────────────┘
```

### Deployment strategies
| Strategy | How it works | Downtime | Rollback |
|---|---|---|---|
| **Rolling** | Gradually replace old instances with new | None | Roll back to previous image |
| **Blue-green** | Run new version alongside old, switch traffic | None | Switch back to old (instant) |
| **Canary** | Send small % of traffic to new version, increase if healthy | None | Route all traffic back to old |
| **Recreate** | Stop old, start new | YES | Redeploy old (slow) |

```
Blue-Green:
  Blue (current) ← 100% traffic
  Green (new)    ← 0% traffic, being tested

  Switch: Blue ← 0%, Green ← 100%
  If Green fails: switch back to Blue instantly

Canary:
  Old version ← 95% traffic
  New version ← 5% traffic (monitor error rate)
  If healthy → 25% → 50% → 100%
  If unhealthy → back to 0%
```

### GitOps (the modern approach)
```
Traditional: CI pipeline pushes to Kubernetes (push model)
GitOps:      Operator watches Git, pulls changes to Kubernetes (pull model)

Git is the single source of truth.
Any change in Git → automatically applied to the cluster.
```

---

## 📚 How to master this

1. **Set up GitHub Actions** for your repo — it's free and built-in.
2. **Build a complete pipeline** — test → build → deploy.
3. **Practice rollbacks** — deploy, break, roll back.
4. **Try different strategies** — rolling, blue-green, canary.
5. **Monitor your pipelines** — a broken pipeline blocks all deploys.

### Resources
- **GitHub Actions docs:** https://docs.github.com/en/actions
- **ArgoCD (GitOps):** https://argo-cd.readthedocs.io/
- **Spinnaker (multi-cloud CD):** https://spinnaker.io/

---

## ⚠️ Major issues SREs face with CI/CD (and how to fix them)

### 1. Pipeline is slow → developers wait, productivity drops
**Fix:** Cache dependencies. Parallelize jobs. Use incremental builds. Only run relevant tests.

### 2. Flaky tests → pipeline fails randomly
**Fix:** Identify and fix flaky tests. Quarantine them. Run tests in isolation.

### 3. Bad deploy reaches production → outage
**Fix:** Always deploy with health checks. Use canary strategy. Automatic rollback on error rate increase.

### 4. Pipeline has too many manual approvals → bottleneck
**Fix:** Automate testing. Only require approval for production. Use progressive delivery.

### 5. No rollback mechanism → stuck with bad version
**Fix:** Always have a rollback plan. `kubectl rollout undo`. Blue-green for instant rollback.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Build a CI pipeline with GitHub Actions — lint, test, build Docker image, push to registry
2. **Lab 2:** Add a CD stage that deploys to Kubernetes with a rolling update strategy
3. **Lab 3:** Implement a canary deployment with automatic rollback on health check failure

---

## ✅ Completion checklist

- [ ] Read this README and understand CI/CD, deployment strategies, pipelines, GitOps
- [ ] Complete Lab 1: CI pipeline → PR accepted
- [ ] Complete Lab 2: CD to Kubernetes → PR accepted
- [ ] Complete Lab 3: Canary with rollback → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
