# CI/CD Pipelines — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What is the difference between Continuous Integration, Continuous Delivery, and Continuous Deployment?

**Q2.** Draw a standard CI/CD pipeline. Label each stage and explain what happens there.

**Q3.** Explain blue-green deployment. How does it achieve zero downtime? How do you roll back?

**Q4.** Explain canary deployment. How does it differ from blue-green? When is canary better?

**Q5.** What is GitOps? How does it differ from traditional push-based deployment?

**Q6.** Write a GitHub Actions workflow that runs tests on every push. Explain each part.

**Q7.** What is an automatic rollback? How does it work? What triggers it?

**Q8.** Your CI pipeline takes 25 minutes. How would you reduce it to under 10 minutes?

**Q9.** What is a flaky test? Why is it dangerous? How do you deal with it?

**Q10.** A bad deploy reached production and caused an outage. How should your pipeline have prevented this? What do you add?

---

## How to submit your answers

1. Create a file: `concepts/ci-cd/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/ci-cd/answers`
4. Open a Pull Request titled: `quiz(ci-cd): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
