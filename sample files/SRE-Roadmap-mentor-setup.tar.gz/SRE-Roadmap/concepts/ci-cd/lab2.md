# CI/CD Pipelines — Lab 2: CD to Kubernetes

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Extend the pipeline with a deploy stage that updates a Kubernetes deployment with the new image. Use kubectl rollout status to verify. Document the deployment process.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/ci-cd/lab2-punith`
3. Create your lab folder: `concepts/ci-cd/lab-submissions/punith/lab2/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(ci-cd): lab2 - cd to kubernetes by punith"`
6. Push: `git push -u origin labs/ci-cd/lab2-punith`
7. Open a Pull Request titled: `labs(ci-cd): lab2 - CD to Kubernetes — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- Deploy stage added to pipeline; K8s deployment updated with new image; Rollout status checked; Deployment verified; README documents the CD process and rollback steps
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
