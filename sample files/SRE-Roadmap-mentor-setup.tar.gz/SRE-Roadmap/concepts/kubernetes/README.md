# Kubernetes

> **Phase:** Infrastructure | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — the standard for container orchestration

---

## 🎯 Why is this used in SRE?

**Kubernetes (K8s) is how modern companies run containerized applications at scale.** It handles:
- **Self-healing:** Restarts failed containers automatically
- **Auto-scaling:** Scales up when traffic increases, down when it decreases
- **Rolling updates:** Deploys new versions with zero downtime
- **Service discovery:** Services find each other automatically
- **Load balancing:** Distributes traffic across multiple instances

**Real-world example:** You deploy a new version of your API. Kubernetes gradually replaces old pods with new ones, running health checks on each new pod before sending traffic to it. If a new pod fails the health check, Kubernetes stops the rollout automatically. **Zero downtime, automatic rollback on failure. That's why every major company uses Kubernetes.**

---

## 🔧 How does this work? (From the basics)

### Kubernetes architecture
```
┌─────────────────── CONTROL PLANE ───────────────────┐
│  API Server    → The front door (everything goes    │
│                  through it)                         │
│  Scheduler     → Decides which node runs which pod   │
│  Controller Mgr → Watches state, makes things happen │
│  etcd         → The brain (stores all cluster state) │
└──────────────────────────────────────────────────────┘
          │ manages
          ▼
┌─────────── NODE 1 ──────────┐  ┌─────────── NODE 2 ──────────┐
│  kubelet (talks to control   │  │  kubelet                    │
│  plane)                      │  │                              │
│  kube-proxy (networking)     │  │  kube-proxy                  │
│  ┌────┐ ┌────┐ ┌────┐       │  │  ┌────┐ ┌────┐              │
│  │Pod │ │Pod │ │Pod │       │  │  │Pod │ │Pod │              │
│  │ A  │ │ B  │ │ C  │       │  │  │ D  │ │ E  │              │
│  └────┘ └────┘ └────┘       │  │  └────┘ └────┘              │
│  (containers run in pods)    │  │                              │
└──────────────────────────────┘  └──────────────────────────────┘
```

### Core objects (memorize these)
| Object | What it is | Analogy |
|---|---|---|
| **Pod** | Smallest unit. Contains 1+ containers | A single apartment |
| **Deployment** | Manages pods (how many, what image) | A building manager |
| **Service** | Stable network endpoint for pods | A mailing address |
| **ConfigMap** | Configuration data | A settings file |
| **Secret** | Sensitive data (passwords) | A locked safe |
| **Namespace** | Virtual cluster (for isolation) | A floor in a building |
| **Ingress** | HTTP/HTTPS routing from outside | A reception desk |

### kubectl — your main tool
```bash
# Get information
kubectl get pods                    # List all pods
kubectl get pods -o wide            # More details
kubectl get deployments             # List deployments
kubectl get services                # List services
kubectl get all                     # Everything in the namespace

# Describe (troubleshooting)
kubectl describe pod <pod-name>     # Detailed info about a pod
kubectl describe deployment <name>  # Detailed info about a deployment

# Logs
kubectl logs <pod-name>             # View pod logs
kubectl logs -f <pod-name>          # Follow logs (tail -f)
kubectl logs <pod-name> --previous  # Logs from before the crash

# Execute inside a pod
kubectl exec -it <pod-name> -- bash

# Apply changes
kubectl apply -f deployment.yaml    # Create/update from file
kubectl delete -f deployment.yaml   # Delete from file

# Scale
kubectl scale deployment <name> --replicas=5

# Port forward (for local testing)
kubectl port-forward svc/myservice 8080:80
```

### A Deployment YAML (this is what you'll write)
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: myapp
  labels:
    app: myapp
spec:
  replicas: 3                         # Run 3 copies
  selector:
    matchLabels:
      app: myapp
  template:                           # The pod template
    metadata:
      labels:
        app: myapp
    spec:
      containers:
      - name: myapp
        image: myapp:1.0
        ports:
        - containerPort: 8080
        resources:
          requests:                   # Minimum resources
            cpu: 100m
            memory: 128Mi
          limits:                     # Maximum resources
            cpu: 500m
            memory: 512Mi
        livenessProbe:                # Is the app alive?
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
        readinessProbe:               # Is the app ready to serve?
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
```

### A Service YAML
```yaml
apiVersion: v1
kind: Service
metadata:
  name: myapp
spec:
  type: ClusterIP              # Internal only (use LoadBalancer for external)
  selector:
    app: myapp                 # Routes traffic to pods with this label
  ports:
  - port: 80                   # Service port
    targetPort: 8080           # Container port
```

### Health checks (probes) — critical for reliability
| Probe | What it checks | What happens on failure |
|---|---|---|
| **Liveness** | Is the app alive? | Pod is restarted |
| **Readiness** | Is the app ready to serve traffic? | Pod is removed from load balancer |
| **Startup** | Has the app finished starting? | Other probes are disabled until this passes |

### Horizontal Pod Autoscaler (HPA)
```yaml
# Automatically scales pods based on CPU usage
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: myapp-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: myapp
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70    # Scale up if CPU > 70%
```

---

## 📚 How to master this

1. **Use minikube or kind** (Kubernetes in Docker) for local practice — it's free.
2. **Deploy everything** — every app you dockerize, deploy to K8s.
3. **Practice kubectl daily** — it should become muscle memory.
4. **Break pods on purpose** — kill them, see K8s restart them.
5. **Practice rolling updates and rollbacks.**
6. **Read the Kubernetes docs** — they're excellent.

### Resources
- **Kubernetes docs:** https://kubernetes.io/docs/home/
- **Interactive tutorial:** https://kubernetes.io/docs/tutorials/
- **Kubernetes the Hard Way (advanced):** https://github.com/kelseyhightower/kubernetes-the-hard-way
- **Killercoda (free scenarios):** https://killercoda.com/

---

## ⚠️ Major issues SREs face with Kubernetes (and how to fix them)

### 1. CrashLoopBackOff → pod keeps crashing and restarting
**Diagnose:** `kubectl describe pod <name>`, `kubectl logs <name> --previous`
**Fix:** Usually a bad config, missing env var, or app error. Check the logs from before the crash.

### 2. Pending pods → pods won't schedule
**Diagnose:** `kubectl describe pod <name>` — look at Events section
**Fix:** Usually insufficient resources. Check node capacity, resource requests, or node selectors.

### 3. OOMKilled → container killed for using too much memory
**Diagnose:** `kubectl describe pod <name>` — look for "OOMKilled"
**Fix:** Increase memory limit, or fix the memory leak in the app.

### 4. Service has no endpoints → traffic can't reach pods
**Diagnose:** `kubectl get endpoints <service-name>`
**Fix:** Check that pod labels match the service selector. Check readiness probes.

### 5. etcd issues → cluster state problems
**Fix:** Monitor etcd health. Back up etcd regularly. etcd is the single point of failure — run it as a cluster.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Deploy a simple app on minikube — Pod, Deployment, Service, ConfigMap
2. **Lab 2:** Deploy a 3-tier app with health probes, resource limits, and a database
3. **Lab 3:** Set up Horizontal Pod Autoscaler, load test to trigger scaling, document results

---

## ✅ Completion checklist

- [ ] Read this README and understand Pods, Deployments, Services, probes, kubectl
- [ ] Complete Lab 1: Simple app deployment → PR accepted
- [ ] Complete Lab 2: 3-tier app with probes → PR accepted
- [ ] Complete Lab 3: HPA + load testing → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
