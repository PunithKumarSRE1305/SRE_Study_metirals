# Kubernetes — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What is the difference between a Pod and a Deployment? Why do we use Deployments?

**Q2.** Explain the difference between liveness, readiness, and startup probes. When would you use each?

**Q3.** What is a Kubernetes Service? What are the differences between ClusterIP, NodePort, and LoadBalancer?

**Q4.** Write a kubectl command to view the logs of a crashed pod (including logs from before the crash).

**Q5.** What is a ConfigMap? How does it differ from a Secret? When would you use each?

**Q6.** What are resource requests and limits? Why are they important? What happens when a container exceeds its memory limit?

**Q7.** Your pod is in a CrashLoopBackOff state. Walk through your troubleshooting process.

**Q8.** What is a Horizontal Pod Autoscaler? How does it decide when to scale?

**Q9.** Explain how a Kubernetes Service routes traffic to the correct Pods.

**Q10.** What is etcd? Why is it critical to the Kubernetes cluster? How do you back it up?

---

## How to submit your answers

1. Create a file: `concepts/kubernetes/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/kubernetes/answers`
4. Open a Pull Request titled: `quiz(kubernetes): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
