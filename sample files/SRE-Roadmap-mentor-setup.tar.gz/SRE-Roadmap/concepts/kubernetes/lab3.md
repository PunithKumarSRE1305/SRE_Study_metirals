# Kubernetes — Lab 3: HPA with Load Testing

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Set up a Horizontal Pod Autoscaler for a deployment. Install a load testing tool (e.g., hey, k6). Run a load test that triggers auto-scaling. Document the scaling behavior with before/after pod counts.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/kubernetes/lab3-punith`
3. Create your lab folder: `concepts/kubernetes/lab-submissions/punith/lab3/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(kubernetes): lab3 - hpa with load testing by punith"`
6. Push: `git push -u origin labs/kubernetes/lab3-punith`
7. Open a Pull Request titled: `labs(kubernetes): lab3 - HPA with Load Testing — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- HPA configured; Load test run; Pods scaled up under load; Pods scaled down after load removed; Scaling behavior documented with screenshots; README explains the HPA configuration
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
