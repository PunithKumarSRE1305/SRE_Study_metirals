# SRE Practices — SLOs, SLIs, Error Budgets

> **Phase:** Advanced SRE | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** CRITICAL — this IS SRE. Everything else supports this.

---

## 🎯 Why is this used in SRE?

**This concept is the heart of SRE.** SLOs (Service Level Objectives), SLIs (Service Level Indicators), and error budgets are what make SRE different from traditional operations. They answer the fundamental question: **"How reliable is reliable enough?"**

What SREs do with SLOs:
- **Define what "reliable" means** for each service (in measurable numbers)
- **Track whether services meet their targets** (SLO compliance)
- **Use error budgets** to balance reliability vs. feature velocity
- **Alert based on error budget burn rate** (not arbitrary thresholds)
- **Make data-driven decisions** about when to invest in reliability vs. features

**Real-world example:** Your API has an SLO of 99.9% availability (8.76 hours of downtime allowed per year). After a new feature launch, error rate increases and you burn 30% of your error budget in one week. The SRE team tells product: "We're burning our error budget too fast. All new feature deploys are frozen until we fix the reliability issue." **This is the SRE's superpower — data-backed authority to prioritize reliability.**

---

## 🔧 How does this work? (From the basics)

### The hierarchy
```
SLA (Service Level Agreement)
  ↓ (what we promise customers, in a contract, with penalties)
SLO (Service Level Objective)
  ↓ (what we aim for internally — tighter than SLA)
SLI (Service Level Indicator)
  ↓ (the actual measurement — what we track)
```

### SLI — the measurement
An SLI is a ratio of good events to total events:
```
SLI = (good events) / (total events)

Examples:
  Availability SLI = (successful HTTP requests) / (total HTTP requests)
  Latency SLI = (requests under 500ms) / (total requests)
  Correctness SLI = (correct API responses) / (total API responses)
```

### SLO — the target
An SLO is the target for your SLI:
```
SLO: 99.9% of requests succeed over 30 days
SLO: 99% of requests complete in under 500ms over 7 days

Common SLO levels:
  99%    = 7.2 hours downtime/month    (internal tools)
  99.9%  = 43.2 minutes downtime/month (user-facing services)
  99.99% = 4.3 minutes downtime/month  (critical services)
  99.999% = 26 seconds downtime/month  (life-critical, extremely hard)
```

### Error budget — the key concept
```
If your SLO is 99.9%:
  Error budget = 100% - 99.9% = 0.1%
  
  Over 30 days (43,200 minutes):
  0.1% = 43.2 minutes of allowed downtime

  Error budget = 43.2 minutes/month

How to think about it:
  ✅ Error budget remaining → team can ship features, take risks
  ⚠️ Error budget depleting fast → slow down, focus on reliability
  ❌ Error budget exhausted → freeze feature deploys, fix reliability
```

### The SRE equation
```
Reliability = 100% - Error Rate

If SLO = 99.9%, then acceptable error rate = 0.1%

Error budget burn rate:
  If you're failing 1% of requests but SLO allows 0.1%:
  Burn rate = 1% / 0.1% = 10x
  (You're burning budget 10x faster than allowed)
  
  At 10x burn rate, you'll exhaust your monthly budget in 3 days.
```

### Burn-rate alerting (the SRE way to alert)
```yaml
# Multi-window, multi-burn-rate alerting
# Fast burn (page immediately):
- 14.4x burn rate over 1h  → page (exhausts budget in 2 hours)
- 6x burn rate over 2h     → page (exhausts budget in 5 hours)

# Slow burn (ticket, not page):
- 3x burn rate over 6h     → ticket (exhausts budget in 1 day)
- 1x burn rate over 3d    → ticket (exhausts budget in 3 days)
```

### The 4 golden signals (monitor what matters)
| Signal | What it measures | Example metric |
|---|---|---|
| **Latency** | How long requests take | `http_request_duration_seconds` |
| **Traffic** | How much demand | `http_requests_total` (rate) |
| **Errors** | How often things fail | Error rate = 5xx / total |
| **Saturation** | How full the system is | CPU %, memory %, disk % |

### Choosing SLIs (the right way)
```
❌ BAD SLI: "Server CPU should be under 80%"
  (Users don't care about CPU — they care about their requests working)

✅ GOOD SLI: "99% of API requests succeed in under 500ms"
  (Directly measures user experience)
```

### Error budget policy (make it concrete)
```
GREEN (budget > 50% remaining):
  → Normal feature development
  → Can take risks, push new features

YELLOW (budget 25-50% remaining):
  → Proceed with caution
  → Extra review for risky changes

RED (budget < 25% remaining):
  → Feature freeze
  → All engineering effort goes to reliability
  → No new features until budget recovers
```

---

## 📚 How to master this

1. **Define SLIs for a real service** — what does "good" look like for the user?
2. **Set SLOs** — what's realistic? What do users expect?
3. **Implement burn-rate alerting** in Prometheus.
4. **Create an SLO dashboard** showing budget remaining.
5. **Write an error budget policy** — what happens when budget runs out?
6. **Read the SRE Workbook** — chapters on SLOs are essential.

### Resources
- **Google SRE Book — Service Level Objectives:** https://sre.google/sre-book/service-level-objectives/
- **Google SRE Workbook — Implementing SLOs:** https://sre.google/workbook/implementing-slos/
- **Sloth (SLO generator for Prometheus):** https://sloth.dev/

---

## ⚠️ Major issues SREs face with SLOs (and how to fix them)

### 1. SLOs set too high (100%) → impossible to maintain, no innovation
**Fix:** 100% is the wrong target. Choose SLOs based on user expectations. 99.9% is usually enough. The error budget is FEATURE for development velocity.

### 2. SLIs don't measure user experience → SLOs are meaningless
**Fix:** Measure what users care about: latency, availability, correctness. Not internal metrics like CPU.

### 3. No error budget policy → SLOs exist but nobody acts on them
**Fix:** Write a clear policy. When budget is low, freeze features. Make it enforceable, not a suggestion.

### 4. Alerting on arbitrary thresholds → alert fatigue
**Fix:** Use burn-rate-based alerting. Alert when you're burning budget too fast, not when CPU > 80%.

### 5. SLOs never reviewed → they become stale
**Fix:** Review SLOs quarterly. Adjust based on user feedback and business needs.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Define SLIs and SLOs for a sample service, document them, and justify your choices
2. **Lab 2:** Implement burn-rate alerting in Prometheus — fast burn (page) and slow burn (ticket)
3. **Lab 3:** Build a complete SRE dashboard — SLO tracking, error budget remaining, burn rate, 4 golden signals, and alerts

---

## ✅ Completion checklist

- [ ] Read this README and understand SLIs, SLOs, error budgets, burn rate, golden signals
- [ ] Complete Lab 1: Define SLIs/SLOs → PR accepted
- [ ] Complete Lab 2: Burn-rate alerting → PR accepted
- [ ] Complete Lab 3: SRE dashboard → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
