# SRE Practices — SLOs, SLIs, Error Budgets — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** Define SLI, SLO, and SLA. How do they relate to each other?

**Q2.** What is an error budget? If your SLO is 99.9%, what is your monthly error budget in minutes?

**Q3.** Why is 100% the wrong reliability target? What do you lose by aiming for 100%?

**Q4.** What is burn rate? If you're burning budget at 10x, how long until your monthly budget is exhausted?

**Q5.** What are the 4 golden signals? Why are they important? Give one metric for each.

**Q6.** Write an SLI for a web API. Why did you choose this SLI? What makes it user-centric?

**Q7.** What is multi-window, multi-burn-rate alerting? Why is it better than threshold-based alerting?

**Q8.** Explain an error budget policy. What should happen when the budget is exhausted?

**Q9.** What is toil? Why does SRE care about reducing it? Give an example of toil.

**Q10.** Your service's error budget is 80% consumed and it's only week 2 of the month. What actions should you take and why?

---

## How to submit your answers

1. Create a file: `concepts/sre-practices/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/sre-practices/answers`
4. Open a Pull Request titled: `quiz(sre-practices): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
