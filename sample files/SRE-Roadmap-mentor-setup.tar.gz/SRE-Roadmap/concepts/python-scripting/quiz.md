# Python Scripting for SRE — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** Why should you always use virtual environments in Python? What happens if you don't?

**Q2.** Write a Python function that makes an HTTP GET request and handles connection errors, timeouts, and non-200 responses.

**Q3.** What is the difference between `subprocess.run()` and `subprocess.Popen()`? When would you use each?

**Q4.** How do you parse a JSON API response in Python? Show code that extracts a specific field.

**Q5.** Write a Python script using argparse that accepts --host, --port, and --timeout arguments.

**Q6.** What is the Python `logging` module? Why is it better than `print()` for production scripts?

**Q7.** How do you read a large log file line by line in Python without loading it all into memory?

**Q8.** Write a Python script that runs a shell command and captures both stdout and stderr.

**Q9.** What are context managers (`with` statement)? Why should you use them for file operations?

**Q10.** Your Python script runs in cron but fails with 'ModuleNotFoundError'. What's likely wrong and how do you fix it?

---

## How to submit your answers

1. Create a file: `concepts/python-scripting/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/python-scripting/answers`
4. Open a Pull Request titled: `quiz(python-scripting): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
