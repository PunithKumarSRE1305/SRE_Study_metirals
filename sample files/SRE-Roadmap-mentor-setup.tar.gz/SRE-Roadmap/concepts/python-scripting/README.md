# Python Scripting for SRE

> **Phase:** Core Skills | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — Python is the SRE's primary programming language

---

## 🎯 Why is this used in SRE?

**Python is the #1 language for SRE automation.** While Bash handles quick server tasks, Python handles complex automation: API interactions, data processing, infrastructure tooling, and orchestration.

What SREs build with Python:
- **Automation scripts:** Provision servers, configure services, deploy applications
- **API tools:** Query Prometheus, call Kubernetes API, interact with cloud APIs
- **Monitoring tools:** Custom exporters, health check scripts, alerting handlers
- **Data processing:** Parse logs, analyze metrics, generate reports
- **Infrastructure tools:** Terraform providers, Kubernetes operators, custom CLI tools

**Real-world example:** You need to check if all 50 microservices have valid TLS certificates and alert before they expire. A Python script using `requests` and `ssl` modules can check all 50 services, compare against a threshold, and send a Slack alert for any expiring within 30 days. Runs as a cron job. **This is real SRE work.**

---

## 🔧 How does this work? (From the basics)

### Python fundamentals
```python
# Variables and types
name = "Punith"          # string
age = 25                 # integer
height = 5.9             # float
is_sre = True            # boolean
servers = ["web1", "web2", "web3"]  # list
config = {"host": "localhost", "port": 8080}  # dict

# Functions
def check_service(url):
    """Check if a service is responding."""
    import requests
    try:
        response = requests.get(url, timeout=5)
        return response.status_code == 200
    except requests.RequestException:
        return False

# Call the function
if check_service("http://localhost:8080/health"):
    print("Service is UP ✅")
else:
    print("Service is DOWN ❌")
```

### Working with files (essential for log processing)
```python
# Read a file
with open("/var/log/app.log", "r") as f:
    for line in f:
        if "ERROR" in line:
            print(line.strip())

# Write a file
with open("/tmp/report.txt", "w") as f:
    f.write("Health Check Report\n")
    f.write(f"All services: {'OK' if all_ok else 'FAIL'}\n")
```

### Working with APIs (the SRE bread and butter)
```python
import requests

# Query Prometheus
response = requests.get(
    "http://prometheus:9090/api/v1/query",
    params={"query": "up{job='nginx'}"}
)
data = response.json()
for result in data["data"]["result"]:
    print(f"Instance: {result['metric']['instance']}, Status: {result['value'][1]}")
```

### CLI tools with argparse
```python
import argparse

parser = argparse.ArgumentParser(description="Check service health")
parser.add_argument("--url", required=True, help="Service URL to check")
parser.add_argument("--timeout", type=int, default=5, help="Timeout in seconds")
parser.add_argument("--alert", action="store_true", help="Send alert if down")
args = parser.parse_args()

# Now you can run: python check.py --url http://localhost:8080 --timeout 10 --alert
```

### Error handling (critical for production scripts)
```python
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def restart_service(service_name):
    try:
        # Try to restart
        result = subprocess.run(["systemctl", "restart", service_name], check=True)
        logging.info(f"Successfully restarted {service_name}")
    except subprocess.CalledProcessError as e:
        logging.error(f"Failed to restart {service_name}: {e}")
        raise
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        raise
```

### Virtual environments (always use these)
```bash
python3 -m venv venv        # Create a virtual environment
source venv/bin/activate    # Activate it (Linux/Mac)
# On Windows: venv\Scripts\activate
pip install requests        # Install packages (only in this env)
pip freeze > requirements.txt  # Save dependencies
```

---

## 📚 How to master this

1. **Build real tools, not toy examples.** Write scripts you'd actually use.
2. **Use `requests` library extensively** — it's how you interact with everything.
3. **Learn `subprocess`** — it's how you run shell commands from Python.
4. **Use virtual environments always** — never install packages globally.
5. **Write CLI tools with `argparse`** — SREs build tools for other people to use.
6. **Add proper logging and error handling** to every script.

### Resources
- **Automate the Boring Stuff with Python (free):** https://automatetheboringstuff.com/
- **Python for DevOps (book):** Noah Gift & Kennedy Behrman
- **Real Python (tutorials):** https://realpython.com/

---

## ⚠️ Major issues SREs face with Python (and how to fix them)

### 1. No error handling → script crashes silently
**Fix:** Always use try/except. Add logging. Use `sys.exit(1)` on failure so cron knows it failed.

### 2. Hardcoded values → script breaks on different servers
**Fix:** Use environment variables and argparse. Never hardcode URLs, passwords, paths.

### 3. No virtual environment → dependency conflicts
**Fix:** Always use venv. Pin dependencies with `requirements.txt`. Use `pip freeze`.

### 4. Synchronous scripts too slow for many targets
**Fix:** Use `concurrent.futures.ThreadPoolExecutor` for parallel API calls. Or use `asyncio` for I/O-bound tasks.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Build a system inventory script — collect server info (CPU, memory, disk) and output JSON
2. **Lab 2:** Build an API monitoring tool — check multiple endpoints, parse JSON responses, alert on failures
3. **Lab 3:** Build a CLI tool — a health-check command that checks services across multiple servers and generates a report

---

## ✅ Completion checklist

- [ ] Read this README and understand variables, functions, file I/O, APIs, error handling
- [ ] Complete Lab 1: System inventory script → PR accepted
- [ ] Complete Lab 2: API monitoring tool → PR accepted
- [ ] Complete Lab 3: CLI health-check tool → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
