# Infrastructure as Code — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What is Infrastructure as Code? Name 3 benefits over manual infrastructure management.

**Q2.** What is Terraform state? Why must you not commit it to Git? Where should you store it?

**Q3.** Write the Terraform workflow (the 4 main commands and what each does).

**Q4.** What is Terraform drift? How do you detect it? How do you fix it?

**Q5.** Write a basic Ansible playbook that installs nginx and ensures it's running.

**Q6.** What is idempotency? Why is it important for Ansible? Are Ansible playbooks always idempotent?

**Q7.** What is a Terraform module? Why do we use modules? Give an example of when to use one.

**Q8.** How do you prevent `terraform destroy` from accidentally destroying production resources?

**Q9.** Explain how Terraform and Ansible complement each other. Which does what?

**Q10.** Someone manually changed an AWS security group in the console. Your next `terraform plan` shows unexpected changes. What happened and how do you resolve it?

---

## How to submit your answers

1. Create a file: `concepts/infrastructure-as-code/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/infrastructure-as-code/answers`
4. Open a Pull Request titled: `quiz(infrastructure-as-code): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
