# Infrastructure as Code — Lab 1: Terraform Provisioning

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Use Terraform to provision: an EC2 instance, a security group (allow SSH and HTTP), and an S3 bucket. Run terraform init, plan, and apply. Verify all resources exist. Then destroy everything.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/infrastructure-as-code/lab1-punith`
3. Create your lab folder: `concepts/infrastructure-as-code/lab-submissions/punith/lab1/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(infrastructure-as-code): lab1 - terraform provisioning by punith"`
6. Push: `git push -u origin labs/infrastructure-as-code/lab1-punith`
7. Open a Pull Request titled: `labs(infrastructure-as-code): lab1 - Terraform Provisioning — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- Terraform config files written; terraform init/plan/apply all succeed; All 3 resources created in AWS; terraform destroy cleans up; README documents the process and includes screenshots
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
