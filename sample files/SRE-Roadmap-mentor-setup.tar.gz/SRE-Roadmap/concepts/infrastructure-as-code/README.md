# Infrastructure as Code (Terraform & Ansible)

> **Phase:** Infrastructure | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — manual infrastructure doesn't scale

---

## 🎯 Why is this used in SRE?

**SREs never click through a web console to create infrastructure.** Everything is code — version-controlled, reviewable, repeatable, and automated. This is called Infrastructure as Code (IaC).

What SREs do with IaC:
- **Provision cloud resources** (servers, databases, networks) with Terraform
- **Configure servers** (install packages, set up configs) with Ansible
- **Reproduce environments** — dev looks exactly like prod
- **Track infrastructure changes** in Git (know what changed and when)
- **Destroy and rebuild** entire environments in minutes

**Real-world example:** A new region needs to be set up (eu-west-2). Instead of manually creating 50 resources in the AWS console (2 days of work, lots of mistakes), you change one variable in Terraform and run `terraform apply`. 50 resources are created in 4 minutes, identical to the existing region. **That's IaC.**

---

## 🔧 How does this work? (From the basics)

### Terraform — provisioning infrastructure
```hcl
# main.tf — provision an EC2 instance

provider "aws" {
  region = "us-east-1"
}

resource "aws_instance" "web" {
  ami           = "ami-0c7217cdde317cfec"
  instance_type = "t3.micro"

  tags = {
    Name = "web-server"
    Environment = "production"
  }
}

resource "aws_s3_bucket" "logs" {
  bucket = "my-app-logs-bucket"
}
```

### The Terraform workflow
```bash
terraform init      # Download providers, set up backend
terraform plan      # Show what WILL change (dry run)
terraform apply     # Actually make the changes
terraform destroy   # Tear down everything (careful!)
```

### Terraform state
```
Terraform tracks what it created in a "state file":
  - terraform.tfstate (local — NOT for production)
  - Remote backend (S3 + DynamoDB — for production)

State tells Terraform:
  "I created EC2 i-12345, S3 bucket my-logs"
  So when you run `terraform plan`, it compares
  your code against what actually exists.
```

### Terraform modules — reusable infrastructure
```hcl
# Use a module instead of repeating code
module "web_server" {
  source        = "./modules/ec2"
  instance_count = 3
  environment    = "production"
}
```

### Ansible — configuring servers
```yaml
# playbook.yml — install nginx and deploy an app
---
- hosts: webservers
  become: yes              # run as sudo
  tasks:
    - name: Install nginx
      apt:
        name: nginx
        state: present
        update_cache: yes

    - name: Copy app configuration
      copy:
        src: nginx.conf
        dest: /etc/nginx/nginx.conf
      notify: restart nginx

    - name: Ensure nginx is running
      service:
        name: nginx
        state: started
        enabled: yes

  handlers:
    - name: restart nginx
      service:
        name: nginx
        state: restarted
```

### Ansible inventory
```ini
# inventory.ini
[webservers]
web1 ansible_host=10.0.1.10
web2 ansible_host=10.0.1.11
web3 ansible_host=10.0.1.12

[databases]
db1 ansible_host=10.0.2.10
```

### Ansible commands
```bash
ansible-playbook -i inventory.ini playbook.yml     # Run a playbook
ansible all -i inventory.ini -m ping                # Test connectivity
ansible webservers -i inventory.ini -a "df -h"     # Run ad-hoc command
```

### Terraform + Ansible together
```
1. Terraform creates: servers, networks, security groups, databases
2. Ansible configures: installs software, deploys apps, sets up monitoring

Terraform = build the house
Ansible = furnish and decorate it
```

---

## 📚 How to master this

1. **Write Terraform for everything** — never create AWS resources manually.
2. **Use modules** — don't repeat resource definitions.
3. **Store state remotely** — S3 + DynamoDB for locking.
4. **Run `terraform plan` always** — review changes before applying.
5. **Practice Ansible on local VMs** before trying on real servers.
6. **Learn idempotency** — running a playbook twice should have the same result as once.

### Resources
- **Terraform docs:** https://developer.hashicorp.com/terraform/docs
- **Ansible docs:** https://docs.ansible.com/
- **Terraform Best Practices:** https://www.terraform-best-practices.com/

---

## ⚠️ Major issues SREs face with IaC (and how to fix them)

### 1. State file conflicts → team members overwrite each other
**Fix:** Use remote state with locking (S3 + DynamoDB). Never commit state to Git.

### 2. Drift → manual changes break Terraform
**What happens:** Someone changes a resource in the console, Terraform state is now out of sync.
**Fix:** Run `terraform plan` regularly. Use `terraform import` to bring manual resources under Terraform control. Never make manual changes.

### 3. Accidental destruction → `terraform destroy` on production
**Fix:** Use `terraform workspace` to separate environments. Add a `lifecycle { prevent_destroy = true }` to critical resources. Require manual approval for production.

### 4. Ansible playbook fails on one server → partial deployment
**Fix:** Use `serial` to limit how many servers are configured at once. Use `any_errors_fatal: false` to continue on other servers.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Provision an EC2 instance + security group + S3 bucket using Terraform
2. **Lab 2:** Use Ansible to configure the EC2 instance — install nginx, deploy a sample app, set up monitoring
3. **Lab 3:** Combine Terraform + Ansible — provision with Terraform, configure with Ansible, document the full workflow

---

## ✅ Completion checklist

- [ ] Read this README and understand Terraform, Ansible, state management, idempotency
- [ ] Complete Lab 1: Terraform provisioning → PR accepted
- [ ] Complete Lab 2: Ansible configuration → PR accepted
- [ ] Complete Lab 3: Terraform + Ansible combined → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
