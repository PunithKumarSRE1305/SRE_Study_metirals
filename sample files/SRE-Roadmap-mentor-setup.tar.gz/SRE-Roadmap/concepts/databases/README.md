# Databases (SQL & NoSQL)

> **Phase:** Core Skills | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — databases are where production data lives

---

## 🎯 Why is this used in SRE?

**When the database is slow or down, everything is slow or down.** SREs are responsible for database reliability, performance, and recovery. You need to understand how databases work to:
- Diagnose slow queries causing latency spikes
- Set up replication for high availability
- Perform backups and test disaster recovery
- Monitor connection pools and prevent exhaustion
- Troubleshoot deadlocks and lock contention

**Real-world example:** Users report the app is slow. You check the APM dashboard and see database queries taking 5 seconds instead of 50ms. You run `EXPLAIN ANALYZE` on the slow query, find a missing index on a table with 10M rows, add the index, and latency drops back to normal. **This is a weekly occurrence for most SREs.**

---

## 🔧 How does this work? (From the basics)

### SQL basics
```sql
-- Create a table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Insert data
INSERT INTO users (username, email) VALUES ('punith', 'punith@example.com');

-- Query data
SELECT * FROM users WHERE username = 'punith';

-- Update
UPDATE users SET email = 'new@example.com' WHERE id = 1;

-- Delete
DELETE FROM users WHERE id = 1;

-- JOIN (combine data from two tables)
SELECT u.username, o.order_date
FROM users u
JOIN orders o ON u.id = o.user_id
WHERE u.username = 'punith';

-- Aggregate
SELECT COUNT(*) as total_users, AVG(age) as avg_age FROM users GROUP BY country;
```

### Indexes — the #1 performance lever
```sql
-- Without an index: database scans every row (slow on large tables)
SELECT * FROM orders WHERE user_id = 12345;

-- With an index: database jumps directly to matching rows (fast)
CREATE INDEX idx_orders_user_id ON orders(user_id);

-- Check if a query uses an index
EXPLAIN ANALYZE SELECT * FROM orders WHERE user_id = 12345;
-- If you see "Seq Scan" = bad (full table scan)
-- If you see "Index Scan" = good (using index)
```

### ACID properties (memorize this)
| Property | Meaning | Why it matters |
|---|---|---|
| **A**tomicity | All or nothing — a transaction either fully completes or fully rolls back | No partial writes that corrupt data |
| **C**onsistency | Data always follows rules (constraints, triggers) | No invalid data in the database |
| **I**solation | Concurrent transactions don't interfere with each other | No race conditions |
| **D**urability | Committed data survives crashes | No data loss after a crash |

### Connection pooling
```
Without pooling:            With pooling:
App → new connection → DB   App → [Pool of connections] → DB
(100 requests = 100 conns)  (100 requests share 10 conns)
```
Too many connections → database runs out of resources → all services slow down. Connection pooling solves this.

### NoSQL databases
| Database | Type | When to use | Example |
|---|---|---|---|
| Redis | Key-value | Caching, sessions, rate limiting | `SET user:1:session "abc123"` |
| MongoDB | Document | Flexible schemas, rapid development | `{"name": "Punith", "tags": ["sre"]}` |
| Cassandra | Wide-column | Time-series, massive write throughput | Metrics storage |
| DynamoDB | Key-value | Serverless, auto-scaling | AWS managed NoSQL |

### Replication (high availability)
```
Primary DB (writes) ──→ Replica 1 (reads)
                    ──→ Replica 2 (reads)

If primary fails → promote a replica → minimal downtime
```

### Backup and recovery
```bash
# PostgreSQL backup
pg_dump -U postgres mydb > backup.sql
pg_dump -U postgres -Fc mydb > backup.dump  # compressed format

# Restore
psql -U postgres mydb < backup.sql
pg_restore -U postgres -d mydb backup.dump

# Point-in-time recovery (requires WAL archiving)
# Recover to a specific moment before a bad change
```

---

## 📚 How to master this

1. **Install PostgreSQL locally** and practice all SQL commands.
2. **Load sample data** (1M+ rows) and practice with `EXPLAIN ANALYZE`.
3. **Break things intentionally** — create deadlocks, fill up connections, test recovery.
4. **Set up replication** in a lab environment.
5. **Practice backups AND restores** — an untested backup is not a backup.

### Resources
- **PostgreSQL Tutorial:** https://www.postgresqltutorial.com/
- **Use The Index, Luke! (indexing guide):** https://use-the-index-luke.com/
- **Redis Tutorial:** https://redis.io/tutorial

---

## ⚠️ Major issues SREs face with databases (and how to fix them)

### 1. Slow queries → high latency
**Diagnose:** `EXPLAIN ANALYZE`, `pg_stat_statements`, slow query log
**Fix:** Add indexes, rewrite queries, partition large tables, increase `work_mem`

### 2. Connection exhaustion → service can't connect
**Diagnose:** `SHOW max_connections`, `pg_stat_activity` (see active connections)
**Fix:** Add connection pooling (PgBouncer), increase max_connections (carefully), fix connection leaks in app

### 3. Deadlocks → transactions fail
**Diagnose:** Check database logs for deadlock messages
**Fix:** Always access tables in the same order across all transactions. Keep transactions short.

### 4. Disk full → database stops
**Diagnose:** `df -h`, check WAL archive size, check table sizes
**Fix:** Vacuum old data, set up autovacuum, monitor disk growth, add space

### 5. Replication lag → replicas have stale data
**Diagnose:** Check `pg_stat_replication`, monitor lag metrics
**Fix:** Increase replica capacity, optimize WAL shipping, check network bandwidth

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Set up PostgreSQL, create a schema, load data, write and optimize queries with EXPLAIN
2. **Lab 2:** Set up replication (primary + replica), test failover, document the process
3. **Lab 3:** Build a database health-check script (connections, slow queries, disk usage, replication lag)

---

## ✅ Completion checklist

- [ ] Read this README and understand SQL, indexes, ACID, replication, connection pooling
- [ ] Complete Lab 1: PostgreSQL setup and query optimization → PR accepted
- [ ] Complete Lab 2: Replication and failover → PR accepted
- [ ] Complete Lab 3: Database health-check script → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
