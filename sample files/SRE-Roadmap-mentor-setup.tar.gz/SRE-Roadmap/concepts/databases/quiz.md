# Databases (SQL & NoSQL) — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What are the ACID properties? Explain each one with a real-world example.

**Q2.** Write a SQL query that finds the top 10 customers by total order amount. Include a JOIN.

**Q3.** What is a database index? How does it speed up queries? When can it slow things down?

**Q4.** What does `EXPLAIN ANALYZE` show? How do you use it to diagnose slow queries?

**Q5.** What is connection pooling? Why is it important for SREs? What happens without it?

**Q6.** What is the difference between a primary and a replica? Why do we use replication?

**Q7.** How do you back up a PostgreSQL database? How do you restore it?

**Q8.** What is a deadlock? How does it happen? How can you prevent it?

**Q9.** When would you choose Redis over PostgreSQL? Give a specific use case.

**Q10.** Your database CPU is at 100% and queries are slow. Walk through your diagnosis process.

---

## How to submit your answers

1. Create a file: `concepts/databases/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/databases/answers`
4. Open a Pull Request titled: `quiz(databases): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
