# Databases (SQL & NoSQL) — Lab 1: PostgreSQL Setup and Query Optimization

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Install PostgreSQL, create a schema with at least 2 related tables, load sample data (1000+ rows), write queries with JOINs, and use EXPLAIN ANALYZE to optimize at least one slow query by adding an index.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/databases/lab1-punith`
3. Create your lab folder: `concepts/databases/lab-submissions/punith/lab1/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(databases): lab1 - postgresql setup and query optimization by punith"`
6. Push: `git push -u origin labs/databases/lab1-punith`
7. Open a Pull Request titled: `labs(databases): lab1 - PostgreSQL Setup and Query Optimization — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- PostgreSQL installed and running; Schema with related tables created; Sample data loaded; JOIN queries written; EXPLAIN ANALYZE used; Index added and improvement documented
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
