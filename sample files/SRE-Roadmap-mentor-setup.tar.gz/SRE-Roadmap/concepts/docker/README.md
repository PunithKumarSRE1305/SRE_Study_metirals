# Containers — Docker

> **Phase:** Infrastructure | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — containers are how modern applications are deployed

---

## 🎯 Why is this used in SRE?

**Containers changed how SREs deploy and operate applications.** Instead of "it works on my machine" problems, containers package the application AND its dependencies into a single portable unit that runs identically everywhere.

What SREs do with Docker:
- **Package applications** into images that run anywhere (dev, staging, production)
- **Run multiple services** on one server without dependency conflicts
- **Scale horizontally** by spinning up more containers
- **Roll back instantly** by switching to a previous image
- **Ensure consistency** between environments

**Real-world example:** A new developer joins. Instead of spending 2 days setting up the dev environment (install Python, dependencies, database, Redis, nginx), they run `docker-compose up` and everything starts in 30 seconds. **That's the power of containers.**

---

## 🔧 How does this work? (From the basics)

### Container vs Virtual Machine
```
Virtual Machine:                    Container:
┌──────┐ ┌──────┐ ┌──────┐         ┌──────┐ ┌──────┐ ┌──────┐
│ AppA │ │ AppB │ │ AppC │         │ AppA │ │ AppB │ │ AppC │
│ Libs │ │ Libs │ │ Libs │         │ Libs │ │ Libs │ │ Libs │
│ Guest│ │ Guest│ │ Guest│         ├──────┴─┴──────┴─┴──────┤
│  OS  │ │  OS  │ │  OS  │         │    Docker Engine       │
├──────┴─┴──────┴─┴──────┤         ├────────────────────────┤
│      Hypervisor        │         │      Host OS           │
├────────────────────────┤         ├────────────────────────┤
│      Hardware          │         │      Hardware          │
└────────────────────────┘         └────────────────────────┘
  Heavy (each has full OS)           Light (shares host OS kernel)
```

### Dockerfile — the recipe for an image
```dockerfile
# Start from a base image
FROM python:3.11-slim

# Set working directory inside the container
WORKDIR /app

# Copy requirements and install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy the application code
COPY . .

# Expose the port the app uses
EXPOSE 8080

# Command to run when container starts
CMD ["python", "app.py"]
```

### Docker commands (the ones you'll use daily)
```bash
# Build an image from a Dockerfile
docker build -t myapp:1.0 .

# Run a container
docker run -d -p 8080:8080 --name myapp myapp:1.0
#  -d = detached (run in background)
#  -p = port mapping (host:container)
#  --name = give it a name

# List running containers
docker ps

# List all containers (including stopped)
docker ps -a

# Stop a container
docker stop myapp

# Remove a container
docker rm myapp

# List images
docker images

# Remove an image
docker rmi myapp:1.0

# View container logs
docker logs myapp
docker logs -f myapp    # follow (like tail -f)

# Execute a command inside a running container
docker exec -it myapp bash

# Pull an image from a registry
docker pull nginx:latest

# Push an image to a registry
docker push myregistry/myapp:1.0
```

### Docker Compose — multi-container apps
```yaml
# docker-compose.yml
version: '3.8'
services:
  web:
    build: .
    ports:
      - "8080:8080"
    depends_on:
      - db
      - redis
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/mydb

  db:
    image: postgres:15
    environment:
      - POSTGRES_PASSWORD=secret
    volumes:
      - dbdata:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

volumes:
  dbdata:
```

```bash
docker-compose up -d       # Start all services
docker-compose down         # Stop all services
docker-compose logs -f      # View all logs
docker-compose ps           # Check status
```

### Images and layers
```
Each instruction in a Dockerfile creates a layer:
FROM python:3.11-slim     ← Layer 1 (base image)
WORKDIR /app              ← Layer 2 (metadata only)
COPY requirements.txt .   ← Layer 3 (file changes)
RUN pip install ...       ← Layer 4 (installed packages)
COPY . .                  ← Layer 5 (app code)
CMD ["python", "app.py"]  ← Layer 6 (metadata only)

Layers are cached. If requirements.txt doesn't change,
Docker reuses the cached layer (fast builds!).
```

### Volumes — persistent data
```bash
# Containers are ephemeral — data is lost when they're removed.
# Volumes persist data outside the container.

# Named volume
docker run -v mydata:/data myapp

# Bind mount (map a host directory to container)
docker run -v /host/path:/container/path myapp
```

### Resource limits
```bash
# Limit CPU and memory
docker run -d --memory=512m --cpus=1.0 myapp

# Without limits, one container can use all host resources
# and starve other containers (noisy neighbor problem)
```

---

## 📚 How to master this

1. **Dockerize everything.** Every app you build, wrap in a Dockerfile.
2. **Practice writing Dockerfiles from scratch** — don't just copy-paste.
3. **Learn multi-stage builds** — they dramatically reduce image size.
4. **Use docker-compose for multi-service setups.**
5. **Optimize images** — use slim/alpine bases, .dockerignore, layer caching.
6. **Scan images for vulnerabilities** — use `docker scout` or Trivy.

### Resources
- **Docker docs:** https://docs.docker.com/
- **Play with Docker (free online lab):** https://labs.play-with-docker.com/
- **Dockerfile best practices:** https://docs.docker.com/develop/develop-images/dockerfile_best-practices/

---

## ⚠️ Major issues SREs face with Docker (and how to fix them)

### 1. Image too large → slow builds and deploys
**Fix:** Use slim/alpine base images. Multi-stage builds. `.dockerignore` to exclude unnecessary files.

### 2. Container runs as root → security risk
**Fix:** Create a non-root user in the Dockerfile:
```dockerfile
RUN useradd -m appuser
USER appuser
```

### 3. Container dies and data is lost
**Fix:** Use volumes for persistent data. Never store important data in the container's writable layer.

### 4. No resource limits → one container starves others
**Fix:** Always set `--memory` and `--cpus` limits. In Kubernetes, use resource requests and limits.

### 5. Image contains secrets → security breach
**Fix:** NEVER put secrets in Dockerfiles. Use environment variables at runtime, or Docker secrets, or a secrets manager.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Write a Dockerfile for a Python web app, build, run, and test it
2. **Lab 2:** Dockerize a multi-service app (web + database + Redis) with docker-compose
3. **Lab 3:** Build a multi-stage Dockerfile, optimize image size, add resource limits, scan for vulnerabilities

---

## ✅ Completion checklist

- [ ] Read this README and understand images, containers, Dockerfiles, compose, volumes
- [ ] Complete Lab 1: Dockerize a web app → PR accepted
- [ ] Complete Lab 2: Multi-service with compose → PR accepted
- [ ] Complete Lab 3: Optimized multi-stage build → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
