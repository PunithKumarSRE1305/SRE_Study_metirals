# Containers — Docker — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What is the difference between a container and a virtual machine?

**Q2.** Write a Dockerfile for a Python web app. Explain each instruction.

**Q3.** What is a Docker layer? How does layer caching speed up builds?

**Q4.** What is the difference between `docker run` and `docker exec`?

**Q5.** Why should containers not run as root? How do you run as a non-root user?

**Q6.** What is a Docker volume? Why do you need it? What happens to data without a volume?

**Q7.** Explain what `docker-compose` does. When would you use it instead of plain `docker run`?

**Q8.** What is a multi-stage build? Why does it reduce image size? Show an example.

**Q9.** Your Docker container keeps getting OOMKilled. What does that mean and how do you fix it?

**Q10.** What should go in a `.dockerignore` file and why?

---

## How to submit your answers

1. Create a file: `concepts/docker/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/docker/answers`
4. Open a Pull Request titled: `quiz(docker): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
