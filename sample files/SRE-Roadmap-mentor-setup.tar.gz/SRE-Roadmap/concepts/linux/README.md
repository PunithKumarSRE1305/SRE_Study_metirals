# Linux Fundamentals

> **Phase:** Foundation | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** CRITICAL — this is where everything begins

---

## 🎯 Why is this used in SRE?

**90% of production servers run Linux.** As an SRE, you will spend more time on Linux than on any other single thing. If you can't navigate Linux, you can't do the job. Period.

Here's what SREs actually do on Linux every day:
- **Log into a production server** that's having problems and figure out what's wrong
- **Check if a service is running** and restart it if it crashed
- **Look at logs** to find error messages
- **Check disk space, memory, CPU** to find bottlenecks
- **Deploy applications** by copying files and starting services
- **Write scripts** to automate repetitive tasks

If you don't know Linux, you can't do any of this. You'd be blind in production.

**Real-world example:** At 3 AM, the payment service goes down. The on-call SRE (you) gets paged. You SSH into the server, check `systemctl status payment-service`, see it crashed, check `journalctl -u payment-service` for the error, find it ran out of memory, check `free -h` to confirm, identify the memory leak in the logs, restart the service, and file a bug. **All of this happens on Linux. In 5 minutes. At 3 AM.**

---

## 🔧 How does this work? (From the basics)

### What is Linux?
Linux is an operating system (like Windows or macOS) but it's:
- **Free and open-source** — anyone can use it
- **Command-line first** — you type commands instead of clicking buttons
- **Extremely stable** — servers can run for years without rebooting
- **Lightweight** — doesn't waste resources on a graphical interface

### The file system (think of it like a tree of folders)
```
/              ← The root (top of the tree, like C:\ in Windows)
├── /etc       ← Configuration files (like settings)
├── /var       ← Variable data — logs, databases, temp files
│   └── /var/log   ← Log files live here
├── /home      ← User home directories (like C:\Users\YourName)
├── /tmp       ← Temporary files (deleted on reboot)
├── /proc      ← Info about running processes (virtual, not real files)
├── /opt       ← Optional software installations
└── /usr       ← User programs and libraries
```

### The 20 commands you must know cold
| Command | What it does | Example |
|---|---|---|
| `ls` | List files in current folder | `ls -la` (show all, with details) |
| `cd` | Change directory (go to a folder) | `cd /var/log` |
| `pwd` | Print working directory (where am I?) | `pwd` |
| `cat` | Show contents of a file | `cat /etc/hostname` |
| `less` | View a file page by page | `less /var/log/syslog` |
| `grep` | Search for text in files | `grep "error" /var/log/syslog` |
| `ps` | List running processes | `ps aux` |
| `top` | Real-time process viewer | `top` |
| `kill` | Stop a process | `kill 1234` (by PID) |
| `systemctl` | Manage services | `systemctl status nginx` |
| `journalctl` | View system/service logs | `journalctl -u nginx` |
| `df` | Check disk space | `df -h` |
| `du` | Check folder size | `du -sh /var/log` |
| `free` | Check memory usage | `free -h` |
| `chmod` | Change file permissions | `chmod 755 script.sh` |
| `chown` | Change file owner | `chown user:group file` |
| `find` | Find files | `find / -name "*.log"` |
| `ssh` | Connect to another server | `ssh user@server-ip` |
| `curl` | Make HTTP requests | `curl http://localhost:8080` |
| `sudo` | Run command as admin | `sudo systemctl restart nginx` |

### systemd — the service manager
`systemd` is how Linux starts and manages services (like web servers, databases). Think of it as a supervisor that:
- Starts services when the server boots
- Restarts services if they crash
- Logs what services are doing
- Lets you start/stop/check status

Key commands:
```bash
sudo systemctl start nginx      # Start a service
sudo systemctl stop nginx       # Stop a service
sudo systemctl restart nginx    # Restart a service
sudo systemctl status nginx     # Check if it's running
sudo systemctl enable nginx     # Start automatically on boot
journalctl -u nginx             # View the service's logs
```

### File permissions (this confuses every beginner — learn it now)
Every file has 3 types of permissions for 3 types of people:
```
- rwx r-x r--
│ │   │   │
│ │   │   └── Others: can read only
│ │   └── Group: can read and execute
│ └── Owner: can read, write, execute
└── File type (- = regular file, d = directory)
```
- `r` = read (4) | `w` = write (2) | `x` = execute (1)
- So `rwx` = 4+2+1 = 7, `r-x` = 4+0+1 = 5, `r--` = 4+0+0 = 4
- `chmod 755 file` = owner can do everything, group and others can read+execute

---

## 📚 How to master this

1. **Don't just read — DO.** Open a terminal and run every command in this README. Break things. Fix them.
2. **Set up a Linux environment:** Install Ubuntu in VirtualBox, or use WSL on Windows, or use a cloud VM (AWS free tier).
3. **Complete the 3 labs** in order. Each builds on the previous.
4. **Practice daily.** Even 15 minutes of `grep`, `find`, `ps` practice makes a difference.
5. **Use the command line for everything** — don't use a GUI file manager. Force yourself to use `ls`, `cd`, `cat`.
6. **Read the SRE book chapter on monitoring** — it references Linux tools you'll use daily.

### Resources
- **Linux Journey** (free, interactive): https://linuxjourney.com/
- **The Linux Command Line** (free book): https://linuxcommand.org/tlcl.php
- **OverTheWire Bandit** (security wargame that teaches Linux): https://overthewire.org/wargames/bandit/

---

## ⚠️ Major issues SREs face with Linux (and how to fix them)

### 1. Disk full → service crashes
**What happens:** Logs or data files fill the disk. Services can't write → crash.
**How to diagnose:** `df -h` (see which disk is full), `du -sh /var/log/*` (find the big files)
**How to fix:** Delete or rotate old logs. Set up log rotation (`logrotate`). Add disk space alerts in monitoring.
**As SRE, you prevent this:** Set up monitoring to alert at 80% disk usage, not 100%.

### 2. High CPU / load average → slow responses
**What happens:** A process is consuming all CPU. Other services slow down.
**How to diagnose:** `top` or `htop` (find the process), `ps aux --sort=-%cpu` (sort by CPU usage)
**How to fix:** Kill or restart the runaway process. Add CPU limits (cgroups/Docker). Scale horizontally.
**As SRE, you prevent this:** Set CPU alerts. Use resource limits. Auto-scaling.

### 3. Out of memory (OOM) → process killed
**What happens:** A process uses too much memory. Linux kills it to protect itself.
**How to diagnose:** `dmesg | grep -i oom`, `free -h`, check `journalctl` for OOM killer messages
**How to fix:** Fix the memory leak in the app. Add swap. Increase memory. Set memory limits.
**As SRE, you prevent this:** Memory alerts. Memory limits in containers. Regular load testing.

### 4. Service won't start → app down
**What happens:** A service fails to start after deploy or reboot.
**How to diagnose:** `systemctl status <service>`, `journalctl -u <service>`, check config files
**How to fix:** Read the error in the logs. Usually it's a bad config, missing file, or port conflict.

### 5. SSH access broken → can't reach the server
**What happens:** Can't SSH in. Could be network, firewall, or sshd config issue.
**How to diagnose:** Check security groups/firewall, check `sshd` config, check if sshd is running
**How to fix:** Use a serial console or cloud provider's recovery console. Fix the config. Restart sshd.

---

## 🏗️ Real-world project (build this during the labs)

**Project: Deploy and operate a web application on Linux**

Throughout the 3 labs, you will:
1. **Lab 1:** Deploy a Python web app as a systemd service (auto-restart on crash)
2. **Lab 2:** Write a monitoring script that checks disk/memory and runs via cron
3. **Lab 3:** Troubleshoot a deliberately broken service — find the root cause and fix it

By the end, you'll have done exactly what an SRE does: deploy, monitor, and troubleshoot on Linux.

---

## ✅ Completion checklist (I will verify each item)

- [ ] Read this entire README and understand all 20 commands
- [ ] Complete Lab 1: Deploy a web app with systemd → PR accepted
- [ ] Complete Lab 2: Monitoring script with cron → PR accepted
- [ ] Complete Lab 3: Troubleshoot a broken service → PR accepted
- [ ] Pass quiz with ≥ 8/10 → quiz PR accepted
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
