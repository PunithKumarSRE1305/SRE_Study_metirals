# Linux Fundamentals — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** How do you list all running processes with their full command line? (give the exact command)

**Q2.** How do you find which process is listening on TCP port 8080? (give the command)

**Q3.** Explain what systemd is and how it differs from traditional init scripts.

**Q4.** How do you check disk usage for the root filesystem? (give the command)

**Q5.** What does the command `journalctl -u nginx --since '1 hour ago'` show?

**Q6.** Explain file permissions: what does `-rwxr-xr--` mean? Break down each part.

**Q7.** How do you set up a systemd service unit file that restarts automatically on failure? Show the key directives.

**Q8.** How do you create a cron job that runs a script every hour? Show the crontab entry.

**Q9.** What does `dmesg` show and when would you use it as an SRE?

**Q10.** Your production server is running out of memory and the OOM killer is killing your service. Walk through how you diagnose and fix this.

---

## How to submit your answers

1. Create a file: `concepts/linux/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/linux/answers`
4. Open a Pull Request titled: `quiz(linux): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
