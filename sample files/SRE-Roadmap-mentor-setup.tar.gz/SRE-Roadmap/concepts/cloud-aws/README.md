# Cloud Platforms — AWS

> **Phase:** Infrastructure | **Duration:** 3 weeks | **Labs:** 3 | **Quiz:** 10 questions
> **Status:** 🔴 Not started | **Priority:** High — most SRE jobs require cloud experience

---

## 🎯 Why is this used in SRE?

**Most modern infrastructure runs in the cloud.** As an SRE, you'll provision, manage, and troubleshoot cloud resources daily. AWS is the most common cloud platform, so we focus on it.

What SREs do on AWS:
- **Provision servers** (EC2) and configure them
- **Set up networking** (VPC, subnets, security groups)
- **Manage databases** (RDS — managed PostgreSQL/MySQL)
- **Configure load balancing** (ALB/NLB)
- **Set up monitoring** (CloudWatch)
- **Manage storage** (S3)
- **Control access** (IAM)
- **Optimize costs** (right-sizing, reserved instances)

**Real-world example:** Traffic to your service increases 5x. You configure an Auto Scaling Group to automatically add more EC2 instances when CPU exceeds 70%, and remove them when traffic drops. The system handles the spike automatically. **You were asleep the whole time.**

---

## 🔧 How does this work? (From the basics)

### AWS core services (the ones you must know)
| Service | What it does | SRE use |
|---|---|---|
| **EC2** | Virtual servers | Run applications |
| **VPC** | Private network | Isolate and secure resources |
| **S3** | Object storage | Store backups, logs, static files |
| **RDS** | Managed databases | PostgreSQL/MySQL without DBA work |
| **IAM** | Identity and access | Control who can do what |
| **Route 53** | DNS | Manage domain names |
| **ALB/ELB** | Load balancers | Distribute traffic |
| **CloudWatch** | Monitoring | Metrics, logs, alarms |
| **ASG** | Auto Scaling Groups | Auto-scale EC2 instances |
| **Lambda** | Serverless functions | Run code without servers |

### VPC — your private network in the cloud
```
VPC (10.0.0.0/16)
├── Public Subnet (10.0.1.0/24)  ← Has internet access (load balancers)
│   └── ALB
├── Private Subnet (10.0.2.0/24) ← No direct internet (app servers)
│   └── EC2 instances
├── Private Subnet (10.0.3.0/24) ← No direct internet (databases)
│   └── RDS instance
└── Security Groups (firewalls)
    └── ALB: allow 443 from anywhere
    └── EC2: allow 8080 from ALB only
    └── RDS: allow 5432 from EC2 only
```

### IAM — who can do what
```
Principle of least privilege:
  ❌ Give developer admin access to everything
  ✅ Give developer read access to S3 and deploy access to one service

IAM components:
  User    → A person or application
  Role    → Temporary permissions (for EC2, Lambda, etc.)
  Policy  → A document defining what's allowed (JSON)
  Group   → A collection of users with shared permissions
```

Example IAM policy:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject"],
      "Resource": "arn:aws:s3:::my-logs-bucket/*"
    }
  ]
}
```

### Auto Scaling Groups
```
ASG config:
  - Min: 2 instances (always running)
  - Max: 10 instances (never more than this)
  - Desired: 3 instances (normal state)

Scale-up policy: If average CPU > 70% for 5 min → add 1 instance
Scale-down policy: If average CPU < 30% for 10 min → remove 1 instance
```

### CloudWatch — monitoring on AWS
```bash
# CloudWatch gives you:
# - Metrics (CPU, network, disk for EC2 — free)
# - Logs (application logs — Log Insights for searching)
# - Alarms (trigger when metric crosses threshold)
# - Dashboards (visualize metrics)

# Example: Alert when EC2 CPU > 80% for 5 minutes
aws cloudwatch put-metric-alarm \
  --alarm-name "HighCPU" \
  --metric-name CPUUtilization \
  --namespace AWS/EC2 \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --dimensions Name=InstanceId,Value=i-123456 \
  --evaluation-periods 1
```

---

## 📚 How to master this

1. **Create an AWS Free Tier account** (free for 12 months — don't exceed limits).
2. **Set up a VPC from scratch** — subnets, route tables, gateways.
3. **Launch EC2 instances** and SSH into them.
4. **Set up an ALB + ASG** — auto-scaling is a core SRE skill.
5. **Use the AWS CLI** — don't just click in the console.
6. **Monitor everything with CloudWatch.**
7. **Set a billing alarm** — so you don't accidentally spend money.

### ⚠️ IMPORTANT: Avoid AWS charges
- Set up a billing alarm at $5
- Terminate EC2 instances when not in use
- Don't use expensive instance types (stick to t2.micro/t3.micro)
- Delete resources after labs

### Resources
- **AWS Free Tier:** https://aws.amazon.com/free/
- **AWS docs:** https://docs.aws.amazon.com/
- **AWS Well-Architected Tool:** https://aws.amazon.com/architecture/well-architected/
- **AWS CLI reference:** https://awscli.amazonaws.com/v2/documentation/api/latest/index.html

---

## ⚠️ Major issues SREs face on AWS (and how to fix them)

### 1. Security group misconfiguration → service unreachable
**Diagnose:** Check inbound/outbound rules. Is the port open from the right source?
**Fix:** Allow traffic only from known sources (ALB → EC2 → RDS). Never open 0.0.0.0/0 to private services.

### 2. EC2 instance can't reach the internet
**Diagnose:** Check if it's in a public subnet, check route table, check for a public IP
**Fix:** Add an Internet Gateway, add a route to 0.0.0.0/0, assign a public IP or use a NAT Gateway for private subnets.

### 3. Unexpected AWS bill → cost overrun
**Fix:** Set up billing alerts. Use AWS Cost Explorer. Terminate unused resources. Use Spot Instances for non-critical workloads.

### 4. RDS connection failures
**Diagnose:** Check security groups, check VPC/subnet, check parameter group, check credentials
**Fix:** Ensure security group allows access from the app's security group, not IP-based.

### 5. IAM permission denied
**Diagnose:** Check the IAM policy, check the role attached to the resource
**Fix:** Use the IAM Policy Simulator to test permissions. Follow least privilege.

---

## 🏗️ Real-world project (build this during the labs)

1. **Lab 1:** Create a VPC with public/private subnets, launch an EC2 instance, SSH into it
2. **Lab 2:** Deploy a highly available app — EC2 across 2 AZs with an Application Load Balancer and Auto Scaling
3. **Lab 3:** Set up CloudWatch alarms for CPU/memory, configure auto-scaling, document the monitoring setup

---

## ✅ Completion checklist

- [ ] Read this README and understand VPC, EC2, IAM, ALB, ASG, CloudWatch
- [ ] Complete Lab 1: VPC + EC2 → PR accepted
- [ ] Complete Lab 2: HA app with ALB + ASG → PR accepted
- [ ] Complete Lab 3: CloudWatch + auto-scaling → PR accepted
- [ ] Pass quiz with ≥ 8/10
- [ ] All 3 lab PRs merged
- [ ] Concept marked 100% in status.json

> **Do NOT check these boxes yourself. I check them when I review your PRs.**
