# Cloud Platforms — AWS — Quiz (10 questions)

> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.
> If you fail twice, I will assign remediation tasks before you can reattempt.

**Q1.** What is a VPC? Why do we use public and private subnets? What goes in each?

**Q2.** What is an IAM Role? How does it differ from an IAM User? When would you use each?

**Q3.** What is the principle of least privilege? Give an example of applying it to an S3 bucket.

**Q4.** Explain what an Auto Scaling Group does. How does it decide when to scale?

**Q5.** What is a Security Group? How does it differ from a traditional firewall? What is the best practice for Security Groups?

**Q6.** What is RDS? What are the benefits of using RDS vs running your own database on EC2?

**Q7.** How do you set up a CloudWatch alarm that triggers when EC2 CPU exceeds 80%?

**Q8.** What is an Application Load Balancer? How does it differ from a Network Load Balancer?

**Q9.** Your EC2 instance in a private subnet can't reach the internet. What's likely wrong and how do you fix it?

**Q10.** Name 3 ways to reduce your AWS bill. Which has the biggest impact?

---

## How to submit your answers

1. Create a file: `concepts/cloud-aws/quiz-answers/punith.md`
2. Write your answers to all 10 questions in that file
3. Commit and push to a branch: `quiz/cloud-aws/answers`
4. Open a Pull Request titled: `quiz(cloud-aws): answers - punith`
5. I will review your answers, score them, and either pass you or ask you to study again

> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. If you fail honestly, you know what to study. If you cheat, you cheat yourself.
