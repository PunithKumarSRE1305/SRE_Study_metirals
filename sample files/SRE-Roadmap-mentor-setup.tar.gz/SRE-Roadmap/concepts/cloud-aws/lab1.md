# Cloud Platforms — AWS — Lab 1: VPC + EC2 Setup

> **Estimated time:** 4–6 hours (weekend)
> **Submission:** Open a Pull Request. I will review and may request changes.

## Goal

Create a VPC with one public subnet and one private subnet. Launch a t2.micro EC2 instance in the public subnet. SSH into it from your laptop. Document the entire setup.

## Steps

1. Read this lab file completely
2. Create a branch: `git switch -c labs/cloud-aws/lab1-punith`
3. Create your lab folder: `concepts/cloud-aws/lab-submissions/punith/lab1/`
4. In that folder, create:
   - `README.md` — explain what you did, step by step, with all commands
   - Your code/config files (scripts, configs, YAML, etc.)
   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`
   - Test outputs / screenshots (if applicable)
5. Commit: `git add . && git commit -m "labs(cloud-aws): lab1 - vpc + ec2 setup by punith"`
6. Push: `git push -u origin labs/cloud-aws/lab1-punith`
7. Open a Pull Request titled: `labs(cloud-aws): lab1 - VPC + EC2 Setup — punith`
8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note

## Acceptance Criteria (I will check each of these)

- VPC with public and private subnets created; Route tables and internet gateway configured; EC2 instance launched and running; SSH access verified; Security groups follow least privilege; README documents each step
- All code/config files are included and functional
- README is clear enough that someone else could reproduce your work
- No secrets, passwords, or credentials in any file
- Commands and their outputs are documented

## Tips

- Start early. Don't wait until the last day.
- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.
- Test your work before submitting. A PR that doesn't work will be rejected.
- Document as you go. It's much harder to write the README at the end.
