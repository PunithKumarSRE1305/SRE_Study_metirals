#!/usr/bin/env python3
"""Generate quiz.md and lab files for all 15 concepts."""
import os

CONCEPTS = {
    "linux": {
        "title": "Linux Fundamentals",
        "quiz": [
            "How do you list all running processes with their full command line? (give the exact command)",
            "How do you find which process is listening on TCP port 8080? (give the command)",
            "Explain what systemd is and how it differs from traditional init scripts.",
            "How do you check disk usage for the root filesystem? (give the command)",
            "What does the command `journalctl -u nginx --since '1 hour ago'` show?",
            "Explain file permissions: what does `-rwxr-xr--` mean? Break down each part.",
            "How do you set up a systemd service unit file that restarts automatically on failure? Show the key directives.",
            "How do you create a cron job that runs a script every hour? Show the crontab entry.",
            "What does `dmesg` show and when would you use it as an SRE?",
            "Your production server is running out of memory and the OOM killer is killing your service. Walk through how you diagnose and fix this.",
        ],
        "labs": [
            ("Deploy a Web App with systemd", "Deploy a Python HTTP app, create a systemd unit file, configure it to restart on failure, and document how to start/stop/check status.", "Service unit file exists and is correct; App runs and responds on localhost; README contains commands to test and verify logs"),
            ("Monitoring Script with Cron", "Write a Bash script that checks disk usage and memory, and sends an alert if thresholds are exceeded. Schedule it with cron to run every hour.", "Script checks both disk and memory; Alert triggers above threshold; Cron job is configured; README explains how to test and verify"),
            ("Troubleshoot a Broken Service", "A service has been deliberately broken (bad config, wrong permissions, missing file). Find the root cause using Linux diagnostic tools, fix it, and document your troubleshooting process step by step.", "Root cause identified and documented; Service restored to working state; Troubleshooting steps are reproducible; README explains each diagnostic step"),
        ],
    },
    "networking": {
        "title": "Networking Fundamentals",
        "quiz": [
            "Draw or describe the OSI 7-layer model. Give one example protocol for each layer.",
            "Explain the TCP 3-way handshake. Why is it called 'connection-oriented'?",
            "What is the difference between TCP and UDP? Give one real-world example of each.",
            "What does DNS do? Walk through what happens when you type www.google.com in a browser.",
            "How do you check if a remote server's port 443 is reachable? (give two different commands)",
            "Explain HTTP status codes 200, 301, 404, 500, 502, and 503. What does each mean?",
            "What is a reverse proxy? How does it differ from a forward proxy? Why do SREs use them?",
            "What is a subnet mask? What does 255.255.255.0 mean? How many hosts can it support?",
            "You can SSH into a server but can't reach it on port 443 from your laptop. Walk through how you diagnose this.",
            "What is TLS? Why do we use it? What happens during a TLS handshake?",
        ],
        "labs": [
            ("Network Mapping", "Scan a local network, identify all open ports and running services using ss, nmap, or similar tools. Create a network topology diagram.", "All open ports identified; Services documented; Network diagram included; README explains methodology"),
            ("Network Troubleshooting", "Diagnose 5 simulated network problems (DNS failure, port conflict, firewall block, high latency, broken TLS) using tcpdump, traceroute, dig, and curl. Document each diagnosis step by step.", "All 5 problems diagnosed; Correct tools used for each; Root cause documented; Fixes applied and verified"),
            ("Reverse Proxy with TLS", "Set up nginx as a reverse proxy in front of a web application. Configure TLS with a self-signed certificate. Test and document the setup.", "nginx reverse proxy configured; TLS certificate generated and installed; App accessible via HTTPS; README includes setup and testing steps"),
        ],
    },
    "bash-scripting": {
        "title": "Bash Scripting",
        "quiz": [
            "Why must you always quote variables in Bash? Give an example of what goes wrong if you don't.",
            "What does `set -euo pipefail` do? Explain each flag.",
            "Write a Bash function that takes a filename as an argument and returns 0 if the file exists, 1 if not.",
            "How do you read a file line by line in Bash? Why do you use `IFS= read -r`?",
            "What is the difference between `grep`, `awk`, and `sed`? Give one use case for each.",
            "Write a Bash one-liner that finds the top 5 largest files in /var/log.",
            "Your cron job runs a script but it fails. The script works when you run it manually. What are the likely causes and how do you fix them?",
            "What is a trap in Bash? Write an example that cleans up a temp file when the script exits or errors.",
            "Explain command substitution in Bash. Show two syntaxes and when to use each.",
            "Write a Bash script that checks if the nginx service is running on 3 servers (via SSH) and prints a report. Include error handling.",
        ],
        "labs": [
            ("System Health Check Script", "Write a Bash script that checks disk usage, memory usage, CPU load, and whether critical services (nginx, sshd) are running. Output a formatted report.", "Script checks all 4 items; Output is formatted and readable; Uses proper error handling (set -euo pipefail); README explains how to run and interpret output"),
            ("Automated Alerting with Cron", "Extend the health check script to send an alert (email or webhook) when any threshold is exceeded. Schedule it with cron to run every 30 minutes.", "Alerts trigger correctly on threshold breach; Cron job configured; Alert includes useful information (what failed, current value); README documents testing process"),
            ("Log Parsing Script", "Write a Bash script that parses an application log file, extracts all ERROR lines, counts them, shows the top 5 most frequent errors, and generates a summary report.", "Script extracts ERROR lines; Counts and ranks errors; Generates formatted summary report; Handles edge cases (empty file, no errors); README includes sample input and output"),
        ],
    },
    "git": {
        "title": "Git & Version Control",
        "quiz": [
            "What is the difference between Git and GitHub?",
            "Explain what a commit is. What information does a commit contain?",
            "What is a branch? Why do we use branches instead of committing directly to main?",
            "What is the difference between `git merge` and `git rebase`? When would you use each?",
            "You accidentally committed a file containing a password to Git and pushed it. Walk through exactly what you need to do.",
            "What is a merge conflict? How does it happen? How do you resolve one?",
            "What does `git reset --hard` do? Why is it dangerous? How can you recover from a bad reset?",
            "Write the exact sequence of commands to: create a branch, make changes, commit, push, and open a PR.",
            "What is `git bisect` and how does it help you find which commit introduced a bug?",
            "Explain the difference between `git fetch` and `git pull`. When would you use each?",
        ],
        "labs": [
            ("Full Git Workflow", "Demonstrate the complete Git workflow: clone the repo, create a branch, make changes to a file, commit with a proper message, push, and open a Pull Request. Document each step.", "All git commands demonstrated; Commit message follows conventions; PR opened with proper description; README documents the full workflow step by step"),
            ("Merge Conflict Resolution", "Create a scenario with a merge conflict (two branches modifying the same line). Resolve the conflict manually, document the process with screenshots/output, and merge.", "Conflict created intentionally; Conflict markers shown in the file; Resolution process documented; Final merge successful; README explains what conflicts are and how to resolve them"),
            ("Git Hooks", "Set up a pre-commit Git hook that runs ShellCheck on any .sh files and blocks the commit if errors are found. Document how it works and how to test it.", "Pre-commit hook installed and working; Hook runs ShellCheck on .sh files; Commits with lint errors are blocked; Commits with clean code succeed; README explains hooks and how to install"),
        ],
    },
    "python-scripting": {
        "title": "Python Scripting for SRE",
        "quiz": [
            "Why should you always use virtual environments in Python? What happens if you don't?",
            "Write a Python function that makes an HTTP GET request and handles connection errors, timeouts, and non-200 responses.",
            "What is the difference between `subprocess.run()` and `subprocess.Popen()`? When would you use each?",
            "How do you parse a JSON API response in Python? Show code that extracts a specific field.",
            "Write a Python script using argparse that accepts --host, --port, and --timeout arguments.",
            "What is the Python `logging` module? Why is it better than `print()` for production scripts?",
            "How do you read a large log file line by line in Python without loading it all into memory?",
            "Write a Python script that runs a shell command and captures both stdout and stderr.",
            "What are context managers (`with` statement)? Why should you use them for file operations?",
            "Your Python script runs in cron but fails with 'ModuleNotFoundError'. What's likely wrong and how do you fix it?",
        ],
        "labs": [
            ("System Inventory Script", "Write a Python script that collects system information (hostname, OS, CPU count, memory, disk usage) and outputs it as formatted JSON.", "Script collects all required info; Output is valid JSON; Uses proper error handling; Works on the target system; README explains how to run and interpret output"),
            ("API Monitoring Tool", "Build a Python tool that checks multiple HTTP endpoints, parses JSON responses, measures response time, and alerts if any endpoint is slow or returns errors.", "Checks multiple endpoints; Measures response time; Parses JSON responses; Alerts on failure or slow response; Uses argparse for configuration; README documents usage"),
            ("CLI Health Check Tool", "Build a CLI tool using argparse that checks services across multiple servers (via SSH/subprocess), generates a report, and saves it to a file. Include proper logging.", "CLI tool with argparse arguments; Checks multiple servers; Generates formatted report; Saves report to file; Proper logging implemented; README includes usage examples"),
        ],
    },
    "databases": {
        "title": "Databases (SQL & NoSQL)",
        "quiz": [
            "What are the ACID properties? Explain each one with a real-world example.",
            "Write a SQL query that finds the top 10 customers by total order amount. Include a JOIN.",
            "What is a database index? How does it speed up queries? When can it slow things down?",
            "What does `EXPLAIN ANALYZE` show? How do you use it to diagnose slow queries?",
            "What is connection pooling? Why is it important for SREs? What happens without it?",
            "What is the difference between a primary and a replica? Why do we use replication?",
            "How do you back up a PostgreSQL database? How do you restore it?",
            "What is a deadlock? How does it happen? How can you prevent it?",
            "When would you choose Redis over PostgreSQL? Give a specific use case.",
            "Your database CPU is at 100% and queries are slow. Walk through your diagnosis process.",
        ],
        "labs": [
            ("PostgreSQL Setup and Query Optimization", "Install PostgreSQL, create a schema with at least 2 related tables, load sample data (1000+ rows), write queries with JOINs, and use EXPLAIN ANALYZE to optimize at least one slow query by adding an index.", "PostgreSQL installed and running; Schema with related tables created; Sample data loaded; JOIN queries written; EXPLAIN ANALYZE used; Index added and improvement documented"),
            ("Replication and Failover", "Set up PostgreSQL primary + replica replication. Test failover by stopping the primary and promoting the replica. Document the entire process including recovery.", "Primary and replica configured; Replication working (data syncs); Failover tested and documented; Application can connect to new primary; README includes step-by-step failover guide"),
            ("Database Health Check Script", "Write a script (Python or Bash) that checks: active connections vs max, slow queries, disk usage, replication lag, and table sizes. Output a report.", "Script checks all 5 metrics; Report is formatted and readable; Thresholds defined for alerts; Works against a running PostgreSQL instance; README explains how to run and interpret results"),
        ],
    },
    "web-architecture": {
        "title": "Web Architecture & Protocols",
        "quiz": [
            "Draw the flow of an HTTP request from a user's browser to a database. Label each component.",
            "What is the difference between HTTP/1.1 and HTTP/2? What improvement does HTTP/2 bring?",
            "Explain four different load balancing algorithms. When would you use each?",
            "What is a CDN? How does it reduce latency? What content should and shouldn't be cached?",
            "What is a circuit breaker? Draw a state diagram and explain each state.",
            "What is the difference between a monolith and microservices? Give one advantage and one disadvantage of each.",
            "Explain idempotency. Why is it important for retries? Which HTTP methods are idempotent?",
            "What is rate limiting? Name two algorithms for implementing it.",
            "Describe a cascading failure. How does it happen? How do you prevent it?",
            "You need to design a highly available web application. Describe the architecture, including redundancy at each layer.",
        ],
        "labs": [
            ("3-Tier App Deployment", "Deploy a 3-tier application (web frontend + application server + database). Document the architecture with a diagram. Test that all tiers communicate correctly.", "All 3 tiers deployed and running; Architecture diagram included; Each tier communicates correctly; README documents setup and testing steps"),
            ("Add Caching with Redis", "Add a Redis caching layer to the 3-tier app. Measure response time before and after caching. Document the performance improvement.", "Redis cache layer added; Cache hit/miss logic implemented; Before/after performance measured; Improvement documented with numbers; README explains the caching strategy"),
            ("Load Balancer with Failover", "Set up nginx as a load balancer in front of 2 app instances. Kill one instance and show that traffic routes to the other automatically. Document the failover behavior.", "nginx load balancer configured; 2 app instances running; Traffic distributed across both; Failover tested (kill one, verify traffic routes to other); Recovery tested (restart, verify traffic redistributes); README documents the setup"),
        ],
    },
    "monitoring-observability": {
        "title": "Monitoring & Observability",
        "quiz": [
            "What are the 3 pillars of observability? How do they complement each other?",
            "Explain the difference between a counter, gauge, and histogram in Prometheus. Give one example of each.",
            "Write a PromQL query that calculates the error rate (5xx responses / total responses) over 5 minutes.",
            "What is the 95th percentile latency? Why is it more useful than average latency for SREs?",
            "Explain how Prometheus scrapes metrics. What is a scrape config? What is a target?",
            "What is alert fatigue? How do you prevent it?",
            "Write an Alertmanager rule that pages when a service has been down for more than 2 minutes.",
            "What is the difference between structured and unstructured logging? Why does it matter?",
            "What is distributed tracing? What is a span? What is a trace? How do they help debug latency?",
            "Your monitoring shows high latency but you don't know which component is slow. Walk through your diagnostic process using metrics, logs, and traces.",
        ],
        "labs": [
            ("Prometheus + Grafana Setup", "Install Prometheus and node_exporter. Configure Prometheus to scrape node_exporter. Install Grafana, connect it to Prometheus, and create a dashboard showing CPU, memory, and disk metrics.", "Prometheus installed and scraping; node_exporter running; Grafana connected to Prometheus; Dashboard with at least 3 panels; README documents installation and configuration"),
            ("App Instrumentation", "Write a Python web app that exposes Prometheus metrics (request count, request duration histogram, error count). Run it, scrape with Prometheus, and create a Grafana dashboard for the app.", "Python app exposes /metrics endpoint; At least 3 custom metrics defined; Prometheus scraping the app; Grafana dashboard created for app metrics; README explains the metrics and how to test"),
            ("Complete Alerting Pipeline", "Set up Alertmanager alongside Prometheus. Create alerting rules for: high CPU, service down, and high error rate. Configure Alertmanager to send alerts to a webhook (or Slack). Test all alerts by triggering them.", "Alertmanager installed and connected to Prometheus; 3 alerting rules created; Alerts route to webhook/Slack; Each alert tested and triggered; README documents the alerting setup and testing process"),
        ],
    },
    "docker": {
        "title": "Containers — Docker",
        "quiz": [
            "What is the difference between a container and a virtual machine?",
            "Write a Dockerfile for a Python web app. Explain each instruction.",
            "What is a Docker layer? How does layer caching speed up builds?",
            "What is the difference between `docker run` and `docker exec`?",
            "Why should containers not run as root? How do you run as a non-root user?",
            "What is a Docker volume? Why do you need it? What happens to data without a volume?",
            "Explain what `docker-compose` does. When would you use it instead of plain `docker run`?",
            "What is a multi-stage build? Why does it reduce image size? Show an example.",
            "Your Docker container keeps getting OOMKilled. What does that mean and how do you fix it?",
            "What should go in a `.dockerignore` file and why?",
        ],
        "labs": [
            ("Dockerize a Web App", "Write a Dockerfile for a Python Flask/FastAPI application. Build the image, run the container, and test that the app responds. Document the process.", "Dockerfile written and explained; Image builds successfully; Container runs and app responds on mapped port; README documents build and run commands"),
            ("Multi-Service with Docker Compose", "Create a docker-compose.yml that runs 3 services: a web app, PostgreSQL, and Redis. All services should connect and work together. Document how to start, stop, and check logs.", "docker-compose.yml with 3 services; Services connect correctly; Volumes configured for database persistence; README documents how to start/stop/check logs"),
            ("Optimized Multi-Stage Build", "Build a multi-stage Dockerfile that compiles/builds in one stage and copies only the final artifacts to a slim runtime image. Add resource limits, a non-root user, and a .dockerignore. Compare image sizes before and after.", "Multi-stage Dockerfile written; Non-root user configured; Resource limits set; .dockerignore created; Image size comparison documented; README explains each optimization"),
        ],
    },
    "kubernetes": {
        "title": "Kubernetes",
        "quiz": [
            "What is the difference between a Pod and a Deployment? Why do we use Deployments?",
            "Explain the difference between liveness, readiness, and startup probes. When would you use each?",
            "What is a Kubernetes Service? What are the differences between ClusterIP, NodePort, and LoadBalancer?",
            "Write a kubectl command to view the logs of a crashed pod (including logs from before the crash).",
            "What is a ConfigMap? How does it differ from a Secret? When would you use each?",
            "What are resource requests and limits? Why are they important? What happens when a container exceeds its memory limit?",
            "Your pod is in a CrashLoopBackOff state. Walk through your troubleshooting process.",
            "What is a Horizontal Pod Autoscaler? How does it decide when to scale?",
            "Explain how a Kubernetes Service routes traffic to the correct Pods.",
            "What is etcd? Why is it critical to the Kubernetes cluster? How do you back it up?",
        ],
        "labs": [
            ("Deploy App on Minikube", "Install minikube (or kind). Deploy a simple web app using a Deployment (3 replicas) and a Service. Use kubectl to verify pods are running and the service is accessible.", "minikube/kind running; Deployment with 3 replicas created; Service created and accessible; kubectl commands documented; README explains each YAML file"),
            ("3-Tier App with Probes and ConfigMaps", "Deploy a 3-tier app on Kubernetes: web frontend, API, and database. Add liveness and readiness probes, resource requests/limits, and use ConfigMaps for configuration.", "3 Deployments created with Services; Liveness and readiness probes configured; Resource requests and limits set; ConfigMap used for configuration; README includes all YAML files with explanations"),
            ("HPA with Load Testing", "Set up a Horizontal Pod Autoscaler for a deployment. Install a load testing tool (e.g., hey, k6). Run a load test that triggers auto-scaling. Document the scaling behavior with before/after pod counts.", "HPA configured; Load test run; Pods scaled up under load; Pods scaled down after load removed; Scaling behavior documented with screenshots; README explains the HPA configuration"),
        ],
    },
    "cloud-aws": {
        "title": "Cloud Platforms — AWS",
        "quiz": [
            "What is a VPC? Why do we use public and private subnets? What goes in each?",
            "What is an IAM Role? How does it differ from an IAM User? When would you use each?",
            "What is the principle of least privilege? Give an example of applying it to an S3 bucket.",
            "Explain what an Auto Scaling Group does. How does it decide when to scale?",
            "What is a Security Group? How does it differ from a traditional firewall? What is the best practice for Security Groups?",
            "What is RDS? What are the benefits of using RDS vs running your own database on EC2?",
            "How do you set up a CloudWatch alarm that triggers when EC2 CPU exceeds 80%?",
            "What is an Application Load Balancer? How does it differ from a Network Load Balancer?",
            "Your EC2 instance in a private subnet can't reach the internet. What's likely wrong and how do you fix it?",
            "Name 3 ways to reduce your AWS bill. Which has the biggest impact?",
        ],
        "labs": [
            ("VPC + EC2 Setup", "Create a VPC with one public subnet and one private subnet. Launch a t2.micro EC2 instance in the public subnet. SSH into it from your laptop. Document the entire setup.", "VPC with public and private subnets created; Route tables and internet gateway configured; EC2 instance launched and running; SSH access verified; Security groups follow least privilege; README documents each step"),
            ("HA App with ALB + ASG", "Deploy a highly available application: Launch an AMI with a simple web app, create an Application Load Balancer, set up an Auto Scaling Group across 2 availability zones with min 2 / max 4 instances. Test by terminating an instance.", "ALB created and routing traffic; ASG configured across 2 AZs; Instance termination triggers replacement; Load balancer health checks working; README documents the architecture and setup"),
            ("CloudWatch + Auto Scaling", "Set up CloudWatch alarms for CPU > 80% and memory monitoring. Configure the ASG to scale based on the CloudWatch alarm. Trigger the alarm (e.g., with stress tool) and verify scaling works.", "CloudWatch alarms created; ASG scaling policy linked to alarm; Alarm triggered by load; Scaling occurs automatically; README documents the monitoring and scaling setup"),
        ],
    },
    "infrastructure-as-code": {
        "title": "Infrastructure as Code",
        "quiz": [
            "What is Infrastructure as Code? Name 3 benefits over manual infrastructure management.",
            "What is Terraform state? Why must you not commit it to Git? Where should you store it?",
            "Write the Terraform workflow (the 4 main commands and what each does).",
            "What is Terraform drift? How do you detect it? How do you fix it?",
            "Write a basic Ansible playbook that installs nginx and ensures it's running.",
            "What is idempotency? Why is it important for Ansible? Are Ansible playbooks always idempotent?",
            "What is a Terraform module? Why do we use modules? Give an example of when to use one.",
            "How do you prevent `terraform destroy` from accidentally destroying production resources?",
            "Explain how Terraform and Ansible complement each other. Which does what?",
            "Someone manually changed an AWS security group in the console. Your next `terraform plan` shows unexpected changes. What happened and how do you resolve it?",
        ],
        "labs": [
            ("Terraform Provisioning", "Use Terraform to provision: an EC2 instance, a security group (allow SSH and HTTP), and an S3 bucket. Run terraform init, plan, and apply. Verify all resources exist. Then destroy everything.", "Terraform config files written; terraform init/plan/apply all succeed; All 3 resources created in AWS; terraform destroy cleans up; README documents the process and includes screenshots"),
            ("Ansible Configuration", "Use Ansible to configure a server: install nginx, copy a custom config, deploy a static HTML page, and set up a monitoring agent (e.g., node_exporter). Run the playbook and verify everything works.", "Ansible inventory and playbook written; nginx installed and serving custom page; node_exporter installed and running; Playbook is idempotent (running twice changes nothing); README documents the setup"),
            ("Terraform + Ansible Combined", "Use Terraform to provision an EC2 instance, then use Ansible to configure it (install nginx, deploy app, set up monitoring). Document the complete workflow from provisioning to a running, configured server.", "Terraform provisions EC2; Ansible configures the instance; Full workflow documented; Server is running nginx with a deployed app; Monitoring agent installed; README explains the complete pipeline"),
        ],
    },
    "ci-cd": {
        "title": "CI/CD Pipelines",
        "quiz": [
            "What is the difference between Continuous Integration, Continuous Delivery, and Continuous Deployment?",
            "Draw a standard CI/CD pipeline. Label each stage and explain what happens there.",
            "Explain blue-green deployment. How does it achieve zero downtime? How do you roll back?",
            "Explain canary deployment. How does it differ from blue-green? When is canary better?",
            "What is GitOps? How does it differ from traditional push-based deployment?",
            "Write a GitHub Actions workflow that runs tests on every push. Explain each part.",
            "What is an automatic rollback? How does it work? What triggers it?",
            "Your CI pipeline takes 25 minutes. How would you reduce it to under 10 minutes?",
            "What is a flaky test? Why is it dangerous? How do you deal with it?",
            "A bad deploy reached production and caused an outage. How should your pipeline have prevented this? What do you add?",
        ],
        "labs": [
            ("CI Pipeline with GitHub Actions", "Create a GitHub Actions workflow that: runs on every push to main, installs Python dependencies, runs pytest, builds a Docker image, and pushes it to a container registry (Docker Hub or GHCR).", "Workflow file created; Runs on push to main; Tests executed; Docker image built; Image pushed to registry; README explains the pipeline and how to view results"),
            ("CD to Kubernetes", "Extend the pipeline with a deploy stage that updates a Kubernetes deployment with the new image. Use kubectl rollout status to verify. Document the deployment process.", "Deploy stage added to pipeline; K8s deployment updated with new image; Rollout status checked; Deployment verified; README documents the CD process and rollback steps"),
            ("Canary Deployment with Rollback", "Implement a canary deployment strategy: deploy to 5% of traffic, monitor error rate for 5 minutes, if healthy increase to 100%, if unhealthy roll back automatically. Document the strategy.", "Canary deployment implemented; 5% traffic routing configured; Error rate monitoring during canary; Automatic rollback on error; Manual rollback documented; README explains the canary strategy"),
        ],
    },
    "incident-response": {
        "title": "Incident Response & Postmortems",
        "quiz": [
            "What are the 7 steps of the incident lifecycle? Explain each.",
            "What is the role of the Incident Commander? Why should they NOT fix the issue themselves?",
            "Explain the difference between SEV1, SEV2, SEV3, and SEV4. Give an example of each.",
            "What does 'mitigate first' mean? Why is it more important than finding root cause during an incident?",
            "What is a blameless postmortem? Why is blamelessness important? What happens in a blame culture?",
            "Define MTTD, MTTA, and MTTR. Why does SRE track these metrics?",
            "What is a runbook? What makes a good runbook vs a bad runbook?",
            "Describe an on-call rotation. What is the difference between primary and secondary on-call?",
            "During an incident, how and when should you communicate with stakeholders?",
            "An incident happened because a developer pushed bad code. How do you structure the postmortem to prevent recurrence without blaming the developer?",
        ],
        "labs": [
            ("Write a Runbook", "Write a detailed runbook for a common alert: 'API error rate above 5%'. Include: symptoms, immediate triage steps (with exact commands), common causes, escalation criteria, and post-incident steps. Use the RUNBOOK template.", "Runbook follows the template structure; Includes exact diagnostic commands; Common causes listed; Escalation criteria clear; Post-incident steps included; README explains when to use the runbook"),
            ("Write a Postmortem", "Simulate an incident (or use a real one). Write a complete blameless postmortem using the POSTMORTEM template. Include: summary, impact, timeline, root cause, what went well, what went badly, and action items with owners.", "Postmortem uses the template; Timeline is detailed with timestamps; Root cause is technical (not personal); At least 3 action items with owners and deadlines; Blameless tone throughout; README explains the postmortem process"),
            ("Game Day Exercise", "Run a game day: set up a running application, inject a failure (kill a service, fill up disk, or simulate a bad deploy), respond to the incident using your runbook, resolve it, and write the postmortem. Document the entire exercise.", "Failure injected deliberately; Incident response process followed; Runbook used during response; Issue resolved; Postmortem written; Exercise documented with timeline; README explains the game day setup and what was learned"),
        ],
    },
    "sre-practices": {
        "title": "SRE Practices — SLOs, SLIs, Error Budgets",
        "quiz": [
            "Define SLI, SLO, and SLA. How do they relate to each other?",
            "What is an error budget? If your SLO is 99.9%, what is your monthly error budget in minutes?",
            "Why is 100% the wrong reliability target? What do you lose by aiming for 100%?",
            "What is burn rate? If you're burning budget at 10x, how long until your monthly budget is exhausted?",
            "What are the 4 golden signals? Why are they important? Give one metric for each.",
            "Write an SLI for a web API. Why did you choose this SLI? What makes it user-centric?",
            "What is multi-window, multi-burn-rate alerting? Why is it better than threshold-based alerting?",
            "Explain an error budget policy. What should happen when the budget is exhausted?",
            "What is toil? Why does SRE care about reducing it? Give an example of toil.",
            "Your service's error budget is 80% consumed and it's only week 2 of the month. What actions should you take and why?",
        ],
        "labs": [
            ("Define SLIs and SLOs", "Choose a real or sample service. Define 2-3 SLIs (with specific measurements), set SLOs for each, calculate the error budget, and write a justification for why you chose these targets. Document in a structured format.", "2-3 SLIs defined with clear measurements; SLOs set with justification; Error budget calculated; SLIs are user-centric (not internal metrics); Document is well-structured; README explains the reasoning"),
            ("Burn-Rate Alerting in Prometheus", "Implement multi-window, multi-burn-rate alerting in Prometheus for a service. Create alerting rules for fast burn (page) and slow burn (ticket). Test by simulating errors and verify the alerts fire correctly.", "Burn-rate alerting rules created; Fast burn (page) rule configured; Slow burn (ticket) rule configured; Alerts tested by simulating errors; README explains burn-rate math and the alerting setup"),
            ("Complete SRE Dashboard", "Build a Grafana dashboard that shows: SLO compliance over time, error budget remaining, current burn rate, the 4 golden signals, and active alerts. Use Prometheus as the data source.", "Dashboard shows SLO compliance; Error budget remaining visualized; Burn rate displayed; All 4 golden signals present; Active alerts panel included; Dashboard is clear and usable; README explains each panel"),
        ],
    },
}

def write_quiz(concept, data):
    path = f"concepts/{concept}/quiz.md"
    content = f"# {data['title']} — Quiz (10 questions)\n\n"
    content += "> **Pass requirement:** Score ≥ 8/10. You get ONE retry if you fail.\n"
    content += "> If you fail twice, I will assign remediation tasks before you can reattempt.\n\n"
    for i, q in enumerate(data["quiz"], 1):
        content += f"**Q{i}.** {q}\n\n"
    content += "---\n\n"
    content += "## How to submit your answers\n\n"
    content += "1. Create a file: `concepts/" + concept + "/quiz-answers/punith.md`\n"
    content += "2. Write your answers to all 10 questions in that file\n"
    content += "3. Commit and push to a branch: `quiz/" + concept + "/answers`\n"
    content += "4. Open a Pull Request titled: `quiz(" + concept + "): answers - punith`\n"
    content += "5. I will review your answers, score them, and either pass you or ask you to study again\n\n"
    content += "> **Do not look up answers while taking the quiz the first time.** Test your real knowledge. "
    content += "If you fail honestly, you know what to study. If you cheat, you cheat yourself.\n"
    with open(path, "w") as f:
        f.write(content)
    print(f"  ✅ {path}")

def write_labs(concept, data):
    for i, (title, desc, criteria) in enumerate(data["labs"], 1):
        path = f"concepts/{concept}/lab{i}.md"
        content = f"# {data['title']} — Lab {i}: {title}\n\n"
        content += f"> **Estimated time:** 4–6 hours (weekend)\n"
        content += f"> **Submission:** Open a Pull Request. I will review and may request changes.\n\n"
        content += "## Goal\n\n"
        content += desc + "\n\n"
        content += "## Steps\n\n"
        content += f"1. Read this lab file completely\n"
        content += f"2. Create a branch: `git switch -c labs/{concept}/lab{i}-punith`\n"
        content += f"3. Create your lab folder: `concepts/{concept}/lab-submissions/punith/lab{i}/`\n"
        content += f"4. In that folder, create:\n"
        content += f"   - `README.md` — explain what you did, step by step, with all commands\n"
        content += f"   - Your code/config files (scripts, configs, YAML, etc.)\n"
        content += f"   - `LAB_REPORT.md` — use the template at `templates/LAB_REPORT.md`\n"
        content += f"   - Test outputs / screenshots (if applicable)\n"
        content += f"5. Commit: `git add . && git commit -m \"labs({concept}): lab{i} - {title.lower()} by punith\"`\n"
        content += f"6. Push: `git push -u origin labs/{concept}/lab{i}-punith`\n"
        content += f"7. Open a Pull Request titled: `labs({concept}): lab{i} - {title} — punith`\n"
        content += f"8. In the PR description, include: what you did, commands you ran, how you tested, and a link to your daily note\n\n"
        content += "## Acceptance Criteria (I will check each of these)\n\n"
        content += f"- {criteria}\n"
        content += "- All code/config files are included and functional\n"
        content += "- README is clear enough that someone else could reproduce your work\n"
        content += "- No secrets, passwords, or credentials in any file\n"
        content += "- Commands and their outputs are documented\n\n"
        content += "## Tips\n\n"
        content += "- Start early. Don't wait until the last day.\n"
        content += "- If you're stuck for more than 30 minutes, write down your blocker and move on. Ask me.\n"
        content += "- Test your work before submitting. A PR that doesn't work will be rejected.\n"
        content += "- Document as you go. It's much harder to write the README at the end.\n"
        with open(path, "w") as f:
            f.write(content)
        print(f"  ✅ {path}")

for concept, data in CONCEPTS.items():
    print(f"\nGenerating {concept}:")
    write_quiz(concept, data)
    write_labs(concept, data)

print(f"\n✅ Done! Generated quizzes and labs for {len(CONCEPTS)} concepts.")
