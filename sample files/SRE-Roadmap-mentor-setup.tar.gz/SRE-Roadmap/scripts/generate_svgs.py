#!/usr/bin/env python3
"""
generate_svgs.py — Regenerate progress bar SVGs from progress/status.json.

Generates:
  progress/svg/overall.svg      — overall SRE journey progress
  progress/svg/<concept>.svg    — per-concept progress bar

Also mirrors status.json to docs/progress/status.json for GitHub Pages.

Run manually:   python3 scripts/generate_svgs.py
Run via CI:     .github/workflows/regenerate-svgs.yml
"""
import json
from pathlib import Path
import sys

repo_root = Path('.').resolve()
root_json = repo_root / 'progress' / 'status.json'
docs_json = repo_root / 'docs' / 'progress' / 'status.json'

if root_json.exists():
    status_file = root_json
elif docs_json.exists():
    status_file = docs_json
else:
    print('ERROR: No status.json found in progress/ or docs/progress/', file=sys.stderr)
    sys.exit(1)

with open(status_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

svg_dir = repo_root / 'progress' / 'svg'
docs_progress_dir = repo_root / 'docs' / 'progress'
svg_dir.mkdir(parents=True, exist_ok=True)
docs_progress_dir.mkdir(parents=True, exist_ok=True)

# Mirror root status.json → docs/progress for GitHub Pages
if status_file == root_json:
    with open(docs_json, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
        f.write('\n')


def write_progress_svg(path, label, percent, width=440, height=44,
                       bar_color='#7c3aed', bg_color='#e5e7eb',
                       show_label=True, font_size=14):
    """Write a clean, GitHub-markdown-friendly progress bar SVG."""
    percent = max(0, min(100, int(percent)))
    bar_w = int((width - 20) * percent / 100)
    bar_x = 10
    bar_y = 10 if show_label else 12
    bar_h = height - 20 if show_label else height - 24

    label_y = bar_y - 2
    pct_text = f"{percent}%"
    pct_x = width - 10
    pct_y = bar_y + bar_h // 2 + 5

    label_line = ""
    if show_label:
        label_line = f'  <text x="{bar_x}" y="{label_y}" font-family="Segoe UI,Arial,sans-serif" font-size="{font_size}" font-weight="600" fill="#333">{label}</text>'

    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  <rect width="{width}" height="{height}" fill="white" rx="8"/>
{label_line}
  <rect x="{bar_x}" y="{bar_y + (8 if show_label else 0)}" width="{width - 20}" height="{bar_h}" rx="6" fill="{bg_color}"/>
  <rect x="{bar_x}" y="{bar_y + (8 if show_label else 0)}" width="{bar_w}" height="{bar_h}" rx="6" fill="{bar_color}"/>
  <text x="{pct_x}" y="{bar_y + (8 if show_label else 0) + bar_h // 2 + 5}" font-family="Segoe UI,Arial,sans-serif" font-size="{font_size - 2}" font-weight="700" fill="#333" text-anchor="end">{pct_text}</text>
</svg>'''
    path.write_text(svg, encoding='utf-8')


# ─── Overall SRE journey progress (big bar) ───
overall = data.get('overall', 0)
# If overall is 0 but concepts exist, compute from average
concepts = data.get('concepts', {})
if not overall and concepts:
    vals = [v for v in concepts.values() if isinstance(v, (int, float))]
    if vals:
        overall = round(sum(vals) / len(vals))
write_progress_svg(svg_dir / 'overall.svg', 'Overall SRE Journey', overall,
                   width=600, height=60, bar_color='#7c3aed', font_size=18)

# ─── Per-concept progress bars ───
for name, pct in concepts.items():
    write_progress_svg(svg_dir / f'{name}.svg', name.replace('-', ' ').title(), pct,
                       width=440, height=44, bar_color='#06b6d4')

# ─── Phase-level progress bars ───
phase_completion = data.get('phase_completion', {})
for phase_name, pct in phase_completion.items():
    slug = phase_name.lower().replace(' ', '-')
    write_progress_svg(svg_dir / f'phase-{slug}.svg', f'{phase_name} Phase', pct,
                       width=440, height=44, bar_color='#f59e0b')

print(f'SVG generation complete: {len(concepts)} concepts + overall + {len(phase_completion)} phases')
