// app.js - resilient dashboard loader with inline JSON fallback
(async function(){
  // First, check for an inlined JSON block in the page to avoid relying on Pages propagation
  let data = null;
  try{
    const inline = document.getElementById('status-json');
    if(inline){
      data = JSON.parse(inline.textContent);
      console.log('Loaded status.json from inline script');
    }
  }catch(e){
    console.warn('Failed to parse inline status JSON', e);
    data = null;
  }

  if(!data){
    // Candidate paths tried in order (covers both /docs and root Pages URLs and common mistyped URLs)
    const candidates = [
      '../progress/status.json',    // from /<repo>/dashboard/index.html -> /<repo>/progress/status.json
      '../../progress/status.json',  // from /<repo>/docs/dashboard/index.html -> /<repo>/docs/progress/status.json
      '/progress/status.json',      // absolute path (site root + /progress)
      '/SRE-Roadmap/progress/status.json', // explicit repo path
      'progress/status.json'        // relative to current location
    ];

    async function fetchFirst(urls){
      for(const u of urls){
        try{
          const res = await fetch(u);
          if(res.ok){
            console.log('Loaded status.json from', u);
            const json = await res.json();
            return json;
          } else {
            console.warn('Fetch', u, '->', res.status);
          }
        }catch(e){
          console.warn('Fetch failed', u, e.message);
        }
      }
      throw new Error('All fetch attempts failed');
    }

    try{
      data = await fetchFirst(candidates);
    }catch(e){
      console.error(e);
      document.getElementById('summary-text').textContent = 'Unable to load progress/status.json — attempted several locations. Please ensure progress/status.json is published. See console for paths tried.';
      return;
    }
  }

  // Safe defaults
  data.concepts = data.concepts || {};
  data.phase_completion = data.phase_completion || {};
  data.roadmap = data.roadmap || [];
  data.weekly_hours_by_phase = data.weekly_hours_by_phase || {};

  // Overall
  const overall = typeof data.overall === 'number' ? data.overall : calculateOverall(data.concepts);
  document.getElementById('summary-text').textContent = `${overall}% overall completion — keep pushing.`;

  // KPI cards
  const kpiRow = document.getElementById('kpiRow');
  const kpis = [
    {label: 'Total study hours', key: 'study_hours_total', format: v=>v+'h'},
    {label: 'Current streak (days)', key: 'current_streak_days', format: v=>v+'d'},
    {label: 'Labs completed', key: 'labs_completed', extra: '/'+(data.labs_total||0), format: v=>v},
    {label: 'Modules done', key: 'modules_done', extra: '/'+(data.modules_total||0), format: v=>v},
    {label: 'Avg hours/day (30d)', key: 'avg_hours_day_30d', format: v=>v+'h'},
    {label: 'SRE Score', key: 'sre_score', format: v=>v}
  ];

  kpis.forEach(k=>{
    const card = document.createElement('div'); card.className='kpi-card';
    const val = document.createElement('div'); val.className='kpi-value';
    const raw = data[k.key] !== undefined ? data[k.key] : 0;
    val.textContent = (k.format? k.format(raw) : raw) + (k.extra||'');
    const label = document.createElement('div'); label.className='kpi-label'; label.textContent = k.label;
    card.appendChild(val); card.appendChild(label);
    kpiRow.appendChild(card);
  });

  // Overall doughnut
  const ctx = document.getElementById('overallChart').getContext('2d');
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Completed','Remaining'],
      datasets: [{
        data: [overall, Math.max(0, 100-overall)],
        backgroundColor: ['#7c3aed', '#0b1220'],
        borderWidth:0
      }]
    },
    options: {cutout: '70%', plugins:{legend:{display:false},tooltip:{enabled:false}}}
  });

  // Concept bar
  const concepts = Object.keys(data.concepts||{});
  const percents = concepts.map(k=>data.concepts[k]||0);
  const barCtx = document.getElementById('conceptBar').getContext('2d');
  new Chart(barCtx, {
    type:'bar',
    data:{labels:concepts, datasets:[{label:'% complete',data:percents,backgroundColor:'#06b6d4'}]},
    options:{plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,max:100}}}
  });

  // Phase donut
  const phaseKeys = Object.keys(data.phase_completion);
  const phaseVals = phaseKeys.map(k=>data.phase_completion[k]);
  const phaseCtx = document.getElementById('phaseDonut').getContext('2d');
  new Chart(phaseCtx,{type:'doughnut',data:{labels:phaseKeys,datasets:[{data:phaseVals,backgroundColor:['#7c3aed','#06b6d4','#f59e0b']} ]},options:{plugins:{legend:{position:'right'}}}});

  // Roadmap
  const roadmapEl = document.getElementById('roadmap');
  data.roadmap.forEach(item => {
    const row = document.createElement('div'); row.className='roadmap-item';
    const label = document.createElement('div'); label.className='roadmap-label';
    const left = document.createElement('div'); left.textContent = `${item.phase} — ${item.months}`;
    const right = document.createElement('div'); right.textContent = `${item.percent}%`;
    label.appendChild(left); label.appendChild(right);
    const barWrap = document.createElement('div'); barWrap.className='roadmap-bar';
    const inner = document.createElement('div'); inner.className='roadmap-bar-inner';
    inner.style.width = (item.percent||0) + '%';
    barWrap.appendChild(inner);
    row.appendChild(label); row.appendChild(barWrap);
    roadmapEl.appendChild(row);
  });

  // Weekly stacked bar (convert weekly_hours_by_phase to Chart datasets)
  const weekly = data.weekly_hours_by_phase || {};
  const weeks = Object.keys(weekly);
  // Collect unique phase names
  const phaseSet = new Set();
  weeks.forEach(w=> Object.keys(weekly[w]||{}).forEach(p=>phaseSet.add(p)));
  const phases = Array.from(phaseSet);
  const datasets = phases.map((ph,idx)=>({label:ph,data:weeks.map(w=>weekly[w][ph]||0),backgroundColor:phaseColor(idx)}));
  const stackedCtx = document.getElementById('weeklyStacked').getContext('2d');
  new Chart(stackedCtx,{type:'bar',data:{labels:weeks,datasets:datasets},options:{plugins:{legend:{position:'top'}},scales:{x:{stacked:true},y:{stacked:true,beginAtZero:true}}}});

  function calculateOverall(obj){
    const vals = Object.values(obj||{}).filter(v=>typeof v==='number');
    if(!vals.length) return 0;
    const sum = vals.reduce((a,b)=>a+b,0);return Math.round(sum/vals.length);
  }
  function phaseColor(i){
    const cols = ['#7c3aed','#06b6d4','#f59e0b','#ef4444','#10b981'];
    return cols[i % cols.length];
  }
})();
