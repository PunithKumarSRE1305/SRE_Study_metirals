# SSH setup for GitHub (Windows / macOS / Linux)

Using SSH keys avoids typing your password every time and is the recommended setup for development.

1) macOS / Linux (bash)
- Generate key:
  ssh-keygen -t ed25519 -C "you@example.com"
  - Press Enter to accept defaults
- Start the ssh-agent and add the key:
  eval "$(ssh-agent -s)"
  ssh-add ~/.ssh/id_ed25519
- Copy the public key and add to GitHub:
  cat ~/.ssh/id_ed25519.pub
  - Copy the output and paste into GitHub -> Settings -> SSH and GPG keys -> New SSH key
- Test:
  ssh -T git@github.com
  - You should see a message like "Hi <username>! You've successfully authenticated..."

2) Windows (Git Bash)
- Open Git Bash
- Generate key:
  ssh-keygen -t ed25519 -C "you@example.com"
- Follow the same steps as above to add the public key to GitHub
- If using PuTTY or Pageant, consult GitHub docs for Pageant integration.

3) If you prefer HTTPS (no SSH keys)
- Use: git clone https://github.com/PunithKumarSRE1305/SRE-Roadmap.git
- GitHub now requires a Personal Access Token (PAT) for CLI pushes instead of a password. Create a PAT in GitHub Settings -> Developer settings -> Personal access tokens. Use the token when prompted for a password.

4) Troubleshooting
- Permission denied (publickey): likely your key not added to GitHub or ssh-agent not running
- Use ssh -v git@github.com for verbose debugging

