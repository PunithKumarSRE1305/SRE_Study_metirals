# Where Do I Run Git Commands? (Absolute Beginner Guide)

> You asked: "Do I need to open CMD in my system? Or in any other platform? How to connect it to GitHub?"
>
> This guide answers all of that. Read it fully before 15 August 2026.

---

## The Short Answer

**You run git commands in a "terminal" on YOUR computer.** The terminal is a text-based window where you type commands. Every operating system has one. You do NOT need a special platform — your own laptop/desktop is enough.

| Your Operating System | What to use | What it looks like |
|---|---|---|
| **Windows** | Git Bash (installs with Git for Windows) or PowerShell | A black/white text window |
| **Mac** | Terminal (built-in) or iTerm2 | A black text window |
| **Linux** | Terminal (built-in) | A black text window |

> **Recommendation for Windows users:** Install "Git for Windows" — it gives you both Git AND a tool called "Git Bash" which works exactly like a Linux terminal. This makes learning much easier because all tutorials use Linux-style commands.

---

## Step 1: Install Git on Your Computer

### Windows (most common for beginners)
1. Go to: **https://git-scm.com/download/win**
2. The download should start automatically. If not, click "Click here to download"
3. Run the downloaded `.exe` file
4. Click "Next" through the installer — **keep all default options** (don't change anything unless you know why)
5. When it finishes, you now have:
   - **Git** (the tool)
   - **Git Bash** (a terminal that works like Linux)
   - **Git GUI** (a visual tool — you can ignore this for now)

**Verify it worked:**
1. Press `Windows key`, type `git bash`, press Enter
2. A terminal window opens
3. Type: `git --version` and press Enter
4. You should see something like: `git version 2.43.0`
5. ✅ Git is installed!

### Mac
1. Open Terminal (Press `Cmd + Space`, type "terminal", press Enter)
2. Type: `git --version`
3. If it's already installed, you'll see the version number. ✅
4. If not, macOS will prompt you to install Command Line Tools. Click "Install"
5. Or install via Homebrew: `brew install git`

### Linux (Ubuntu/Debian)
1. Open Terminal
2. Run: `sudo apt update && sudo apt install git -y`
3. Verify: `git --version`

---

## Step 2: Tell Git Who You Are (one-time setup)

Git needs to know your name and email (this gets attached to every commit you make).

Open your terminal (Git Bash on Windows) and type:

```bash
git config --global user.name "Punith Kumar"
git config --global user.email "your-email@gmail.com"
```

> Use the **same email** that your GitHub account uses.

Verify it worked:
```bash
git config --global user.name
git config --global user.email
```
You should see your name and email printed back. ✅

---

## Step 3: Connect Your Computer to GitHub

There are **two ways** to connect. You only need ONE.

### Method A: HTTPS (easier, recommended for beginners)
1. Go to GitHub: **https://github.com/settings/tokens**
2. Click "Generate new token" → "Generate new token (classic)"
3. Give it a name like "my-laptop"
4. Under "Select scopes", check the box next to **`repo`** (this gives access to your repositories)
5. Click "Generate token" at the bottom
6. **COPY the token** — you will NOT be able to see it again. Save it somewhere safe.
7. Now when you clone or push, Git will ask for your username and password. Use your GitHub username and **paste the token as the password**.

> The token is like a password but more secure. You can create multiple tokens (one per computer) and delete them anytime.

### Method B: SSH (more secure, set up once and never type passwords again)
Follow the guide at [docs/ssh-setup.md](ssh-setup.md). This is a one-time setup. After that, you never type a password again.

> **My recommendation:** Start with HTTPS (Method A). Once you're comfortable, switch to SSH (Method B).

---

## Step 4: Clone Your Repository (download the repo to your computer)

"Cloning" means copying the entire repository from GitHub to your computer so you can work on it locally.

1. Open your terminal
2. Navigate to where you want the repo (e.g., your Desktop or Documents folder):
   ```bash
   cd ~/Desktop
   ```
   (On Windows Git Bash, `~` means your user folder, e.g., `C:\Users\YourName`)

3. Clone the repo:
   ```bash
   git clone https://github.com/PunithKumarSRE1305/SRE-Roadmap.git
   ```
   (If using SSH: `git clone git@github.com:PunithKumarSRE1305/SRE-Roadmap.git`)

4. Enter the repo folder:
   ```bash
   cd SRE-Roadmap
   ```

5. ✅ You now have the full repository on your computer! You should see all the files:
   ```bash
   ls
   ```
   (This should show: `README.md  concepts  docs  plan  progress  scripts  templates  ...`)

---

## Step 5: Where Do I Type Commands From Now On?

**ALWAYS open your terminal in the repository folder.**

### On Windows (Git Bash):
1. Open File Explorer and navigate to your `SRE-Roadmap` folder
2. **Right-click** inside the folder
3. Click **"Git Bash Here"**
4. A terminal opens, already in the right folder ✅

### On Mac:
1. Open Terminal
2. Type: `cd ~/Desktop/SRE-Roadmap` (or wherever you cloned it)
3. ✅ You're in the repo

### On Linux:
1. Open Terminal
2. `cd ~/SRE-Roadmap` (or wherever you cloned it)
3. ✅ You're in the repo

> **Quick check:** Type `pwd` in the terminal. It should print the path to your SRE-Roadmap folder. Type `ls` to see the files. If you see `README.md` and `concepts/`, you're in the right place.

---

## Alternative Methods (If You Don't Want to Use the Terminal)

If the terminal feels scary, you can use visual tools instead. **But I recommend learning the terminal** — every SRE job requires it.

### Option 1: GitHub Web UI (no installation needed)
You can edit files directly on GitHub.com:
1. Go to https://github.com/PunithKumarSRE1305/SRE-Roadmap
2. Navigate to any file
3. Click the ✏️ "Edit" button
4. Make changes
5. Click "Commit changes"
6. This works but is **slow for labs** (you can't run/test code on GitHub's web UI)

### Option 2: VS Code (recommended editor)
1. Download and install: **https://code.visualstudio.com/**
2. Open VS Code
3. Open the `SRE-Roadmap` folder (File → Open Folder)
4. VS Code has a **built-in terminal** (View → Terminal, or press `` Ctrl+` ``)
5. VS Code also has a **visual Git interface** (the source control icon on the left sidebar)
6. You can edit files, see changes, stage, commit, and push — all from VS Code

### Option 3: GitHub Desktop (visual Git tool)
1. Download: **https://desktop.github.com/**
2. Sign in with your GitHub account
3. Clone the repo through the app
4. You can commit and push with buttons (no commands)
5. **Limitation:** You can't run code or tests with this — only manage Git

### My recommendation for you:
1. **Install VS Code** — use it as your code editor and terminal
2. **Learn the basic git commands** (clone, branch, add, commit, push, pull)
3. **Use the terminal inside VS Code** for all git commands
4. Use GitHub's web UI only for opening Pull Requests and reviewing

---

## The Complete Daily Workflow (Step by Step)

Here's exactly what you do every study day, from opening your computer to submitting your work:

### 1. Open VS Code and the repo
```
Open VS Code → File → Open Folder → select SRE-Roadmap
```

### 2. Open the terminal in VS Code
```
View → Terminal  (or press Ctrl + `)
```

### 3. Get the latest changes from GitHub
```bash
git checkout main
git pull origin main
```
(This makes sure you have the latest version of the repo)

### 4. Create a branch for today's work
```bash
git switch -c notes/linux/2026-08-15
```
(This creates a new "branch" — a separate workspace for your changes)

### 5. Do your work
- Study the concept
- Create your daily note file in `progress/daily-notes/`
- Write code/config for labs if it's a lab day

### 6. Save your work (commit)
```bash
git add .
git commit -m "notes(linux): daily note for 2026-08-15"
```
(`git add .` stages all changes, `git commit` saves a snapshot with a message)

### 7. Upload to GitHub (push)
```bash
git push -u origin notes/linux/2026-08-15
```
(This uploads your branch to GitHub)

### 8. Open a Pull Request
1. Go to https://github.com/PunithKumarSRE1305/SRE-Roadmap
2. You'll see a yellow/green banner: "notes/linux/2026-08-15 had recent pushes"
3. Click **"Compare & pull request"**
4. Add a title and description
5. Click **"Create pull request"**
6. ✅ Done! I (your mentor) will review it.

---

## Common Mistakes Beginners Make (Avoid These)

| Mistake | Why it's bad | What to do instead |
|---|---|---|
| Committing directly to `main` | Breaks the review process | Always create a branch first |
| Not writing a commit message | Can't tell what changed | Always use `git commit -m "clear message"` |
| Forgetting `git pull` before working | Causes conflicts | Always `git pull origin main` first |
| Committing passwords/secrets | Security risk | Never put passwords in code. Use environment variables |
| Not pushing after committing | Your work is only on your computer | Always `git push` after committing |
| Deleting files manually instead of with `git rm` | Git gets confused | Use `git rm <file>` to remove tracked files |

---

## Quick Command Reference (the only 10 you need daily)

| Command | What it does | When to use it |
|---|---|---|
| `git pull origin main` | Download latest changes from GitHub | Before you start working each day |
| `git switch -c <branch-name>` | Create and switch to a new branch | Before making any changes |
| `git status` | See what files changed | Anytime you want to check what's different |
| `git add .` | Stage all changes for commit | When you're ready to save |
| `git commit -m "message"` | Save a snapshot with a message | After staging, to record your work |
| `git push -u origin <branch>` | Upload your branch to GitHub | After committing, to share your work |
| `git log --oneline` | See recent commit history | When you want to see what you've done |
| `git diff` | See unstaged changes | Before committing, to review your work |
| `git checkout main` | Switch back to main branch | When you want to go back to the main version |
| `git branch` | List all branches | When you forget which branch you're on |

---

## What If Something Goes Wrong?

| Problem | Fix |
|---|---|
| "fatal: not a git repository" | You're not in the repo folder. `cd` into the SRE-Roadmap folder first |
| "Permission denied (publickey)" | SSH key not set up. Use HTTPS instead, or follow [ssh-setup.md](ssh-setup.md) |
| "fatal: refusing to merge unrelated histories" | You probably cloned into an existing folder. Delete and re-clone |
| Merge conflict | Open the file, look for `<<<<<<<` markers, pick the right version, remove markers, then `git add` and `git commit` |
| "error: failed to push some refs" | Someone else pushed changes. Run `git pull origin main` first, then push again |
| I committed to the wrong branch | `git reset HEAD~1` (undoes the last commit but keeps your changes), then switch to the right branch and commit again |

> **When in doubt:** Don't panic. Create a note describing the problem, and ask me. I'm your mentor — I'll help you fix it.
