# Git Basics — Explained Like You're in 1st Year Engineering

> **You said:** "What is commit? What is Pull? What is push? What do those do? Why do we use them?"
>
> This guide answers ALL of that. Read it slowly. Read it twice. Then practice.

---

## 1. The Big Picture (What Problem Does Git Solve?)

Imagine you're writing a project report with 3 friends. Here's what happens WITHOUT Git:

```
report_v1.docx
report_v2.docx
report_final.docx
report_final_v2.docx
report_FINAL_FINAL.docx
report_really_final.docx
```

**Problems:**
- Who changed what? No idea.
- What if you delete the wrong file? Gone forever.
- How do you merge two people's changes? Copy-paste nightmare.
- Want to go back to yesterday's version? Which file was that?

**Git solves ALL of these:**
- ✅ Tracks every change (who, what, when, why)
- ✅ Never loses anything (even deleted files can be recovered)
- ✅ Merges changes automatically (mostly)
- ✅ Go back to ANY point in time

---

## 2. Git vs GitHub (Don't Confuse These)

| Git | GitHub |
|---|---|
| A tool that runs on YOUR computer | A website that stores your code online |
| Tracks file changes | Lets you share code with others |
| Works offline | Needs internet |
| Like a camera taking snapshots | Like Instagram where you upload photos |
| Free, open source | Owned by Microsoft (free for public repos) |

**You use BOTH:** Git on your computer to track changes, GitHub to store and share them.

---

## 3. The Core Concepts (With Simple Analogies)

### 📸 Commit = A Save Point
Think of a video game. When you reach a checkpoint, you "save." A commit is exactly that — a save point for your code.

```
Commit 1: "Add README file"           ← saved at this point
Commit 2: "Add Linux concept folder"   ← saved at this point
Commit 3: "Fix typo in README"         ← saved at this point
```

Each commit records:
- **What changed** (which files, which lines)
- **When** (timestamp)
- **Who** (your name and email)
- **Why** (the commit message you write)

You can ALWAYS go back to any commit. It's like a time machine.

### 🌿 Branch = A Parallel Universe
Imagine you're building a house. You want to try a new paint color, but you're not sure it'll look good. You don't paint the actual house — you build a COPY and try the color there.

A branch is that copy. You make changes on a branch without affecting the "main" version. If the changes are good, you merge them back. If not, you throw the branch away.

```
main ────────●──────●──────●──────●──────
               \                          ← branch off here
                ●──●──●  (your branch)   ← make changes here
               /
main ────────●──●──●──●──●──●──  ← merge back here
```

**Rule: NEVER work directly on `main`. Always create a branch first.**

### ⬆️ Push = Upload to GitHub
When you commit, the save point is only on YOUR computer. `push` uploads it to GitHub so others can see it.

```
Your Computer                         GitHub
[commit, commit, commit]  --push-->  [now GitHub has them too]
```

### ⬇️ Pull = Download from GitHub
When someone else pushes changes to GitHub, you need to get them. `pull` downloads the latest changes to your computer.

```
Your Computer                         GitHub
[you're behind]  <--pull---  [latest changes from others]
```

### 🔀 Pull Request (PR) = "Please Review My Work"
A Pull Request is you saying: "I made changes on my branch. Please review them and merge them into main."

```
You: "Hey mentor, I completed Lab 1. Here's my branch. Please review."
     → Open a Pull Request on GitHub
Mentor: "Looks good!" (approves) or "Fix this." (requests changes)
     → Merge the PR → your changes go into main
```

### 📥 Clone = Download the Whole Project
`clone` copies the entire repository from GitHub to your computer. You do this once at the beginning.

```
GitHub                          Your Computer
[entire repo]  ----clone---->  [full copy on your laptop]
```

---

## 4. Every Command Explained (What, Why, When)

### Setup commands (run ONCE)
```bash
# Tell Git who you are (your name appears on every commit)
git config --global user.name "Punith Kumar"
git config --global user.email "your-email@gmail.com"
```

### Daily commands (run EVERY DAY)

| Command | What it does | Why you use it | When |
|---|---|---|---|
| `git pull origin main` | Download latest changes from GitHub | So you're working on the latest version | Before you start working |
| `git switch -c branch-name` | Create a new branch and switch to it | To work safely without breaking main | Before making any changes |
| `git status` | Show what files changed | To see what you've modified | Anytime — check your progress |
| `git add .` | Stage all changes (prepare to save) | Tell Git "I want to save these changes" | When you're ready to commit |
| `git add file.txt` | Stage one specific file | When you only want to save one file | When you have mixed changes |
| `git commit -m "message"` | Save a snapshot with a message | Create a save point | After staging, to record your work |
| `git push -u origin branch` | Upload your branch to GitHub | Share your work so it can be reviewed | After committing |
| `git log --oneline` | Show recent commits | See what you've done | When you want to review history |
| `git diff` | Show what changed but not saved | Review before committing | Before you stage/commit |
| `git checkout main` | Switch back to main branch | Go back to the stable version | When you're done on your branch |

### Less common but important commands

| Command | What it does | When to use |
|---|---|---|
| `git branch` | List all branches | When you forget which branch you're on |
| `git branch -a` | List all branches including remote | When you want to see all branches |
| `git merge branch-name` | Merge another branch into current | When you want to combine changes |
| `git fetch origin` | Download remote info without merging | When you want to see what's new without changing your work |
| `git revert commit-hash` | Create a new commit that UNDOES a previous commit | When you need to undo a change that's already pushed |
| `git reset HEAD~1` | Undo the last commit (keep changes) | When you committed too early |
| `git stash` | Temporarily save uncommitted changes | When you need to switch branches but aren't ready to commit |
| `git stash pop` | Restore stashed changes | When you come back to your work |
| `git remote -v` | Show remote repository URL | When you want to check where you're pushing to |
| `git rm file.txt` | Remove a file AND stage the deletion | When you want to delete a tracked file |
| `git bisect` | Find which commit introduced a bug | When something broke but you don't know when |

---

## 5. The Complete Daily Workflow (Memorize This)

```
┌─────────────────────────────────────────────────────────────┐
│                    YOUR DAILY GIT WORKFLOW                   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. git checkout main          ← Go to main branch           │
│  2. git pull origin main       ← Get latest from GitHub      │
│  3. git switch -c my-branch    ← Create a new branch         │
│                                                              │
│  4. (edit files, write code, study)                          │
│                                                              │
│  5. git status                 ← Check what changed          │
│  6. git add .                  ← Stage all changes           │
│  7. git commit -m "message"    ← Save a snapshot             │
│  8. git push -u origin my-branch ← Upload to GitHub          │
│                                                              │
│  9. Go to GitHub.com           ← Open in browser             │
│ 10. Click "Compare & pull request" ← Start a PR             │
│ 11. Write a title and description ← Describe your changes    │
│ 12. Click "Create pull request" ← Submit for review          │
│                                                              │
│  13. Wait for mentor review   ← I review and respond         │
│  14. Fix if requested         → commit → push (PR updates)   │
│  15. Merged! ✅               ← Your changes are in main     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 6. Commit Message Rules (Good vs Bad)

**GOOD commit messages** (follow this format):
```
type(scope): description

Examples:
  feat(monitoring): add Prometheus scrape config
  fix(nginx): increase worker_connections
  docs(runbook): update database failover steps
  labs(linux): lab1 - systemd web app
  notes(linux): daily note for 2026-08-15
  quiz(linux): answers - attempt 1
```

Types: `feat` (new feature), `fix` (bug fix), `docs` (documentation), `labs` (lab submission), `notes` (daily note), `quiz` (quiz answers), `ci` (CI changes), `chore` (maintenance)

**BAD commit messages** (NEVER do this):
```
update                    ← What did you update?
fix                       ← Fix what?
asdfasdf                  ← Meaningless
final version             ← There's no "final" version in Git
changes                   ← What changes?
.                         ← Seriously?
```

---

## 7. What Is a Merge Conflict? (And How to Fix It)

A merge conflict happens when two people change the SAME LINE of code. Git doesn't know which version to keep, so it asks you.

```
When you see this in your file:

<<<<<<< HEAD
Your version of the line
=======
Their version of the line
>>>>>>> branch-name

FIX IT:
1. Delete the markers (<<<<<<<, =======, >>>>>>>)
2. Keep the correct version (or combine both)
3. Save the file
4. git add <file>
5. git commit -m "resolve merge conflict in <file>"
```

---

## 8. Safety Rules (Follow These or Regret It Later)

| Rule | Why | What happens if you don't |
|---|---|---|
| NEVER commit passwords/secrets | Secrets in Git history are nearly impossible to fully remove | Security breach, need to rotate all secrets |
| ALWAYS work on a branch | Protects the main version | You break main, everyone suffers |
| ALWAYS write a commit message | Future you won't remember what changed | Useless history, can't find anything |
| ALWAYS `git pull` before working | Get latest changes | Merge conflicts, overwritten work |
| NEVER use `git push --force` on shared branches | Overwrites others' work | You delete someone's commits |
| Commit small, commit often | Easier to review and revert | Huge commits that are hard to review |

---

## 9. Where to Learn More

- **Pro Git (free book):** https://git-scm.com/book/en/v2 — read chapters 1-3
- **Learn Git Branching (interactive game):** https://learngitbranching.js.org/
- **Git visualizer:** https://onlywei.github.io/explain-git-with-d3/
- **GitHub Docs:** https://docs.github.com/en

---

## 10. Quick Reference Card (Print This)

```
SETUP (once):
  git config --global user.name "Your Name"
  git config --global user.email "you@email.com"

DAILY (every time you work):
  git checkout main
  git pull origin main
  git switch -c your-branch-name
  (make changes)
  git add .
  git commit -m "type(scope): description"
  git push -u origin your-branch-name
  (open PR on GitHub.com)

CHECK STATUS:
  git status          ← what changed?
  git log --oneline   ← what's the history?
  git diff            ← what's unstaged?
  git branch          ← which branch am I on?

EMERGENCY:
  git reset HEAD~1    ← undo last commit (keep changes)
  git stash           ← save changes temporarily
  git stash pop       ← restore saved changes
```
