# LAB_REPORT Template

> Copy this file into your lab submission folder and fill it in.

## Lab Report: [Concept Name] — Lab [X]

### Your Name
Punith Kumar

### Date
[YYYY-MM-DD]

### Time Spent
[hours]

---

## What I Built
[Describe what you created in 2-3 sentences]

## Commands I Ran
```
# List every command you ran, in order
command 1
command 2
command 3
```

## How I Tested
[Describe how you verified your work works. Include test commands and expected vs actual output.]

```
# Test commands and their output
$ [test command]
[output]
```

## Evidence
[Screenshots, log output, or other proof that it works]

## Challenges I Faced
[List any problems you encountered and how you solved them]

## What I Learned
[2-3 things you learned from this lab]

## Checklist
- [ ] All required files are included
- [ ] Code/config works as described
- [ ] README explains how to reproduce
- [ ] No secrets or credentials in any file
- [ ] Test evidence included
