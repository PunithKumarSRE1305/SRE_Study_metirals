# WEEKLY_JOURNAL Template

> Copy this file, rename it to `progress/weekly-journals/YYYY-WW-punith.md`, and fill it in every Sunday.

## Weekly Journal — Week [WW] ([start date] to [end date])

### Total Study Hours This Week
[hours] (target: 12–14)

---

### Concepts I Worked On
- [Concept name]: [what you studied]

### Labs Completed / Submitted
- [ ] Lab X for [concept] — [PR link or "in progress"]
- [ ] Lab Y for [concept] — [PR link or "in progress"]

### Quizzes Attempted
- [ ] Quiz for [concept] — [score] / [pass/fail]

---

### What Went Well
- [List what you accomplished]

### What I Struggled With
- [List topics that were difficult]

### Blockers / Questions for Mentor
- [Any questions or things you need help with]

---

### 3 Goals for Next Week
1. [goal 1]
2. [goal 2]
3. [goal 3]

### Days Missed This Week
- [List any days you didn't study and why]
- (If you missed 2+ weekdays, I will assign remediation)

---

### Mentor Notes
[Leave blank — I will fill this in after review]
