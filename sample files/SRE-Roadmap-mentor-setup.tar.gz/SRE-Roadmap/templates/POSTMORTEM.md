# POSTMORTEM Template

Title: Short summary

Timeline:
- What happened and when

Impact:
- Who/what was affected and for how long

Root cause:
- Technical root cause

Remediation:
- Short term and long-term fixes

Actions:
- Assigned owners and deadlines
