# RUNBOOK Template

Title: [Service Name] - Runbook

Overview
- Service purpose
- Criticality and SLO reference

Symptoms
- What an alert looks like
- Common causes

Immediate triage
1. Check metrics: list metrics and dashboards
2. Check logs: where to find logs and common error messages
3. Quick remediation steps (commands to run)

Escalation
- When to escalate and to whom

Post-incident
- Collect logs and timeline
- Open a postmortem link and follow the POSTMORTEM.md template
