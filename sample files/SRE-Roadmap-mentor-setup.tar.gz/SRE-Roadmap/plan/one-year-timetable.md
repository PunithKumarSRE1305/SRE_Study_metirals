# One-Year SRE Timetable — Day-Wise (15 Aug 2026 → 14 Aug 2027)

> **Start date:** 15 August 2026 (Saturday)
> **End date:** 14 August 2027
> **Your background:** Performance Engineer, works 11 hours/day
> **Study budget:** ~1.5–2h weekdays, ~4–6h weekends → **~12–14h/week, ~625h/year**
> **Total concepts:** 15 (each requires quiz ≥8/10 + 3 labs)

---

## How to Read This Timetable

Each concept gets **~3 weeks (21 days)**. The daily structure within those 3 weeks:

| Day | Type | Hours | What you do |
|---|---|---|---|
| Mon | Weekday | 1.5–2h | Study theory — read concept README sections, take notes |
| Tue | Weekday | 1.5–2h | Study theory — continue, practice commands/examples |
| Wed | Weekday | 1.5–2h | Hands-on practice — follow along with examples |
| Thu | Weekday | 1.5–2h | Hands-on practice — try variations, break things, fix them |
| Fri | Weekday | 1.5–2h | Review + start lab prep — read lab1 instructions |
| Sat | Weekend | 4–5h | **Lab work** — build lab1, test, document |
| Sun | Weekend | 3–4h | **Lab work** — finish lab1, submit PR + write weekly journal |

> **Week 1 of each concept:** Theory + Lab 1
> **Week 2 of each concept:** Deeper theory + Lab 2
> **Week 3 of each concept:** Lab 3 + Quiz + Get concept approved

---

## Phase 1: Foundation (Weeks 1–12, Aug–Nov 2026)

### Concept 1: Linux Fundamentals (Weeks 1–3, 15 Aug – 4 Sep 2026)

**Week 1 (15–21 Aug) — Processes, Filesystem, Users**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 15 Aug | **Day 1:** What is Linux? Why SREs need it. Filesystem hierarchy (/etc, /var, /proc). Open terminal, run basic commands (ls, cd, pwd, cat, less) | Daily note + commit |
| Sun | 16 Aug | File permissions (chmod, chown), users and groups (useradd, usermod). Start **Lab 1**: deploy a simple app with systemd | Lab 1 work |
| Mon | 17 Aug | Processes (ps, top, htop, kill, signals). What is a PID? | Daily note |
| Tue | 18 Aug | systemd — what it is, systemctl commands, unit files | Daily note |
| Wed | 19 Aug | Logs — journalctl, /var/log, log levels, structured logs | Daily note |
| Thu | 20 Aug | Disk and memory — df, du, free, iostat, vmstat. Finish Lab 1 | Lab 1 PR |
| Fri | 21 Aug | Review week. Write weekly journal. Start reading Lab 2 | Weekly journal |

**Week 2 (22–28 Aug) — Networking on Linux, Package Management, Cron**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 22 Aug | **Lab 2 work:** Write a monitoring script (disk check + alert), set up cron to run it hourly | Lab 2 work |
| Sun | 23 Aug | Finish Lab 2, open PR. Package management (apt/yum/dnf). SSH basics | Lab 2 PR |
| Mon | 24 Aug | Shell environment — PATH, env vars, .bashrc, aliases | Daily note |
| Tue | 25 Aug | Text processing — grep, awk, sed, find, xargs (critical SRE tools) | Daily note |
| Wed | 26 Aug | SSH — ssh-keygen, ssh config, scp, rsync | Daily note |
| Thu | 27 Aug | Performance basics — load average, CPU steal, iowait, oom killer | Daily note |
| Fri | 28 Aug | Review + weekly journal. Read Lab 3 instructions | Weekly journal |

**Week 3 (29 Aug – 4 Sep) — Troubleshooting + Quiz + Lab 3**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 29 Aug | **Lab 3 work:** Troubleshoot a deliberately broken service — find the issue, fix it, document the process | Lab 3 work |
| Sun | 30 Aug | Finish Lab 3, open PR. Review all notes for quiz | Lab 3 PR |
| Mon | 31 Aug | **QUIZ DAY:** Attempt the 10-question quiz. Submit answers as a PR | Quiz PR |
| Tue | 1 Sep | Address quiz feedback / lab review comments | Fixes |
| Wed | 2 Sep | Address remaining review comments. Get concept approved ✅ | Concept done |
| Thu | 3 Sep | Buffer day — catch up if behind | — |
| Fri | 4 Sep | Weekly journal. Preview next concept: Networking | Weekly journal |

---

### Concept 2: Networking Fundamentals (Weeks 4–6, 5 Sep – 25 Sep 2026)

**Week 4 (5–11 Sep) — OSI Model, TCP/IP, IP Addressing**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 5 Sep | **Day 1 Networking:** Why networking matters for SRE. OSI 7 layers — what each does, real examples. Start Lab 1 | Daily note + Lab 1 |
| Sun | 6 Sep | TCP vs UDP — handshake, reliability, when to use each. IP addressing, subnets, CIDR. Finish Lab 1 | Lab 1 PR |
| Mon | 7 Sep | Ports, sockets, connections — ss, netstat commands | Daily note |
| Tue | 8 Sep | DNS — how it works, dig, nslookup, /etc/hosts, /etc/resolv.conf | Daily note |
| Wed | 9 Sep | HTTP/HTTPS — request/response, status codes, headers | Daily note |
| Thu | 10 Sep | Load balancers — what they do, algorithms (round-robin, least-connections) | Daily note |
| Fri | 11 Sep | Review + weekly journal | Weekly journal |

**Week 5 (12–18 Sep) — Diagnostics, Firewalls, VPN**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 12 Sep | **Lab 2 work:** Network troubleshooting lab — use tcpdump, traceroute, curl, telnet to diagnose issues | Lab 2 work |
| Sun | 13 Sep | Finish Lab 2, open PR. Firewalls — iptables, ufw basics | Lab 2 PR |
| Mon | 14 Sep | VPN, proxies, reverse proxies (nginx as reverse proxy) | Daily note |
| Tue | 15 Sep | TLS/SSL — certificates, handshakes, common cert issues | Daily note |
| Wed | 16 Sep | Network performance — latency, bandwidth, throughput, jitter | Daily note |
| Thu | 17 Sep | CDN basics — how CDNs work, cache invalidation | Daily note |
| Fri | 18 Sep | Review + weekly journal | Weekly journal |

**Week 6 (19–25 Sep) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 19 Sep | **Lab 3 work:** Set up a reverse proxy with nginx, serve a simple app, add TLS | Lab 3 work |
| Sun | 20 Sep | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 21 Sep | **QUIZ DAY:** Attempt 10-question quiz | Quiz PR |
| Tue | 22 Sep | Address feedback | Fixes |
| Wed | 23 Sep | Get concept approved ✅ | Concept done |
| Thu | 24 Sep | Buffer day | — |
| Fri | 25 Sep | Weekly journal. Preview: Bash Scripting | Weekly journal |

---

### Concept 3: Bash Scripting (Weeks 7–9, 26 Sep – 16 Oct 2026)

**Week 7 (26 Sep – 2 Oct) — Shell Basics, Variables, Conditionals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 26 Sep | Why scripting matters for SRE. Bash basics — shebang, variables, strings, arrays. Start Lab 1 | Daily note + Lab 1 |
| Sun | 27 Sep | Conditionals (if/else, case), test operators. Finish Lab 1 | Lab 1 PR |
| Mon | 28 Sep | Loops (for, while, until), break, continue | Daily note |
| Tue | 29 Sep | Functions, arguments, return values, exit codes | Daily note |
| Wed | 30 Sep | Input/output — stdin, stdout, stderr, redirection, piping | Daily note |
| Thu | 1 Oct | String manipulation, parameter expansion | Daily note |
| Fri | 2 Oct | Review + weekly journal | Weekly journal |

**Week 8 (3–9 Oct) — Advanced Bash, Error Handling, Automation**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 3 Oct | **Lab 2 work:** Write an automated health-check script that checks services and sends alerts | Lab 2 work |
| Sun | 4 Oct | Finish Lab 2, open PR. Error handling — set -e, set -u, traps | Lab 2 PR |
| Mon | 5 Oct | Working with files — reading, writing, parsing CSV/JSON | Daily note |
| Tue | 6 Oct | Process management in scripts — backgrounding, wait, parallel execution | Daily note |
| Wed | 7 Oct | ssh automation, remote command execution | Daily note |
| Thu | 8 Oct | Best practices — quoting, quoting, quoting. ShellCheck | Daily note |
| Fri | 9 Oct | Review + weekly journal | Weekly journal |

**Week 9 (10–16 Oct) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 10 Oct | **Lab 3 work:** Write a log parsing script that extracts errors and generates a summary report | Lab 3 work |
| Sun | 11 Oct | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 12 Oct | **QUIZ DAY** | Quiz PR |
| Tue | 13 Oct | Address feedback | Fixes |
| Wed | 14 Oct | Get concept approved ✅ | Concept done |
| Thu | 15 Oct | Buffer day | — |
| Fri | 16 Oct | Weekly journal. Preview: Git | Weekly journal |

---

### Concept 4: Git & Version Control (Weeks 10–12, 17 Oct – 6 Nov 2026)

**Week 10 (17–23 Oct) — Git Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 17 Oct | Why version control is critical for SRE. Git basics — init, clone, add, commit, status. Start Lab 1 | Daily note + Lab 1 |
| Sun | 18 Oct | Branches — switch, checkout, merge. Pull requests. Finish Lab 1 | Lab 1 PR |
| Mon | 19 Oct | Git internals — how commits work, HEAD, reflog | Daily note |
| Tue | 20 Oct | git log, git diff, git show — understanding history | Daily note |
| Wed | 21 Oct | Remote repositories — push, pull, fetch, origin | Daily note |
| Thu | 22 Oct | Merge conflicts — how they happen, how to resolve | Daily note |
| Fri | 23 Oct | Review + weekly journal | Weekly journal |

**Week 11 (24–30 Oct) — Advanced Git Workflows**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 24 Oct | **Lab 2 work:** Simulate a merge conflict, resolve it, document the process | Lab 2 work |
| Sun | 25 Oct | Finish Lab 2, open PR. rebase, cherry-pick, revert | Lab 2 PR |
| Mon | 26 Oct | Git branching strategies — trunk-based, GitFlow | Daily note |
| Tue | 27 Oct | .gitignore, tags, releases | Daily note |
| Wed | 28 Oct | Git hooks — pre-commit, pre-push | Daily note |
| Thu | 29 Oct | Git stash, git bisect (debugging with git) | Daily note |
| Fri | 30 Oct | Review + weekly journal | Weekly journal |

**Week 12 (31 Oct – 6 Nov) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 31 Oct | **Lab 3 work:** Set up a pre-commit hook that runs a linter on scripts | Lab 3 work |
| Sun | 1 Nov | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 2 Nov | **QUIZ DAY** | Quiz PR |
| Tue | 3 Nov | Address feedback | Fixes |
| Wed | 4 Nov | Get concept approved ✅ — **Foundation Phase Complete!** | Concept done |
| Thu | 5 Nov | Buffer day | — |
| Fri | 6 Nov | Weekly journal. Phase 1 retrospective. Preview: Python | Weekly journal |

---

## Phase 2: Core Skills (Weeks 13–24, Nov 2026 – Feb 2027)

### Concept 5: Python Scripting for SRE (Weeks 13–15, 7 Nov – 27 Nov 2026)

**Week 13 (7–13 Nov) — Python Basics**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 7 Nov | Why Python for SRE. Python basics — variables, types, strings. Start Lab 1 | Daily note + Lab 1 |
| Sun | 8 Nov | Lists, dicts, tuples, sets. Control flow. Finish Lab 1 | Lab 1 PR |
| Mon | 9 Nov | Functions, arguments, *args, **kwargs, lambda | Daily note |
| Tue | 10 Nov | File I/O — reading/writing files, context managers | Daily note |
| Wed | 11 Nov | Exception handling — try/except/finally, custom exceptions | Daily note |
| Thu | 12 Nov | Modules and packages, pip, virtualenv/venv | Daily note |
| Fri | 13 Nov | Review + weekly journal | Weekly journal |

**Week 14 (14–20 Nov) — Python for Infrastructure**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 14 Nov | **Lab 2 work:** Write a Python script that calls an API, parses JSON, and alerts on thresholds | Lab 2 work |
| Sun | 15 Nov | Finish Lab 2, open PR. requests library, working with REST APIs | Lab 2 PR |
| Mon | 16 Nov | subprocess module — running shell commands from Python | Daily note |
| Tue | 17 Nov | Working with JSON, YAML, CSV in Python | Daily note |
| Wed | 18 Nov | argparse — building CLI tools | Daily note |
| Thu | 19 Nov | Logging module — structured logging in Python | Daily note |
| Fri | 20 Nov | Review + weekly journal | Weekly journal |

**Week 15 (21–27 Nov) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 21 Nov | **Lab 3 work:** Build a CLI tool that checks service health across multiple servers and generates a report | Lab 3 work |
| Sun | 22 Nov | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 23 Nov | **QUIZ DAY** | Quiz PR |
| Tue | 24 Nov | Address feedback | Fixes |
| Wed | 25 Nov | Get concept approved ✅ | Concept done |
| Thu | 26 Nov | Buffer day | — |
| Fri | 27 Nov | Weekly journal. Preview: Databases | Weekly journal |

---

### Concept 6: Databases (Weeks 16–18, 28 Nov – 18 Dec 2026)

**Week 16 (28 Nov – 4 Dec) — SQL Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 28 Nov | Why databases matter for SRE. SQL basics — SELECT, INSERT, UPDATE, DELETE. Start Lab 1 | Daily note + Lab 1 |
| Sun | 29 Nov | JOINs, GROUP BY, HAVING, subqueries. Finish Lab 1 | Lab 1 PR |
| Mon | 30 Nov | Indexes — what they are, when they help, when they hurt | Daily note |
| Tue | 1 Dec | EXPLAIN — understanding query plans | Daily note |
| Wed | 2 Dec | Transactions, ACID, isolation levels | Daily note |
| Thu | 3 Dec | Connection pooling — why SREs care | Daily note |
| Fri | 4 Dec | Review + weekly journal | Weekly journal |

**Week 17 (5–11 Dec) — NoSQL & Database Operations**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 5 Dec | **Lab 2 work:** Set up PostgreSQL, create a schema, write queries, analyze performance with EXPLAIN | Lab 2 work |
| Sun | 6 Dec | Finish Lab 2, open PR. NoSQL — Redis, MongoDB, when to use each | Lab 2 PR |
| Mon | 7 Dec | Replication — primary/replica, read replicas | Daily note |
| Tue | 8 Dec | Backups and recovery — pg_dump, point-in-time recovery | Daily note |
| Wed | 9 Dec | Database performance — slow queries, lock contention, deadlocks | Daily note |
| Thu | 10 Dec | Connection exhaustion, pool sizing | Daily note |
| Fri | 11 Dec | Review + weekly journal | Weekly journal |

**Week 18 (12–18 Dec) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 12 Dec | **Lab 3 work:** Build a database health-check script that checks connections, slow queries, and disk usage | Lab 3 work |
| Sun | 13 Dec | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 14 Dec | **QUIZ DAY** | Quiz PR |
| Tue | 15 Dec | Address feedback | Fixes |
| Wed | 16 Dec | Get concept approved ✅ | Concept done |
| Thu | 17 Dec | Buffer day | — |
| Fri | 18 Dec | Weekly journal. Preview: Web Architecture | Weekly journal |

---

### Concept 7: Web Architecture & Protocols (Weeks 19–21, 19 Dec 2026 – 8 Jan 2027)

**Week 19 (19–25 Dec) — Web Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 19 Dec | Why web architecture matters for SRE. HTTP deep dive — methods, headers, body. Start Lab 1 | Daily note + Lab 1 |
| Sun | 20 Dec | HTTP/2, HTTP/3, WebSocket. Finish Lab 1 | Lab 1 PR |
| Mon | 21 Dec | REST API design — resources, status codes, pagination | Daily note |
| Tue | 22 Dec | gRPC — what it is, when to use it vs REST | Daily note |
| Wed | 23 Dec | Caching — browser cache, CDN, application cache, Redis cache | Daily note |
| Thu | 24 Dec | API gateways — what they do, rate limiting | Daily note |
| Fri | 25 Dec | Review + weekly journal (holiday — adjust if needed) | Weekly journal |

**Week 20 (26 Dec – 1 Jan) — Architecture Patterns**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 26 Dec | **Lab 2 work:** Deploy a 3-tier app (web + app + DB), diagram the architecture | Lab 2 work |
| Sun | 27 Dec | Finish Lab 2, open PR. Microservices vs monoliths | Lab 2 PR |
| Mon | 28 Dec | Load balancing algorithms, session affinity | Daily note |
| Tue | 29 Dec | Service discovery, DNS-based vs registry-based | Daily note |
| Wed | 30 Dec | Message queues — RabbitMQ, Kafka basics | Daily note |
| Thu | 31 Dec | Idempotency, retries, circuit breakers | Daily note |
| Fri | 1 Jan | Review + weekly journal (New Year — adjust) | Weekly journal |

**Week 21 (2–8 Jan) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 2 Jan | **Lab 3 work:** Set up nginx as a load balancer in front of 2 app instances, test failover | Lab 3 work |
| Sun | 3 Jan | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 4 Jan | **QUIZ DAY** | Quiz PR |
| Tue | 5 Jan | Address feedback | Fixes |
| Wed | 6 Jan | Get concept approved ✅ | Concept done |
| Thu | 7 Jan | Buffer day | — |
| Fri | 8 Jan | Weekly journal. Preview: Monitoring | Weekly journal |

---

### Concept 8: Monitoring & Observability (Weeks 22–24, 9–29 Jan 2027)

**Week 22 (9–15 Jan) — Observability Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 9 Jan | Why monitoring is the SRE's eyes. The 3 pillars: metrics, logs, traces. Start Lab 1 | Daily note + Lab 1 |
| Sun | 10 Jan | Prometheus architecture — server, exporters, targets, scrape configs. Finish Lab 1 | Lab 1 PR |
| Mon | 11 Jan | Metrics types — counter, gauge, histogram, summary | Daily note |
| Tue | 12 Jan | PromQL — selectors, aggregations, rate, histograms | Daily note |
| Wed | 13 Jan | Recording rules, alerting rules | Daily note |
| Thu | 14 Jan | Alertmanager — routing, inhibition, silences | Daily note |
| Fri | 15 Jan | Review + weekly journal | Weekly journal |

**Week 23 (16–22 Jan) — Grafana & Dashboards**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 16 Jan | **Lab 2 work:** Set up Prometheus + Grafana, instrument a sample app, create dashboards | Lab 2 work |
| Sun | 17 Jan | Finish Lab 2, open PR. Grafana dashboards — panels, variables, templating | Lab 2 PR |
| Mon | 18 Jan | Structured logging — JSON logs, log levels, correlation IDs | Daily note |
| Tue | 19 Jan | Distributed tracing — OpenTelemetry, Jaeger, spans | Daily note |
| Wed | 20 Jan | SLI/SLO-based alerting (connecting to SRE practices) | Daily note |
| Thu | 21 Jan | Dashboard anti-patterns — what NOT to do | Daily note |
| Fri | 22 Jan | Review + weekly journal | Weekly journal |

**Week 24 (23–29 Jan) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 23 Jan | **Lab 3 work:** Create a complete monitoring stack — alert when CPU > 80%, create a Grafana dashboard, test the alert | Lab 3 work |
| Sun | 24 Jan | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 25 Jan | **QUIZ DAY** | Quiz PR |
| Tue | 26 Jan | Address feedback | Fixes |
| Wed | 27 Jan | Get concept approved ✅ — **Core Skills Phase Complete!** | Concept done |
| Thu | 28 Jan | Buffer day | — |
| Fri | 29 Jan | Weekly journal. Phase 2 retrospective. Preview: Docker | Weekly journal |

---

## Phase 3: Infrastructure (Weeks 25–36, Jan–May 2027)

### Concept 9: Containers — Docker (Weeks 25–27, 30 Jan – 19 Feb 2027)

**Week 25 (30 Jan – 5 Feb) — Docker Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 30 Jan | Why containers changed SRE. What is a container vs a VM. Docker install + first container. Start Lab 1 | Daily note + Lab 1 |
| Sun | 31 Jan | Dockerfile — FROM, RUN, COPY, CMD, ENTRYPOINT. Finish Lab 1 | Lab 1 PR |
| Mon | 1 Feb | Docker images — layers, caching, multi-stage builds | Daily note |
| Tue | 2 Feb | Docker run — ports, volumes, environment variables, networks | Daily note |
| Wed | 3 Feb | Docker Compose — multi-container apps | Daily note |
| Thu | 4 Feb | Container registries — Docker Hub, ECR, GCR | Daily note |
| Fri | 5 Feb | Review + weekly journal | Weekly journal |

**Week 26 (6–12 Feb) — Docker Operations & Security**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 6 Feb | **Lab 2 work:** Dockerize a multi-service app (web + DB) with docker-compose | Lab 2 work |
| Sun | 7 Feb | Finish Lab 2, open PR. Container security — minimal images, non-root user, scanning | Lab 2 PR |
| Mon | 8 Feb | Docker networking — bridge, host, overlay networks | Daily note |
| Tue | 9 Feb | Volumes vs bind mounts, persistent data | Daily note |
| Wed | 10 Feb | Resource limits — CPU, memory limits in Docker | Daily note |
| Thu | 11 Feb | Image optimization — slim images, .dockerignore | Daily note |
| Fri | 12 Feb | Review + weekly journal | Weekly journal |

**Week 27 (13–19 Feb) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 13 Feb | **Lab 3 work:** Build a multi-stage Dockerfile, optimize image size, run with resource limits, document | Lab 3 work |
| Sun | 14 Feb | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 15 Feb | **QUIZ DAY** | Quiz PR |
| Tue | 16 Feb | Address feedback | Fixes |
| Wed | 17 Feb | Get concept approved ✅ | Concept done |
| Thu | 18 Feb | Buffer day | — |
| Fri | 19 Feb | Weekly journal. Preview: Kubernetes | Weekly journal |

---

### Concept 10: Kubernetes (Weeks 28–30, 20 Feb – 12 Mar 2027)

**Week 28 (20–26 Feb) — K8s Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 20 Feb | Why Kubernetes. K8s architecture — control plane, nodes, etcd. Start Lab 1 (minikube/kind) | Daily note + Lab 1 |
| Sun | 21 Feb | Pods, Deployments, ReplicaSets. kubectl basics. Finish Lab 1 | Lab 1 PR |
| Mon | 22 Feb | Services — ClusterIP, NodePort, LoadBalancer | Daily note |
| Tue | 23 Feb | ConfigMaps and Secrets | Daily note |
| Wed | 24 Feb | Namespaces, labels, selectors | Daily note |
| Thu | 25 Feb | Health checks — liveness, readiness, startup probes | Daily note |
| Fri | 26 Feb | Review + weekly journal | Weekly journal |

**Week 29 (27 Feb – 5 Mar) — K8s Operations**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 27 Feb | **Lab 2 work:** Deploy a 3-tier app on K8s with Deployments, Services, ConfigMaps, and probes | Lab 2 work |
| Sun | 28 Feb | Finish Lab 2, open PR. StatefulSets, DaemonSets, Jobs, CronJobs | Lab 2 PR |
| Mon | 1 Mar | Volumes and PersistentVolumeClaims | Daily note |
| Tue | 2 Mar | RBAC — roles, role bindings, service accounts | Daily note |
| Wed | 3 Mar | Resource requests and limits, QoS classes | Daily note |
| Thu | 4 Mar | HPA (Horizontal Pod Autoscaler) | Daily note |
| Fri | 5 Mar | Review + weekly journal | Weekly journal |

**Week 30 (6–12 Mar) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 6 Mar | **Lab 3 work:** Deploy an app with HPA, set up a Horizontal Pod Autoscaler, load test to trigger scaling | Lab 3 work |
| Sun | 7 Mar | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 8 Mar | **QUIZ DAY** | Quiz PR |
| Tue | 9 Mar | Address feedback | Fixes |
| Wed | 10 Mar | Get concept approved ✅ | Concept done |
| Thu | 11 Mar | Buffer day | — |
| Fri | 12 Mar | Weekly journal. Preview: Cloud Platforms | Weekly journal |

---

### Concept 11: Cloud Platforms — AWS (Weeks 31–33, 13 Mar – 2 Apr 2027)

**Week 31 (13–19 Mar) — AWS Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 13 Mar | Why cloud for SRE. AWS core services — EC2, VPC, S3, IAM. Start Lab 1 (create a free-tier account) | Daily note + Lab 1 |
| Sun | 14 Mar | VPC — subnets, route tables, internet gateways, security groups. Finish Lab 1 | Lab 1 PR |
| Mon | 15 Mar | EC2 — launch, connect, key pairs, user data | Daily note |
| Tue | 16 Mar | S3 — buckets, permissions, lifecycle policies | Daily note |
| Wed | 17 Mar | IAM — users, roles, policies, least privilege | Daily note |
| Thu | 18 Mar | Route 53 — DNS management in AWS | Daily note |
| Fri | 19 Mar | Review + weekly journal | Weekly journal |

**Week 32 (20–26 Mar) — AWS for Reliability**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 20 Mar | **Lab 2 work:** Deploy a highly available app — EC2 across 2 AZs with an Application Load Balancer | Lab 2 work |
| Sun | 21 Mar | Finish Lab 2, open PR. Auto Scaling Groups | Lab 2 PR |
| Mon | 22 Mar | RDS — managed databases, multi-AZ | Daily note |
| Tue | 23 Mar | CloudWatch — metrics, logs, alarms | Daily note |
| Wed | 24 Mar | AWS cost optimization — what SREs watch | Daily note |
| Thu | 25 Mar | Well-Architected Framework — reliability pillar | Daily note |
| Fri | 26 Mar | Review + weekly journal | Weekly journal |

**Week 33 (27 Mar – 2 Apr) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 27 Mar | **Lab 3 work:** Set up CloudWatch alarms for CPU/memory, configure auto-scaling, document the setup | Lab 3 work |
| Sun | 28 Mar | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 29 Mar | **QUIZ DAY** | Quiz PR |
| Tue | 30 Mar | Address feedback | Fixes |
| Wed | 31 Mar | Get concept approved ✅ | Concept done |
| Thu | 1 Apr | Buffer day | — |
| Fri | 2 Apr | Weekly journal. Preview: IaC | Weekly journal |

---

### Concept 12: Infrastructure as Code (Weeks 34–36, 3–23 Apr 2027)

**Week 34 (3–9 Apr) — Terraform Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 3 Apr | Why IaC. Terraform basics — providers, resources, state. Start Lab 1 | Daily note + Lab 1 |
| Sun | 4 Apr | Terraform workflow — init, plan, apply, destroy. Variables and outputs. Finish Lab 1 | Lab 1 PR |
| Mon | 5 Apr | Terraform state — local vs remote, state locking | Daily note |
| Tue | 6 Apr | Modules — reusability, structure | Daily note |
| Wed | 7 Apr | Ansible basics — inventory, playbooks, modules | Daily note |
| Thu | 8 Apr | Ansible — roles, variables, conditionals | Daily note |
| Fri | 9 Apr | Review + weekly journal | Weekly journal |

**Week 35 (10–16 Apr) — IaC Operations**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 10 Apr | **Lab 2 work:** Provision an AWS EC2 + security group + S3 bucket using Terraform | Lab 2 work |
| Sun | 11 Apr | Finish Lab 2, open PR. Terraform + Ansible together | Lab 2 PR |
| Mon | 12 Apr | IaC best practices — DRY, modular, versioned | Daily note |
| Tue | 13 Apr | Drift detection and remediation | Daily note |
| Wed | 14 Apr | Secrets management in IaC | Daily note |
| Thu | 15 Apr | CI for Terraform — terraform plan in PRs | Daily note |
| Fri | 16 Apr | Review + weekly journal | Weekly journal |

**Week 36 (17–23 Apr) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 17 Apr | **Lab 3 work:** Use Ansible to configure a server — install nginx, deploy an app, set up monitoring agent | Lab 3 work |
| Sun | 18 Apr | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 19 Apr | **QUIZ DAY** | Quiz PR |
| Tue | 20 Apr | Address feedback | Fixes |
| Wed | 21 Apr | Get concept approved ✅ — **Infrastructure Phase Complete!** | Concept done |
| Thu | 22 Apr | Buffer day | — |
| Fri | 23 Apr | Weekly journal. Phase 3 retrospective. Preview: CI/CD | Weekly journal |

---

## Phase 4: Advanced SRE (Weeks 37–48, Apr–Jul 2027)

### Concept 13: CI/CD Pipelines (Weeks 37–39, 24 Apr – 14 May 2027)

**Week 37 (24–30 Apr) — CI/CD Fundamentals**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 24 Apr | Why CI/CD for SRE. CI vs CD vs CD (continuous deployment). Start Lab 1 (GitHub Actions) | Daily note + Lab 1 |
| Sun | 25 Apr | GitHub Actions — workflows, runners, jobs, steps. Finish Lab 1 | Lab 1 PR |
| Mon | 26 Apr | Build vs deploy pipelines | Daily note |
| Tue | 27 Apr | Testing in CI — unit, integration, smoke tests | Daily note |
| Wed | 28 Apr | Artifact management and versioning | Daily note |
| Thu | 29 Apr | Blue-green, canary, rolling deployments | Daily note |
| Fri | 30 Apr | Review + weekly journal | Weekly journal |

**Week 38 (1–7 May) — CD Operations**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 1 May | **Lab 2 work:** Build a CI pipeline that runs tests, builds a Docker image, and pushes to a registry | Lab 2 work |
| Sun | 2 May | Finish Lab 2, open PR. Deployment strategies in practice | Lab 2 PR |
| Mon | 3 May | Pipeline observability — monitoring your CI/CD | Daily note |
| Tue | 4 May | Rollbacks — automated and manual | Daily note |
| Wed | 5 May | Feature flags and progressive delivery | Daily note |
| Thu | 6 May | GitOps — ArgoCD / Flux concepts | Daily note |
| Fri | 7 May | Review + weekly journal | Weekly journal |

**Week 39 (8–14 May) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 8 May | **Lab 3 work:** Build a CD pipeline that deploys to Kubernetes with a canary strategy and automated rollback | Lab 3 work |
| Sun | 9 May | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 10 May | **QUIZ DAY** | Quiz PR |
| Tue | 11 May | Address feedback | Fixes |
| Wed | 12 May | Get concept approved ✅ | Concept done |
| Thu | 13 May | Buffer day | — |
| Fri | 14 May | Weekly journal. Preview: Incident Response | Weekly journal |

---

### Concept 14: Incident Response & Postmortems (Weeks 40–42, 15 May – 4 Jun 2027)

**Week 40 (15–21 May) — Incident Management**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 15 May | Why incidents define SRE. Incident lifecycle — detect, respond, mitigate, resolve. Start Lab 1 | Daily note + Lab 1 |
| Sun | 16 May | Severity levels, escalation, incident commander role. Finish Lab 1 | Lab 1 PR |
| Mon | 17 May | On-call rotation — primary, secondary, follow-the-sun | Daily note |
| Tue | 18 May | Pager systems — PagerDuty, Opsgenie concepts | Daily note |
| Wed | 19 May | Runbooks — when to use them, how to write good ones | Daily note |
| Thu | 20 May | Communication during incidents — status pages, stakeholder updates | Daily note |
| Fri | 21 May | Review + weekly journal | Weekly journal |

**Week 41 (22–28 May) — Postmortems & Blameless Culture**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 22 May | **Lab 2 work:** Write a full postmortem for a simulated incident using the POSTMORTEM template | Lab 2 work |
| Sun | 23 May | Finish Lab 2, open PR. Blameless postmortems — why, how | Lab 2 PR |
| Mon | 24 May | Root cause analysis — 5 whys, fishbone | Daily note |
| Tue | 25 May | Action items — tracking, ownership, follow-through | Daily note |
| Wed | 26 May | Incident metrics — MTTD, MTTR, MTBF | Daily note |
| Thu | 27 May | Chaos engineering — injecting failures on purpose | Daily note |
| Fri | 28 May | Review + weekly journal | Weekly journal |

**Week 42 (29 May – 4 Jun) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 29 May | **Lab 3 work:** Run a game day — inject a failure, respond using a runbook, write the postmortem | Lab 3 work |
| Sun | 30 May | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 31 May | **QUIZ DAY** | Quiz PR |
| Tue | 1 Jun | Address feedback | Fixes |
| Wed | 2 Jun | Get concept approved ✅ | Concept done |
| Thu | 3 Jun | Buffer day | — |
| Fri | 4 Jun | Weekly journal. Preview: SRE Practices | Weekly journal |

---

### Concept 15: SRE Practices — SLOs, SLIs, Error Budgets (Weeks 43–45, 5–25 Jun 2027)

**Week 43 (5–11 Jun) — Service Level Objectives**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 5 Jun | The heart of SRE. SLIs, SLOs, SLAs — definitions and relationships. Start Lab 1 | Daily note + Lab 1 |
| Sun | 6 Jun | Error budgets — what they are, how to use them. Finish Lab 1 | Lab 1 PR |
| Mon | 7 Jun | Choosing good SLIs — latency, availability, correctness | Daily note |
| Tue | 8 Jun | Setting SLOs — user-focused, measurable, achievable | Daily note |
| Wed | 9 Jun | Error budget policy — what happens when you burn it | Daily note |
| Thu | 10 Jun | Burn rate alerting — multi-window, multi-burn-rate | Daily note |
| Fri | 11 Jun | Review + weekly journal | Weekly journal |

**Week 44 (12–18 Jun) — Reliability Engineering**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 12 Jun | **Lab 2 work:** Define SLIs/SLOs for a sample service, implement burn-rate alerting in Prometheus | Lab 2 work |
| Sun | 13 Jun | Finish Lab 2, open PR. Capacity planning — when to scale up | Lab 2 PR |
| Mon | 14 Jun | Load testing — k6, locust, identifying bottlenecks | Daily note |
| Tue | 15 Jun | Toil reduction — what is toil, how to eliminate it | Daily note |
| Wed | 16 Jun | Reliability reviews and risk assessment | Daily note |
| Thu | 17 Jun | Cost vs reliability — the tradeoff | Daily note |
| Fri | 18 Jun | Review + weekly journal | Weekly journal |

**Week 45 (19–25 Jun) — Lab 3 + Quiz + Approve**
| Day | Date | Topic | Output |
|---|---|---|---|
| Sat | 19 Jun | **Lab 3 work:** Build a complete SRE dashboard — SLO tracking, error budget, burn rate, alerts | Lab 3 work |
| Sun | 20 Jun | Finish Lab 3, open PR. Review for quiz | Lab 3 PR |
| Mon | 21 Jun | **QUIZ DAY** | Quiz PR |
| Tue | 22 Jun | Address feedback | Fixes |
| Wed | 23 Jun | Get concept approved ✅ — **Advanced SRE Phase Complete!** | Concept done |
| Thu | 24 Jun | Buffer day | — |
| Fri | 25 Jun | Weekly journal. All 15 concepts done! Preview: Capstone | Weekly journal |

---

## Phase 5: Capstone (Weeks 46–52, Jun–Aug 2027)

### Capstone Project (Weeks 46–51, 26 Jun – 6 Aug 2027)

**The capstone ties everything together. You will design, build, and operate a production-grade system.**

**Week 46–47 (26 Jun – 9 Jul): Design & Plan**
- Design a multi-service application architecture
- Define SLOs and error budgets
- Write infrastructure plan (Terraform)
- Write deployment plan (CI/CD)
- Write monitoring plan (Prometheus + Grafana)
- Write runbooks for expected incidents

**Week 48–49 (10–23 Jul): Build & Deploy**
- Implement the application (2–3 services)
- Containerize everything (Docker)
- Deploy to Kubernetes
- Set up CI/CD pipeline
- Implement monitoring, alerting, and dashboards

**Week 50 (24–30 Jul): Operate & Test**
- Run a load test
- Run a game day (inject failures)
- Practice incident response
- Write postmortems
- Verify SLOs are being met

**Week 51 (31 Jul – 6 Aug): Polish & Document**
- Finalize all documentation
- Create architecture diagrams
- Write a comprehensive README for the capstone
- Prepare a presentation/demo

### Week 52 (7–13 Aug 2027): Career Prep & Wrap-up
| Day | Date | Topic |
|---|---|---|
| Mon | 7 Aug | Resume preparation — SRE keywords, projects, metrics |
| Tue | 8 Aug | Interview prep — common SRE interview questions |
| Wed | 9 Aug | Mock interview (I will quiz you) |
| Thu | 10 Aug | Mock interview continued |
| Fri | 11 Aug | Final review of all 15 concepts |
| Sat | 12 Aug | Final retrospective — what you learned, what's next |
| Sun | 13 Aug | **Graduation Day** 🎓 — 1 year complete |

---

## Summary Stats

| Metric | Value |
|---|---|
| Total duration | 52 weeks (12 months) |
| Total concepts | 15 |
| Total labs | 45 (3 per concept) |
| Total quizzes | 15 (10 questions each) |
| Estimated study hours | ~625 hours |
| Start date | 15 August 2026 |
| End date | 13 August 2027 |
| Your work hours | 11 hours/day (Performance Engineer) |
| Your study hours | ~1.5–2h weekdays, ~4–6h weekends |

> **This timetable is ambitious but achievable IF you are consistent. Missing weeks will push the end date. There is no shortcut.**
