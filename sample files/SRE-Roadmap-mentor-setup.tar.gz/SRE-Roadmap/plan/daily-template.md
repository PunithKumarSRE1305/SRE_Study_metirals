# Daily Study Template

> Copy this structure for EVERY study day. Save as: `progress/daily-notes/YYYY-MM-DD-punith.md`

---

## Daily Note — [YYYY-MM-DD]

### Day [X] of SRE Journey | Concept: [concept name]

### Time Spent Today
[hours] (target: 1.5–2h weekday, 4–6h weekend)

---

### What I Studied
- [Topic 1]: [2-3 sentences about what you learned]
- [Topic 2]: [2-3 sentences]

### Commands/Code I Practiced
```
# List any commands or code you ran during practice
```

### What I Found Confusing (Blockers)
- [Any topic you didn't fully understand — be honest]

### Tasks Completed
- [ ] Read concept README sections
- [ ] Practiced commands/examples
- [ ] Started/continued lab work
- [ ] Created daily note (this file)

### Plan for Tomorrow
- [What you'll study next]

---

## Important Reminders
1. **Be honest about blockers** — if you don't understand something, write it down. I will help.
2. **Don't skip the daily note** — it's required. No note = no evidence you studied.
3. **Commit and push this note** — don't leave it on your computer only.
4. **Quality over quantity** — 1 hour of focused study beats 3 hours of distracted reading.

---

## Weekly Schedule Reference

### Weekday (1.5–2 hours)
| Time | Activity |
|---|---|
| 10 min | Review yesterday's notes |
| 10 min | Read today's objectives in the concept README |
| 60–80 min | Focused study / hands-on practice |
| 10–20 min | Write daily note, commit and push |

### Weekend — Saturday (4–5 hours)
| Time | Activity |
|---|---|
| 30 min | Review the week's notes |
| 3–4 hours | Lab work (build, test, iterate) |
| 30–60 min | Document lab, prepare PR, commit and push |

### Weekend — Sunday (3–4 hours)
| Time | Activity |
|---|---|
| 1–2 hours | Finish lab work / start new lab |
| 30 min | Attempt quiz (if ready) |
| 30 min | Write weekly journal |
| 30 min | Commit everything, push, open PRs |
